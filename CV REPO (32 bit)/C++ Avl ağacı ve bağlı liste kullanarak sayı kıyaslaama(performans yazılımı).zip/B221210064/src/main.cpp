/**
* @file main.cpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include "kontrolClass.hpp"
using namespace std;

int main()
{
    kontrolClass *kontrolClassElemani = new kontrolClass();
    std::ifstream dosya("veriler.txt");
    int counterforKontrollClass = 1;
    int *pointerforcounterforKontrollClass = &counterforKontrollClass;

    // Dosya açıldı mı kontrol et
    if (!dosya.is_open())
    {
        std::cerr << "Dosya acilamadi." << std::endl;
        return 1; // Hata durumunu belirtmek için uygun bir değer dönebilirsiniz
    }

    // Dosyadan veri oku ve işle
    std::string satir;
    while (getline(dosya, satir))
    {
        std::istringstream lineStream(satir);
        int number;

        avlAgaci *avlAgaciNesneleri = new avlAgaci();

        while (lineStream >> number)
        {
            avlAgaciNesneleri->kok = avlAgaciNesneleri->ekle(number, avlAgaciNesneleri->kok);
        }

        Yigin *yeniYigin = new Yigin(avlAgaciNesneleri->yaprakSayisi(avlAgaciNesneleri->kok));
        avlAgaciNesneleri->postorderYapraklariYiginaEkle(avlAgaciNesneleri->kok, yeniYigin);
        kontrolClassElemani->ekle(avlAgaciNesneleri, yeniYigin, *pointerforcounterforKontrollClass);
        avlAgaciNesneleri->inorderYazdir(avlAgaciNesneleri->kok);

        
        (*pointerforcounterforKontrollClass)++;
    }

    DugumForKontrolClass *tempkontrolclass = kontrolClassElemani->ilkDugum;

    while (tempkontrolclass != nullptr)
    {
        int ascii = (tempkontrolclass->avlAgaciNesnesi->yapraklarHaricTopla(tempkontrolclass->avlAgaciNesnesi->kok)) % (90 - 65 + 1) + 65;
        cout << static_cast<char>(ascii);
        tempkontrolclass->yiginNesnesi->YiginElemanlariYazdir(*tempkontrolclass->yiginNesnesi);
        tempkontrolclass = tempkontrolclass->sonraki;
    }

    tempkontrolclass = kontrolClassElemani->ilkDugum;

    int silmeIslemiCalismaliMi = 0;
    int *pointerForSilmeIslemiCalismaliMi = &silmeIslemiCalismaliMi;

    int kucukMuBuyukMuCikacak = 0;
    int *kucukMuBuyukMuCikacakP = &kucukMuBuyukMuCikacak;

    int ilkKontrolIslemiMi;
    int *pointerForIlkKontrolIslemiMi = &ilkKontrolIslemiMi;

    int exmin = 0;
    int *pointerforexmin = &exmin;

    int exmax = 0;
    int *pointerForExMax = &exmax;

    int hangiDugumde;
    int *pointerForHangiDugumde = &hangiDugumde;

    int alttakiIslemeGirmeliMiyim = 1;
    int *pointerForalttakiIslemeGirmeliMiyim = &alttakiIslemeGirmeliMiyim;

    while (*pointerforcounterforKontrollClass > 1)
    {
        if (*pointerForSilmeIslemiCalismaliMi == 1)
        {
            (*pointerForalttakiIslemeGirmeliMiyim) = 1;
            *kucukMuBuyukMuCikacakP = 0;

            tempkontrolclass = kontrolClassElemani->ilkDugum;
            while (tempkontrolclass != nullptr)
            {
                int yaprakSayisi = tempkontrolclass->avlAgaciNesnesi->yaprakSayisi(tempkontrolclass->avlAgaciNesnesi->kok);
                Yigin *yeniYigin = new Yigin(yaprakSayisi);
                tempkontrolclass->yiginNesnesi = yeniYigin;
                tempkontrolclass = tempkontrolclass->sonraki;
            }

            tempkontrolclass = kontrolClassElemani->ilkDugum;

            while (tempkontrolclass != nullptr)
            {
                tempkontrolclass->avlAgaciNesnesi->postorderYapraklariYiginaEkle(tempkontrolclass->avlAgaciNesnesi->kok, tempkontrolclass->yiginNesnesi);
                tempkontrolclass = tempkontrolclass->sonraki;
            }

            tempkontrolclass = kontrolClassElemani->ilkDugum;
            // yazdir
            system("cls");
            if (*pointerforcounterforKontrollClass != 2)
            {
                while (tempkontrolclass != nullptr)
                {

                    int ascii = (tempkontrolclass->avlAgaciNesnesi->yapraklarHaricTopla(tempkontrolclass->avlAgaciNesnesi->kok)) % (90 - 65 + 1) + 65;
                    cout << static_cast<char>(ascii);
                    tempkontrolclass = tempkontrolclass->sonraki;
                }
            }
            tempkontrolclass = kontrolClassElemani->ilkDugum;
            if (*pointerforcounterforKontrollClass == 2)
            {

                
                int ascii = (tempkontrolclass->avlAgaciNesnesi->yapraklarHaricTopla(tempkontrolclass->avlAgaciNesnesi->kok)) % (90 - 65 + 1) + 65;
                for (int i = 0; i < 30; i++)
                {
                    cout << "=";
                }
                cout << endl;
                cout << "|                             |" << endl;
                cout << "|                             |" << endl;
                cout << "|       Son Karakter: " << static_cast<char>(ascii) << "       |" << endl;
                cout << "|       AVL No      : " << tempkontrolclass->kacinciEleman << "     |" << endl;
                cout << "|                             |" << endl;
                cout << "|                             |" << endl;
                for (int i = 0; i < 30; i++)
                {
                    cout << "=";
                }
                cout << endl;

                break;
            }
            tempkontrolclass = kontrolClassElemani->ilkDugum;
            *pointerForSilmeIslemiCalismaliMi = 0;
        }

        if (*kucukMuBuyukMuCikacakP % 2 == 1)
        {
            tempkontrolclass = kontrolClassElemani->ilkDugum;
            (*pointerForIlkKontrolIslemiMi) = 1;
            while (tempkontrolclass != nullptr)
            {
                int max = tempkontrolclass->yiginNesnesi->peek();
                if (*pointerForIlkKontrolIslemiMi == 1)
                {
                    *pointerForExMax = tempkontrolclass->yiginNesnesi->peek();
                    *pointerForHangiDugumde = tempkontrolclass->kacinciEleman;
                    tempkontrolclass = tempkontrolclass->sonraki;
                    *pointerForIlkKontrolIslemiMi = 0;
                    continue;
                }
                if (*pointerForIlkKontrolIslemiMi == 0 && max > *pointerForExMax)
                {
                    *pointerForExMax = max;
                    *pointerForHangiDugumde = tempkontrolclass->kacinciEleman;
                }
                tempkontrolclass = tempkontrolclass->sonraki;
            }
            (*kucukMuBuyukMuCikacakP)++;
            DugumForKontrolClass *poplanacakDugum = kontrolClassElemani->getirByElemanIndex(*pointerForHangiDugumde);
            poplanacakDugum->yiginNesnesi->pop();
            if (poplanacakDugum->yiginNesnesi->isEmpty() == true)
            {
                *pointerForSilmeIslemiCalismaliMi = 1;
                kontrolClassElemani->elemanCikarByElemanIndex(*pointerForHangiDugumde);

                DugumForKontrolClass *temp = kontrolClassElemani->ilkDugum;

                temp = kontrolClassElemani->ilkDugum;
                while (temp != nullptr)
                {
                    delete temp->yiginNesnesi;
                    temp = temp->sonraki;
                }
                (*pointerforcounterforKontrollClass)--;
                (*kucukMuBuyukMuCikacakP) = 0;

                (*pointerForalttakiIslemeGirmeliMiyim) = 0;
                continue;
            }
        }

        if (*pointerForalttakiIslemeGirmeliMiyim == 1)
        {
            if (*kucukMuBuyukMuCikacakP % 2 == 0)
            {
                tempkontrolclass = kontrolClassElemani->ilkDugum;
                *pointerForIlkKontrolIslemiMi = 1;
                while (tempkontrolclass != nullptr)
                {
                    int min = tempkontrolclass->yiginNesnesi->peek();
                    if (*pointerForIlkKontrolIslemiMi == 1)
                    {
                        *pointerforexmin = tempkontrolclass->yiginNesnesi->peek();
                        *pointerForHangiDugumde = tempkontrolclass->kacinciEleman;
                        tempkontrolclass = tempkontrolclass->sonraki;
                        *pointerForIlkKontrolIslemiMi = 0;
                        continue;
                    }
                    if (*pointerForIlkKontrolIslemiMi == 0 && min < *pointerforexmin)
                    {
                        *pointerforexmin = min;
                        *pointerForHangiDugumde = tempkontrolclass->kacinciEleman;
                    }
                    tempkontrolclass = tempkontrolclass->sonraki;
                }
                (*kucukMuBuyukMuCikacakP)++;
                DugumForKontrolClass *poplanacakDugum = kontrolClassElemani->getirByElemanIndex(*pointerForHangiDugumde);
                poplanacakDugum->yiginNesnesi->pop();
                if (poplanacakDugum->yiginNesnesi->isEmpty() == true)
                {
                    *pointerForSilmeIslemiCalismaliMi = 1;
                    kontrolClassElemani->elemanCikarByElemanIndex(*pointerForHangiDugumde);
                    DugumForKontrolClass *temp = kontrolClassElemani->ilkDugum;
                    while (temp != nullptr)
                    {
                        delete temp->yiginNesnesi;
                        temp = temp->sonraki;
                    }
                    (*pointerforcounterforKontrollClass)--;
                    (*kucukMuBuyukMuCikacakP) = 0;
                    continue;
                }
            }
        }
    }
    delete kontrolClassElemani;

    return 0;
}