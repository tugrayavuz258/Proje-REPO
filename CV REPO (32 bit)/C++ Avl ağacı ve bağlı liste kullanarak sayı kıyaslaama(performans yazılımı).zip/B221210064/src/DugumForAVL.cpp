/**
* @file DugumForAVL.cpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/
#include "DugumForAVL.hpp"

DugumForAVL::DugumForAVL(int girisverisi) : sol(nullptr), sag(nullptr), sayi(girisverisi){}
