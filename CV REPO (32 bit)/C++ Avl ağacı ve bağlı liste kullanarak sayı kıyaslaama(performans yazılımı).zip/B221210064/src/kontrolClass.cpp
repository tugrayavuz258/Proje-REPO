/**
* @file kontrolClass.cpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/
#include "kontrolClass.hpp"

kontrolClass::kontrolClass()
    : ilkDugum(nullptr)
{
}

void kontrolClass::ekle(avlAgaci *avlAgaciEklenecek, Yigin *eklenecekYigin, int elemanIndex)
{
    DugumForKontrolClass *yeniEleman = new DugumForKontrolClass(avlAgaciEklenecek, eklenecekYigin, elemanIndex);

    if (this->ilkDugum == nullptr)
    {
        this->ilkDugum = yeniEleman;
    }
    else
    {
        DugumForKontrolClass *temp = this->ilkDugum;
        while (temp->sonraki != nullptr)
        {
            temp = temp->sonraki;
        }
        temp->sonraki = yeniEleman;
    }
}

void kontrolClass::elemanCikar(int indeks)
{
    if (indeks < 0)
    {

        return;
    }

    DugumForKontrolClass *silinecekDugum;

    // İlk elemanı silme durumu
    if (indeks == 0 && ilkDugum != nullptr)
    {
        silinecekDugum = ilkDugum;
        ilkDugum = ilkDugum->sonraki;
    }
    else
    {
        DugumForKontrolClass *temp = ilkDugum;
        int index = 0;

        // Silinecek elemanın bir öncesine kadar git
        while (temp != nullptr && index < indeks - 1)
        {
            temp = temp->sonraki;
            index++;
        }

        if (temp == nullptr || temp->sonraki == nullptr)
        {

            return;
        }

        silinecekDugum = temp->sonraki;
        temp->sonraki = silinecekDugum->sonraki;
    }

    delete silinecekDugum->avlAgaciNesnesi;
    delete silinecekDugum->yiginNesnesi;

    delete silinecekDugum;
}

kontrolClass::~kontrolClass()
{
    DugumForKontrolClass *current = ilkDugum;
    while (current != nullptr)
    {
        DugumForKontrolClass *temp = current;
        current = current->sonraki;
        delete temp->avlAgaciNesnesi;
        delete temp->yiginNesnesi;
        delete temp;
    }
}

DugumForKontrolClass *kontrolClass::getir(int indeks)
{
    if (indeks < 0)
    {

        return nullptr;
    }

    DugumForKontrolClass *temp = ilkDugum;
    int index = 0;

    while (temp != nullptr && index < indeks)
    {
        temp = temp->sonraki;
        index++;
    }

    if (temp == nullptr)
    {

        return nullptr;
    }

    return temp;
}

DugumForKontrolClass *kontrolClass::getirByElemanIndex(int elemanIndex)
{
    DugumForKontrolClass *temp = ilkDugum;

    while (temp != nullptr)
    {
        if (temp->kacinciEleman == elemanIndex)
        {
            return temp;
        }
        temp = temp->sonraki;
    }

    return nullptr;
}

void kontrolClass::elemanCikarByElemanIndex(int elemanIndex)
{
    if (elemanIndex < 0)
    {

        return;
    }

    DugumForKontrolClass *silinecekDugum = nullptr;

    // İlk elemanı silme durumu
    if (ilkDugum != nullptr && ilkDugum->kacinciEleman == elemanIndex)
    {
        silinecekDugum = ilkDugum;
        ilkDugum = ilkDugum->sonraki;
    }
    else
    {
        DugumForKontrolClass *temp = ilkDugum;

        // Silinecek elemanı bulana kadar git
        while (temp != nullptr && temp->sonraki != nullptr && temp->sonraki->kacinciEleman != elemanIndex)
        {
            temp = temp->sonraki;
        }

        if (temp == nullptr || temp->sonraki == nullptr)
        {

            return;
        }

        silinecekDugum = temp->sonraki;
        temp->sonraki = silinecekDugum->sonraki;
    }

    delete silinecekDugum->avlAgaciNesnesi;
    delete silinecekDugum->yiginNesnesi;

    delete silinecekDugum;
}
