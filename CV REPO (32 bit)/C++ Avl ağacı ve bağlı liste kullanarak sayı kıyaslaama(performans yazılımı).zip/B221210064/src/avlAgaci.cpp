
/**
* @file avlagaci.cpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/


#include "avlAgaci.hpp"
#include <algorithm>

using namespace std;

    avlAgaci::avlAgaci() : kok(nullptr) {
      
    }

    void avlAgaci::inorderYazdir(DugumForAVL* dugum) {
        if (dugum != nullptr) {
            inorderYazdir(dugum->sol);
          
            inorderYazdir(dugum->sag);
        }
    }
    DugumForAVL* avlAgaci::solaDondur(DugumForAVL* buyukEbeveyn)
    {
        DugumForAVL* sagCocuk = buyukEbeveyn->sag;
        buyukEbeveyn->sag = sagCocuk->sol;
        sagCocuk->sol = buyukEbeveyn;
        return sagCocuk;
    }
    DugumForAVL* avlAgaci::sagaDondur(DugumForAVL* buyukEbeveyn)
    {
        DugumForAVL* solCocuk = buyukEbeveyn->sol;
        buyukEbeveyn->sol = solCocuk->sag;
        solCocuk->sag = buyukEbeveyn;
        return solCocuk;
    }
    DugumForAVL* avlAgaci::ekle(int veri, DugumForAVL* aktifDugum) {
        if (aktifDugum == nullptr)
            return new DugumForAVL(veri);

        if (veri < aktifDugum->sayi) {
            aktifDugum->sol = ekle(veri, aktifDugum->sol);
        }
        else if (veri > aktifDugum->sayi) {
            aktifDugum->sag = ekle(veri, aktifDugum->sag);
        }
        else {
            // Veri zaten ağaçta varsa, hiçbir şey yapma
            return aktifDugum;
        }

        // Yükseklik kontrolü ve rotasyonlar
        int solYukseklik = yukseklik(aktifDugum->sol);
        int sagYukseklik = yukseklik(aktifDugum->sag);

        // Sol alt ağaç yüksekliği daha büyükse sola dönüş yap
        if (solYukseklik - sagYukseklik > 1) {
            if (veri < aktifDugum->sol->sayi) {
                aktifDugum = sagaDondur(aktifDugum);
            }
            else {
                aktifDugum->sol = solaDondur(aktifDugum->sol);
                aktifDugum = sagaDondur(aktifDugum);
            }
        }
        // Sağ alt ağaç yüksekliği daha büyükse sağa dönüş yap
        else if (sagYukseklik - solYukseklik > 1) {
            if (veri > aktifDugum->sag->sayi) {
                aktifDugum = solaDondur(aktifDugum);
            }
            else {
                aktifDugum->sag = sagaDondur(aktifDugum->sag);
                aktifDugum = solaDondur(aktifDugum);
            }
        }

        return aktifDugum;
    }

    int avlAgaci::yukseklik(DugumForAVL* aktifDugum)
    {
        if (aktifDugum)
        {
            return 1 + max(yukseklik(aktifDugum->sol),
                yukseklik(aktifDugum->sag));
        }
        return -1;
    }



    void avlAgaci::tumElemanlariSil(DugumForAVL* aktifNode) {
        if (aktifNode == nullptr)
            return;

        // Sol ve sağ alt ağaçları temizle
        tumElemanlariSil(aktifNode->sol);
        tumElemanlariSil(aktifNode->sag);

        // Şu anki düğümü sil
        delete aktifNode;
    }



    // Bu fonksiyonu çağırarak ağaçtaki tüm elemanları bellekten silebilirsiniz.
    void avlAgaci::tumElemanlariSil() {
        tumElemanlariSil(kok);
        kok = nullptr; // Ağacın kökünü null olarak ayarla
    }
    avlAgaci::~avlAgaci() {
        tumElemanlariSil(kok);
    }

    int avlAgaci::yapraklarHaricTopla(DugumForAVL* dugum) {
        if (dugum == nullptr) {
            return 0;
        }

        // Eğer düğüm yaprak ise, 0 döndür
        if (dugum->sol == nullptr && dugum->sag == nullptr) {
            return 0;
        }

        // Sol ve sağ alt ağaçlardaki yapraklarda olmayan elemanları topla
        int solToplam = yapraklarHaricTopla(dugum->sol);
        int sagToplam = yapraklarHaricTopla(dugum->sag);

        // Eğer düğümün sol ve sağ alt ağaçları da yaprak değilse, düğümün değerini toplama ekle
        if (dugum->sol != nullptr || dugum->sag != nullptr) {
            return solToplam + sagToplam + dugum->sayi;
        }

        return solToplam + sagToplam;
    }

    void avlAgaci::postorderYapraklariYiginaEkle(DugumForAVL* node, Yigin* yigin) {
        
        if (node != nullptr) {
            postorderYapraklariYiginaEkle(node->sol, yigin);
            postorderYapraklariYiginaEkle(node->sag, yigin);
            if (node->sol == nullptr && node->sag == nullptr) {
                
                yigin->push(node->sayi);
                
            }
        }
    }

    int avlAgaci::yaprakSayisi(DugumForAVL* dugum) {
        if (dugum == nullptr) {
            return 0;
        }

        // Eğer düğüm yaprak ise, 1 döndür
        if (dugum->sol == nullptr && dugum->sag == nullptr) {
            return 1;
        }

        // Sol ve sağ alt ağaçlardaki yaprak düğüm sayılarını topla
        int solYapraklar = yaprakSayisi(dugum->sol);
        int sagYapraklar = yaprakSayisi(dugum->sag);

        return solYapraklar + sagYapraklar;
    }
