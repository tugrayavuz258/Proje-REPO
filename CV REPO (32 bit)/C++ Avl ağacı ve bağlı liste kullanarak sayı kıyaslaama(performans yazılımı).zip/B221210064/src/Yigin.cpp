/**
* @file Yigin.cpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/

#include "yigin.hpp"

#include <iostream>
using namespace std;

Yigin::Yigin(int boyut) : kapasite(boyut), tepe(-1)
{
    dizi = new int[kapasite];
}
void Yigin::YiginElemanlariYazdir(const Yigin &yigin)
{
    if (yigin.isEmpty())
    {

        return;
    }

   
}
void Yigin::push(int veri)
{
    if (tepe >= kapasite - 1)
    {
        // Dizi dolu, genişletme işlemi uygulanabilir
        int yeniKapasite = kapasite * 2;
        int *yeniDizi = new int[yeniKapasite];

        // Eski verileri yeni diziye kopyala
        for (int i = 0; i < kapasite; ++i)
        {
            yeniDizi[i] = dizi[i];
        }

        // Eski diziyi temizle
        delete[] dizi;

        // Yeni diziyi kullan
        dizi = yeniDizi;
        kapasite = yeniKapasite;
    }

    // Yeni elemanı ekleyerek tepeyi güncelle
    dizi[++tepe] = veri;
    ;
}

int Yigin::peek() const
{
    if (isEmpty())
    {
        std::cerr << "Yigin bos. Tepe degeri alinamaz." << std::endl;
        return -1; // Veya başka bir değer dönebilirsiniz, hata durumunu belirtmek için
    }

    return dizi[tepe];
}

void Yigin::pop()
{
    if (isEmpty())
    {

        return;
    }

    --tepe;
}

bool Yigin::isEmpty() const
{
    return tepe == -1;
}

Yigin::~Yigin()
{
    delete[] dizi;
}
