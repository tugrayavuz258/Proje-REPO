
/**
* @file Yigin.hpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/




// yigin.hpp

#ifndef YIGIN_HPP
#define YIGIN_HPP

class Yigin {
private:
    int* dizi;
    int kapasite;
    int tepe;

public:
    Yigin(int boyut);
    void YiginElemanlariYazdir(const Yigin& yigin);
    void push(int veri);

    int peek() const;

    void pop();

    bool isEmpty() const;

    ~Yigin();
};

#endif // YIGIN_HPP