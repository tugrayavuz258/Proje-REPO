
/**
* @file kontrolClass.hpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/



// kontrolClass.hpp

#ifndef KONTROLCLASS_HPP
#define KONTROLCLASS_HPP

#include "DugumForKontrolClass.hpp"

class kontrolClass {
public:
    DugumForKontrolClass* ilkDugum;

    kontrolClass();

    void ekle(avlAgaci* avlAgaciEklenecek, Yigin* eklenecekYigin, int elemanIndex);

    void elemanCikar(int indeks);

    ~kontrolClass();

    DugumForKontrolClass* getir(int indeks);

    DugumForKontrolClass* getirByElemanIndex(int elemanIndex);

    void elemanCikarByElemanIndex(int elemanIndex);
};

#endif // KONTROLCLASS_HPP