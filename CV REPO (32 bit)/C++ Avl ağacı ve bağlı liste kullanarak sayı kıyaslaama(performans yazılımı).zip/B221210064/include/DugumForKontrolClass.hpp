
/**
* @file DugumForKontrolClass.hpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/




#ifndef DUGUMFORKONTROLCLASS_HPP
#define DUGUMFORKONTROLCLASS_HPP

#include "avlAgaci.hpp"


class DugumForKontrolClass {
public:
    DugumForKontrolClass* sonraki;
    avlAgaci* avlAgaciNesnesi;
    Yigin* yiginNesnesi;
    int kacinciEleman;

    DugumForKontrolClass(avlAgaci* avlAgaciKurucu, Yigin* yiginKurucu, int elemanIndex);
};
#endif // DUGUMFORKONTROLCLASS_HPP
