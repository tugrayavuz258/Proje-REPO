
/**
* @file avlagaci.hpp
* @description Avl agaclari ve Yigitler hakkinda sayi ve kiyaslama islemleri
* @course Dersi 1. ogretim c grubu
* @assignment 2. odev
* @date 17.12.2023
* @author Tugra Yavuz tugrayavuz258@gmail.com/tugra.yavuz@ogr.sakarya.edu.tr
*/



#ifndef avlAgaci_hpp
#define avlAgaci_hpp

#include "DugumForAVL.hpp"

class avlAgaci
{
public:
  avlAgaci();
  DugumForAVL *kok;

  void inorderYazdir(DugumForAVL *dugum);
  DugumForAVL *solaDondur(DugumForAVL *buyukEbeveyn);
  DugumForAVL *sagaDondur(DugumForAVL *buyukEbeveyn);
  DugumForAVL *ekle(int veri, DugumForAVL *aktifDugum);
  int yukseklik(DugumForAVL *aktifDugum);
  void tumElemanlariSil(DugumForAVL *aktifNode);
  // Bu fonksiyonu çağırarak ağaçtaki tüm elemanları bellekten silebilirsiniz.
  void tumElemanlariSil();
  ~avlAgaci();
  int yapraklarHaricTopla(DugumForAVL *dugum);
  void postorderYapraklariYiginaEkle(DugumForAVL *node, Yigin *yigin);
  int yaprakSayisi(DugumForAVL *dugum);
};

#endif // AVL_AGACI_HPP