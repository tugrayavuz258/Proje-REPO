/**
* B221210064
* @description baglı listeler ile basamak ve sayi islemleri yapan kodlar
* @course 1-C
* @assignment 1. odev
*  13.11.2023
*  Tugra YAVUZ tugrayavuz258@gmail.com / tugra.yavuz@ogr.sakarya.edu.tr
*/




#include "Basamak.hpp"

Basamak::Basamak() : deger(0), sonraki(nullptr) {}

Basamak::Basamak(int veri) : deger(veri), sonraki(nullptr) {}



