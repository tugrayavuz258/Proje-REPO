/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
** PROGRAMLAMAYA GİRİŞİ DERSİ
**
** ÖDEV NUMARASI…:PROJE-1
** ÖĞRENCİ ADI...............:Tuğra YAVUZ
** ÖĞRENCİ NUMARASI.:B221210064
** DERS GRUBU…………:1-B
YOUTUBE LİNKİ… …: https://www.youtube.com/playlist?list=PLlpHaUl82RMu87QM-CiQfTzfQSk4Bq_xH
****************************************************************************/









using System.Collections.Generic;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;



namespace Tuğra_YAVUZ_ndp_proje
{

    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();



        }

        static public class geometrikIslemler  //islem classı 
        {
            public static float merkezNokta;
            private static float birinciCisimIcinMerkeznoktaXekseni;
            private static float birinciCisimIcinMerkezNoktaYekseni;
            private static float birinciCisimIcinMerkezNoktaZekseni;
            private static float ikinciCisimIcinMerkeznoktaXekseni;
            private static float ikinciCisimIcinMerkezNoktaYekseni;
            private static float ikinciCisimIcinMerkezNoktaZekseni;
            private static float ikinciIcinCisminEni;
            private static float birinciIcinCisminEni;
            private static float birinciIcinCisminBoyu;
            private static float ikinciIcinCisminBoyu;  //değişkenler
            private static float piDegeri;
            private static float yaricap1;
            private static float yaricap2;
            private static float BirincicisminBoyuYaniYEkseni;
            private static float BirincicisminEniYaniXEkseni;
            private static float BirincicisminDerinligiYaniZekseni;
            private static float ikinciCisminBoyuYaniYEkseni;
            private static float ikinciCisminEniYaniXEkseni;
            private static float ikinciCisminDerinligiYaniZekseni;
           
            
            
            public static void NoktaCemberCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1 , NumericUpDown Nmr2 , NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5)//2
            {

                // Form elemanlarına ait değerlere erişim
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr3.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr4.Value;
                float yaricap1 = (float)Nmr5.Value;

                float mesafeX = birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni;
                float mesafeY = birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni;
                float mesafeninKaresi = mesafeX * mesafeX + mesafeY * mesafeY;
                float yaricapkare = yaricap1 * yaricap1;

                if (mesafeninKaresi < yaricapkare)
                {
                    TBX.Text = "kesişme var";  //yaricapkare mesafekareden büyük ise
                }
                else
                {
                    TBX.Text = "kesişme yok";
                }
            }
            public static void dikdortgenDikdortgenCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8) //3
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float BirincicisminEniYaniXEkseni = (float)Nmr3.Value;
                float BirincicisminBoyuYaniYEkseni = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisminEniYaniXEkseni = (float)Nmr7.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr8.Value;



                if (birinciCisimIcinMerkeznoktaXekseni + BirincicisminEniYaniXEkseni < ikinciCisimIcinMerkeznoktaXekseni || birinciCisimIcinMerkeznoktaXekseni > ikinciCisimIcinMerkeznoktaXekseni + ikinciCisminEniYaniXEkseni)
                {
                    TBX.Text = "kesişme yok";
                }
                else if (birinciCisimIcinMerkezNoktaYekseni + BirincicisminBoyuYaniYEkseni < ikinciCisimIcinMerkezNoktaYekseni || birinciCisimIcinMerkezNoktaYekseni > ikinciCisimIcinMerkezNoktaYekseni + ikinciCisminBoyuYaniYEkseni)
                { TBX.Text = "kesişme yok"; }
                else
                {              
                    TBX.Text = "kesişme var";   //kesişme var mı yok mu test eden kod
                }



            }

            public static bool dikdortgenCemberCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7)//4
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciIcinCisminEni = (float)Nmr3.Value;
                float birinciIcinCisminBoyu = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float yaricap2 = (float)Nmr7.Value;

                float dikdortgenSol = birinciCisimIcinMerkeznoktaXekseni - birinciIcinCisminEni / 2;
                float dikdortgenSag = birinciCisimIcinMerkeznoktaXekseni + birinciIcinCisminEni / 2;
                float dikdortgenUst = birinciCisimIcinMerkezNoktaYekseni - birinciIcinCisminBoyu / 2;
                float dikdortgenAlt = birinciCisimIcinMerkezNoktaYekseni + birinciIcinCisminBoyu / 2;

                float x = Math.Abs(ikinciCisimIcinMerkeznoktaXekseni - birinciCisimIcinMerkeznoktaXekseni);
                float y = Math.Abs(ikinciCisimIcinMerkezNoktaYekseni - birinciCisimIcinMerkezNoktaYekseni);

                if (x > (birinciIcinCisminEni / 2 + yaricap2))
                    return false;
                if (y > (birinciIcinCisminBoyu / 2 + yaricap2))//kesişme var mı yok mu test eden kod
                    return false;
                if (x <= (birinciIcinCisminEni / 2))
                    return true;
                if (y <= (birinciIcinCisminBoyu / 2))
                    return true;
                float koseMesafesi = (x - birinciIcinCisminEni / 2) * (x - birinciIcinCisminEni / 2) + (y - birinciIcinCisminBoyu / 2) * (y - birinciIcinCisminBoyu);
                return (koseMesafesi <= (yaricap2 * yaricap2));

            }

            public static bool CemberCemberCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6)//5
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float yaricap1 = (float)Nmr3.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr4.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr5.Value;
                float yaricap2 = (float)Nmr6.Value;



                float ikiMerkezArasiUzaklik = (float)Math.Sqrt(Math.Pow((ikinciCisimIcinMerkeznoktaXekseni - birinciCisimIcinMerkeznoktaXekseni), 2) + Math.Pow((ikinciCisimIcinMerkezNoktaYekseni - birinciCisimIcinMerkezNoktaYekseni), 2));

                if (ikiMerkezArasiUzaklik > (yaricap2 + yaricap1))
                {
                    return false;
                }
                //kesişme var mı yok mu test eden kod
                else
                {
                    return true;
                }
            }

            public static bool noktaKureCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7)//6
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr4.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr6.Value;
                float yaricap2 = (float)Nmr7.Value;

                float mesafeX = ikinciCisimIcinMerkeznoktaXekseni - birinciCisimIcinMerkeznoktaXekseni;
                float mesafeY = ikinciCisimIcinMerkezNoktaYekseni - birinciCisimIcinMerkezNoktaYekseni;
                float mesafeZ = birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni;

                float mesafeKare = (mesafeX * mesafeX) + (mesafeY * mesafeY) + (mesafeZ * mesafeZ);
                float yaricapKare = yaricap2 * yaricap2;
                if (mesafeKare <= yaricapKare)
                {
                    return true;
                }
                else//kesişme var mı yok mu test eden kod
                {
                    return false;
                }


            }
            public static bool noktaDikdortgenPrizmaCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9)//7
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr4.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr6.Value;
                float ikinciCisminEniYaniXEkseni = (float)Nmr7.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr8.Value;
                float ikinciCisminDerinligiYaniZekseni = (float)Nmr9.Value;

                float Xmin = ikinciCisimIcinMerkeznoktaXekseni - ikinciCisminEniYaniXEkseni / 2f;
                float Ymin = ikinciCisimIcinMerkezNoktaYekseni - ikinciCisminBoyuYaniYEkseni / 2f;
                float Zmin = ikinciCisimIcinMerkezNoktaZekseni - ikinciCisminDerinligiYaniZekseni / 2f;
                float Xmax = ikinciCisimIcinMerkeznoktaXekseni + ikinciCisminEniYaniXEkseni / 2f;
                float Ymax = ikinciCisimIcinMerkezNoktaYekseni + ikinciCisminBoyuYaniYEkseni / 2f;
                float Zmax = ikinciCisimIcinMerkezNoktaZekseni + ikinciCisminDerinligiYaniZekseni / 2f;

                if (birinciCisimIcinMerkeznoktaXekseni >= Xmin && birinciCisimIcinMerkeznoktaXekseni <= Xmax && birinciCisimIcinMerkezNoktaYekseni >= Ymin && birinciCisimIcinMerkezNoktaYekseni <= Ymax && birinciCisimIcinMerkezNoktaZekseni >= Zmin && birinciCisimIcinMerkezNoktaZekseni <= Zmax)
                {
                    return true;
                }
                else
                {
                    return false;//kesişme var mı yok mu test eden kod
                }

            }
            public static void noktaSilindirCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8)//8
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr4.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr6.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr7.Value;
                float yaricap2 = (float)Nmr8.Value;

                float uzaklikX = birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni;
                float uzaklikY = birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni;
                float uzaklikZ = birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni;
                float uzaklikkare = uzaklikX * uzaklikX + uzaklikY * uzaklikY;
                if (uzaklikkare > yaricap2 * yaricap2)
                {
                    TBX.Text = "nokta silindirin disindadir";
                }
                else if (birinciCisimIcinMerkezNoktaZekseni > ikinciCisimIcinMerkezNoktaZekseni + ikinciCisminBoyuYaniYEkseni / 2 || birinciCisimIcinMerkezNoktaZekseni < ikinciCisimIcinMerkezNoktaZekseni - ikinciCisminBoyuYaniYEkseni / 2)
                {
                    TBX.Text = "nokta silindirin yuksekligi disindadir";
                }//kesişme var mı yok mu test eden kod
                else
                {
                    TBX.Text = "nokta silindirin icindedir";
                }


            }













public static void silindirSilindirCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9, NumericUpDown Nmr10)//9
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float BirincicisminBoyuYaniYEkseni = (float)Nmr4.Value;
                float yaricap1 = (float)Nmr5.Value;
                float BirincicisminEniYaniXEkseni = 2 * yaricap1;
                float BirincicisminDerinligiYaniZekseni = 2 * yaricap1;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr7.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr8.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr9.Value;
                float yaricap2 = (float)Nmr10.Value;
                float ikinciCisminDerinligiYaniZekseni = 2 * yaricap2;
                float ikinciCisminEniYaniXEkseni = 2 * yaricap2;

                float xMesafe = ikinciCisimIcinMerkeznoktaXekseni - birinciCisimIcinMerkeznoktaXekseni;
                float yMesafe = ikinciCisimIcinMerkezNoktaYekseni - birinciCisimIcinMerkezNoktaYekseni;
                float zMesafe = ikinciCisimIcinMerkezNoktaZekseni - birinciCisimIcinMerkezNoktaZekseni;

                float mesafeKare = xMesafe * xMesafe + yMesafe * yMesafe + zMesafe * zMesafe;
                float yaricapToplamKare = (yaricap1 + yaricap2) * (yaricap1 + yaricap2);

                if (mesafeKare > yaricapToplamKare)
                {
                    TBX.Text = "kesisme olmaz";
                }
                else if (mesafeKare < (yaricap2 - yaricap1) * (yaricap2 - yaricap1))
                {
                    TBX.Text = "kesisme olmaz bir silindir digerinin icinde";
                }//kesişme var mı yok mu test eden kod
                else
                {
                    float minMesafeX = (BirincicisminEniYaniXEkseni + ikinciCisminEniYaniXEkseni) / 2;
                    float minMesafeY = (BirincicisminBoyuYaniYEkseni + ikinciCisminBoyuYaniYEkseni) / 2;
                    float minMesafeZ = (ikinciCisminDerinligiYaniZekseni + BirincicisminDerinligiYaniZekseni) / 2;
                    if (Math.Abs(xMesafe) > minMesafeX + yaricap2 || Math.Abs(yMesafe) > minMesafeY + yaricap2 || Math.Abs(zMesafe) > minMesafeZ + yaricap2)
                    {
                        TBX.Text = "kesisme olmaz";
                    }
                    if (Math.Abs(xMesafe) <= minMesafeX || Math.Abs(yMesafe) <= minMesafeY || Math.Abs(zMesafe) <= minMesafeZ)

                        TBX.Text = "kesisme var";

                }

            }


            public static void kureKureCarpsimaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8)//10
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float yaricap1 = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr7.Value;
                float yaricap2 = (float)Nmr8.Value;

                float mesafeX = ikinciCisimIcinMerkeznoktaXekseni - birinciCisimIcinMerkeznoktaXekseni;
                float mesafeY = ikinciCisimIcinMerkezNoktaYekseni - birinciCisimIcinMerkezNoktaYekseni;
                float mesafeZ = ikinciCisimIcinMerkezNoktaZekseni - birinciCisimIcinMerkezNoktaZekseni;
                float mesafeKare = (mesafeX * mesafeX) + (mesafeY * mesafeY) + (mesafeZ * mesafeZ);

                float yaricapToplam = yaricap1 + yaricap2;
                if (mesafeKare < (yaricapToplam * yaricapToplam))
                {

                    TBX.Text = "kesisme var";
                }
                else//kesişme var mı yok mu test eden kod
                {

                    TBX.Text = "kesisme yok";
                }

            }


            public static void kureSilindirCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9)//11
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float yaricap1 = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr7.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr8.Value;
                float yaricap2 = (float)Nmr9.Value;
                float ikinciCisminDerinligiYaniZekseni = 2 * yaricap2;
                float ikinciCisminEniYaniXEkseni = 2 * yaricap2;

                float mesafe = (float)Math.Sqrt(Math.Pow(ikinciCisimIcinMerkeznoktaXekseni - birinciCisimIcinMerkeznoktaXekseni, 2) + Math.Pow(ikinciCisimIcinMerkezNoktaYekseni - birinciCisimIcinMerkezNoktaYekseni, 2) + Math.Pow(ikinciCisimIcinMerkezNoktaZekseni - birinciCisimIcinMerkezNoktaZekseni, 2));

                //iki cismin yarıçaplarını mesafe ile karşılaştır
                if (mesafe <= yaricap1 + yaricap2)
                {
                    TBX.Text = "kESİSME VAR"; // Kesişme var
                }//kesişme var mı yok mu test eden kod
                else
                {
                    TBX.Text = "kESİSME YOK"; // Kesişme yok
                }




            }

            public static void yuzeyKureCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8)//12
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float yaricap1 = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr7.Value;
                float yaricap2 = (float)Nmr8.Value;


                float mesafe = (float)Math.Sqrt(Math.Pow(birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni, 2) +
                                                    Math.Pow(birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni, 2) +
                                                    Math.Pow(birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni, 2));

                float yaricapToplami = yaricap1 + yaricap2;


                if (mesafe <= yaricapToplami)
                {
                    TBX.Text = "KESİSME VAR";
                }//kesişme var mı yok mu test eden kod
                else
                {
                    TBX.Text = "KESİSME YOK";
                }
            }
            public static bool yuzeyDikdortgenPrizmaCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9, NumericUpDown Nmr10)//13
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float yaricap1 = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr7.Value;
                float ikinciCisminEniYaniXEkseni = (float)Nmr8.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr9.Value;
                float ikinciCisminDerinligiYaniZekseni = (float)Nmr10.Value;

                float xMesafe = Math.Abs(birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni);
                float yMesafe = Math.Abs(birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni);
                float zMesafe = Math.Abs(birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni);
                float dikdortgenYariEn = ikinciCisminEniYaniXEkseni / 2f;
                float dikdortgenYariBoy = ikinciCisminBoyuYaniYEkseni / 2f;
                float dikdortgenYariDerinlik = ikinciCisminDerinligiYaniZekseni / 2f;
                float cap = yaricap1 * 2f;
                if (xMesafe > (dikdortgenYariEn + cap) || yMesafe > (dikdortgenYariBoy + cap) || zMesafe > (dikdortgenYariDerinlik + cap))
                {
                    return false;
                }
                if (xMesafe <= (dikdortgenYariEn + cap) || yMesafe <= dikdortgenYariBoy || zMesafe <= dikdortgenYariDerinlik) ;
                {//kesişme var mı yok mu test eden kod
                    return true;
                }
                float xKoseMesafe = xMesafe - dikdortgenYariEn;
                float yKoseMesafe = yMesafe - dikdortgenYariBoy;
                float zKoseMesafe = zMesafe - dikdortgenYariDerinlik;
                float koseMesafeKare = xKoseMesafe * xKoseMesafe + yKoseMesafe * yKoseMesafe + zKoseMesafe * zKoseMesafe;


                return koseMesafeKare <= (cap * cap);




            }




            public static bool yuzeySilindirCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9)//14
            {


                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float yaricap1 = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr7.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr8.Value;
                float yaricap2 = (float)Nmr9.Value;
                float ikinciCisminDerinligiYaniZekseni = 2 * yaricap2;
                float ikinciCisminEniYaniXEkseni = 2 * yaricap2;

                float dx = birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni;
                float dy = birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni;
                float dz = birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni;
                float distance = (float)Math.Sqrt(dx * dx + dy * dy + dz * dz);
                if (distance <= yaricap1 + ikinciCisminEniYaniXEkseni / 2f)
                {//kesişme var mı yok mu test eden kod
                    return true;
                }
                else if ((Math.Abs(birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni) < yaricap1 + ikinciCisminEniYaniXEkseni / 2f) && (Math.Abs(birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni) < yaricap1 + ikinciCisminBoyuYaniYEkseni / 2f) && (Math.Abs(birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni) < yaricap1 + ikinciCisminDerinligiYaniZekseni / 2f))
                {
                    return true;
                }
                else
                {
                    return false;
                }




            }





            public static bool kureDikdortgenPrizmaCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9, NumericUpDown Nmr10) //15 
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float yaricap1 = (float)Nmr4.Value;
                float ikinciCisimIcinMerkeznoktaXeksen = (float)Nmr5.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr7.Value;
                float ikinciCisminEniYaniXEkseni = (float)Nmr8.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr9.Value;
                float ikinciCisminDerinligiYaniZekseni = (float)Nmr10.Value;

                float xFarki = birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXeksen;
                float yFarki = birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni;
                float zFarki = birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni;
                float mesafe = (float)Math.Sqrt(xFarki * xFarki + yFarki * yFarki + zFarki * zFarki);
                float yarimGenislik = ikinciCisminEniYaniXEkseni / 2f;
                float yarimYukseklik = ikinciCisminBoyuYaniYEkseni / 2.0f;
                float yarimDerinlik = ikinciCisminDerinligiYaniZekseni / 2.0f;
                if (mesafe > yaricap1)
                {
                    return false;
                }

                float minX = ikinciCisimIcinMerkeznoktaXeksen - yarimGenislik;
                float maxX = ikinciCisimIcinMerkeznoktaXeksen + yarimGenislik;
                float minY = ikinciCisimIcinMerkezNoktaYekseni - yarimYukseklik;//kesişme var mı yok mu test eden kod
                float maxY = ikinciCisimIcinMerkezNoktaYekseni + yarimYukseklik;
                float minZ = ikinciCisimIcinMerkezNoktaZekseni - yarimDerinlik;
                float maxZ = ikinciCisimIcinMerkezNoktaZekseni + yarimDerinlik;

                if (birinciCisimIcinMerkeznoktaXekseni >= minX && birinciCisimIcinMerkeznoktaXekseni <= maxX && birinciCisimIcinMerkezNoktaYekseni >= minY && birinciCisimIcinMerkezNoktaYekseni <= maxY && birinciCisimIcinMerkezNoktaZekseni >= minZ && birinciCisimIcinMerkezNoktaZekseni <= maxZ)
                {
                    return true;
                }
                else
                {
                    return false;
                }




            }




            public static void DikdortgenPrizmaCarpismaDenetimi(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7, NumericUpDown Nmr8, NumericUpDown Nmr9, NumericUpDown Nmr10, NumericUpDown Nmr11, NumericUpDown Nmr12)//16
            {

                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float birinciCisimIcinMerkezNoktaZekseni = (float)Nmr3.Value;
                float BirincicisminEniYaniXEkseni = (float)Nmr4.Value;
                float BirincicisminBoyuYaniYEkseni = (float)Nmr5.Value;
                float BirincicisminDerinligiYaniZekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr7.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr8.Value;
                float ikinciCisimIcinMerkezNoktaZekseni = (float)Nmr9.Value;
                float ikinciCisminEniYaniXEkseni = (float)Nmr10.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr11.Value;
                float ikinciCisminDerinligiYaniZekseni = (float)Nmr12.Value;


                float xFarki = Math.Abs(birinciCisimIcinMerkeznoktaXekseni - ikinciCisimIcinMerkeznoktaXekseni);
                float yFarki = Math.Abs(birinciCisimIcinMerkezNoktaYekseni - ikinciCisimIcinMerkezNoktaYekseni);
                float zFarki = Math.Abs(birinciCisimIcinMerkezNoktaZekseni - ikinciCisimIcinMerkezNoktaZekseni);
                float prizma1YarimGenislik = BirincicisminEniYaniXEkseni / 2.0f;
                float prizma1YarimYukseklik = BirincicisminBoyuYaniYEkseni / 2.0f;
                float prizma1YarimDerinlik = BirincicisminDerinligiYaniZekseni / 2.0f;
                float prizma2YarimGenislik = ikinciCisminEniYaniXEkseni / 2.0f;
                float prizma2YarimYukseklik = ikinciCisminBoyuYaniYEkseni / 2.0f;
                float prizma2YarimDerinlik = ikinciCisminDerinligiYaniZekseni / 2.0f;
                if (xFarki <= (prizma1YarimGenislik + prizma2YarimDerinlik) &&
                    yFarki <= (prizma1YarimYukseklik + prizma2YarimYukseklik) &&//kesişme var mı yok mu test eden kod
                    zFarki <= (prizma1YarimDerinlik + prizma2YarimDerinlik))
                {
                    TBX.Text = "kesişme var";
                }
                else
                {
                    TBX.Text = "kesişme yok";
                }


            }


            public static bool NoktaYamukKesismeTesti(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7)//1
            {



                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float BirincicisminEniYaniXEkseni = (float)Nmr3.Value;
                float BirincicisminBoyuYaniYEkseni = (float)Nmr4.Value;
                float CisminEgimAcisi = (float)Nmr5.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr6.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr7.Value;
                // Yamuk merkezinin konumu
                float centerX = birinciCisimIcinMerkeznoktaXekseni - BirincicisminEniYaniXEkseni / 2;
                float centerY = birinciCisimIcinMerkezNoktaYekseni + BirincicisminBoyuYaniYEkseni / 2;
                // Yamuk kenar noktalarının koordinatlarını hesapla
                float leftX = centerX - (float)Math.Cos(CisminEgimAcisi * Math.PI / 180) * BirincicisminEniYaniXEkseni;
                float leftY = centerY - (float)Math.Sin(CisminEgimAcisi * Math.PI / 180) * BirincicisminEniYaniXEkseni / 2;
                float rightX = centerX + (float)Math.Cos(CisminEgimAcisi * Math.PI / 180) * BirincicisminEniYaniXEkseni / 2;
                float rightY = centerY + (float)Math.Sin(CisminEgimAcisi * Math.PI / 180) * BirincicisminEniYaniXEkseni / 2;
                float topX = centerX - (float)Math.Sin(CisminEgimAcisi * Math.PI / 180) * BirincicisminBoyuYaniYEkseni / 2;
                float topY = centerY + (float)Math.Cos(CisminEgimAcisi * Math.PI / 180) * BirincicisminBoyuYaniYEkseni / 2;
                float bottomX = centerX + (float)Math.Sin(CisminEgimAcisi * Math.PI / 180) * BirincicisminBoyuYaniYEkseni / 2;
                float bottomY = centerY - (float)Math.Cos(CisminEgimAcisi * Math.PI / 180) * BirincicisminBoyuYaniYEkseni / 2;
                // Nokta ile yamuk kenarlarının arasındaki uzaklıkları hesapla
                float distanceToLeft = (ikinciCisimIcinMerkeznoktaXekseni - leftX) * (ikinciCisimIcinMerkeznoktaXekseni - leftX) + (ikinciCisimIcinMerkezNoktaYekseni - leftY) * (ikinciCisimIcinMerkezNoktaYekseni - leftY);
                float distanceToRight = (ikinciCisimIcinMerkeznoktaXekseni - rightX) * (ikinciCisimIcinMerkeznoktaXekseni - rightX) + (ikinciCisimIcinMerkezNoktaYekseni - rightY) * (ikinciCisimIcinMerkezNoktaYekseni - rightY);
                float distanceToTop = (ikinciCisimIcinMerkeznoktaXekseni - topX) * (ikinciCisimIcinMerkeznoktaXekseni - topX) + (ikinciCisimIcinMerkezNoktaYekseni - topY) * (ikinciCisimIcinMerkezNoktaYekseni - topY);
                float distanceToBottom = (ikinciCisimIcinMerkeznoktaXekseni - bottomX) * (ikinciCisimIcinMerkeznoktaXekseni - bottomX) + (ikinciCisimIcinMerkezNoktaYekseni - bottomY) * (ikinciCisimIcinMerkezNoktaYekseni - bottomY);

                if (distanceToLeft <= BirincicisminEniYaniXEkseni * BirincicisminEniYaniXEkseni / 4 || distanceToRight <= BirincicisminEniYaniXEkseni * BirincicisminEniYaniXEkseni / 4 || distanceToTop <= BirincicisminBoyuYaniYEkseni * BirincicisminBoyuYaniYEkseni / 4 || distanceToBottom <= BirincicisminBoyuYaniYEkseni * BirincicisminBoyuYaniYEkseni / 4)
                {
                    return true;
                }//kesişme var mı yok mu test eden kod
                else
                {
                    return false;
                }


            }



            public static void NoktaDikdortgenTesti(TextBox TBX, NumericUpDown Nmr1, NumericUpDown Nmr2, NumericUpDown Nmr3, NumericUpDown Nmr4, NumericUpDown Nmr5, NumericUpDown Nmr6, NumericUpDown Nmr7)//1_2
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)Nmr1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)Nmr2.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)Nmr3.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)Nmr4.Value;
                float ikinciCisminEniYaniXEkseni = (float)Nmr5.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)Nmr6.Value;
                if (birinciCisimIcinMerkeznoktaXekseni >= ikinciCisimIcinMerkeznoktaXekseni - ikinciCisminEniYaniXEkseni / 2 &&
                    birinciCisimIcinMerkeznoktaXekseni <= ikinciCisimIcinMerkeznoktaXekseni + ikinciCisminEniYaniXEkseni / 2 &&
                    birinciCisimIcinMerkezNoktaYekseni >= ikinciCisimIcinMerkezNoktaYekseni - ikinciCisminBoyuYaniYEkseni / 2 &&
                    birinciCisimIcinMerkezNoktaYekseni <= ikinciCisimIcinMerkezNoktaYekseni + ikinciCisminBoyuYaniYEkseni / 2)
                {
                    TBX.Text = "Kesisme var";
                }
                else
                {
                    TBX.Text = "Kesisme yok";//kesişme var mı yok mu test eden kod
                }
            }

            internal static void NoktaDikdortgenTesti(TextBox textBoxSonuc_1, NumericUpDown nokta2X_1, NumericUpDown nokta2Y_1, NumericUpDown kareIcınMerkezNoktaX_1, NumericUpDown kareIcınMerkezNoktaY_1, NumericUpDown kareIcınEn_1, NumericUpDown kareIcınBoy_1)
            {
                float birinciCisimIcinMerkeznoktaXekseni = (float)nokta2X_1.Value;
                float birinciCisimIcinMerkezNoktaYekseni = (float)nokta2Y_1.Value;
                float ikinciCisimIcinMerkeznoktaXekseni = (float)kareIcınMerkezNoktaX_1.Value;
                float ikinciCisimIcinMerkezNoktaYekseni = (float)kareIcınMerkezNoktaY_1.Value;
                float ikinciCisminEniYaniXEkseni = (float)kareIcınEn_1.Value;
                float ikinciCisminBoyuYaniYEkseni = (float)kareIcınBoy_1.Value;
                if (birinciCisimIcinMerkeznoktaXekseni >= ikinciCisimIcinMerkeznoktaXekseni - ikinciCisminEniYaniXEkseni / 2 &&
                    birinciCisimIcinMerkeznoktaXekseni <= ikinciCisimIcinMerkeznoktaXekseni + ikinciCisminEniYaniXEkseni / 2 &&
                    birinciCisimIcinMerkezNoktaYekseni >= ikinciCisimIcinMerkezNoktaYekseni - ikinciCisminBoyuYaniYEkseni / 2 &&
                    birinciCisimIcinMerkezNoktaYekseni <= ikinciCisimIcinMerkezNoktaYekseni + ikinciCisminBoyuYaniYEkseni / 2)
                {
                    textBoxSonuc_1.Text = "Kesisme var";
                }
                else
                {
                    textBoxSonuc_1.Text = "Kesisme yok";//kesişme var mı yok mu test eden kod
                }
            }
        }




       

        private void HesaplaVeÇiz_2_Click(object sender, EventArgs e)
        {


           
          
            Graphics grafik2 = this.CreateGraphics();
            grafik2.Clear(Color.White); //grafik nesnesi 
            int MerkezX = 500; 
            int MerkezY = 285;
            int yaricap1 = (int) CemberYaricap_2.Value;
            grafik2.DrawEllipse(Pens.Red, MerkezX - yaricap1 + (int)CemberMerkezXEkseni_2.Value, MerkezY - yaricap1 + (int)CemberMerkezYEkseni_2.Value, 2 * yaricap1, 2 * yaricap1);
            Pen Kalem = new Pen(Color.Blue, 2);
            grafik2.DrawLine(Kalem, 490+(int)NoktaXekseni_2.Value, 275+(int)NoktaYekseni_2.Value, 510+(int)NoktaXekseni_2.Value, 295+ (int)NoktaYekseni_2.Value);
            grafik2.DrawLine(Kalem, 490+ (int)NoktaXekseni_2.Value, 295 + (int)NoktaYekseni_2.Value, 510+ (int)NoktaXekseni_2.Value, 275 + (int)NoktaYekseni_2.Value); //çizgileri çizdir

            geometrikIslemler.NoktaCemberCarpismaDenetimi(SonucTextBox_2, NoktaXekseni_2, NoktaYekseni_2, CemberMerkezXEkseni_2, CemberMerkezYEkseni_2, CemberYaricap_2);

        }
      

        private void Hesapla_Ve_CİZ_3_Button_Click(object sender, EventArgs e)
        {
         

            Graphics grafik_3 = this.CreateGraphics();//grafik nesnesi  
            grafik_3.Clear(Color.White);
            int x = 400;
            int y = 185;
            grafik_3.DrawRectangle(Pens.Red, x + (int)Dikdortgen1Xekseni_3.Value, y+(int) Dikdortgen1Yekseni_3.Value, (int)Dikdortgen1Genislik_3.Value, (int)Dikdortgen1Uzunluk_3.Value); //rectangle çizdir
            grafik_3.DrawRectangle(Pens.Green, x+(int)Dikdortgen2Xekseni_3.Value, y+(int) Dikdortgen2Yekseni_3.Value, (int)Dikdortgen2Genislik_3.Value, (int)Dikdortgen2Uzunluk_3.Value);


            geometrikIslemler.dikdortgenDikdortgenCarpismaDenetimi(SonucTextBox_3, Dikdortgen1Xekseni_3, Dikdortgen1Yekseni_3, Dikdortgen1Genislik_3, Dikdortgen1Uzunluk_3, Dikdortgen2Xekseni_3, Dikdortgen2Yekseni_3, Dikdortgen2Genislik_3, Dikdortgen2Uzunluk_3);








        }

       

        private void Hesapla_Ve_Ciz_4_Click(object sender, EventArgs e)
        {
            
            


            



            Graphics grafik4 = this.CreateGraphics();
            grafik4.Clear(Color.White);
            int MerkezX = 500; //grafik nesnesi
            int MerkezY = 285;
            int yaricap1 = (int)CemberinizinYaricapi_4.Value;
            grafik4.DrawEllipse(Pens.Red, MerkezX - yaricap1 + (int)CemberinizinMerkeziXekseni_4.Value, MerkezY - yaricap1 + (int)CemberinizinMerkeziYekseni_4.Value, 2 * yaricap1, 2 * yaricap1);
            int x = 500 - (int)DikdortgeninEni_4.Value/ 2; //***
            int y = 285 - (int)DikdortgeninBoyu_4.Value / 2; //dikdrtgen çizdiriliyor

            // Dikdörtgeni çiz *****
            grafik4.DrawRectangle(Pens.Black, x+ (int)dikdortgenIcınMerkezNoktaX_4.Value, y+(int)DikdortgenIcınMerkezNoktaY_4.Value, (int)DikdortgeninEni_4.Value, (int)DikdortgeninBoyu_4.Value);

            if (geometrikIslemler.dikdortgenCemberCarpismaDenetimi(SonucTextBox_4, dikdortgenIcınMerkezNoktaX_4, DikdortgenIcınMerkezNoktaY_4, DikdortgeninEni_4, DikdortgeninBoyu_4, CemberinizinMerkeziXekseni_4, CemberinizinMerkeziYekseni_4, CemberinizinYaricapi_4) == true)
            {
                SonucTextBox_4.Text = "KESİSME VAR";
            }
            else   //fonksiyon ile kontrol yapan kod 
            {
                SonucTextBox_4.Text = "KESİSME YOK";
            }



        }

       

        

        private void Hesapla_Ve_Cizdir_5_Click(object sender, EventArgs e)
        {


            


            Graphics grafik5 = this.CreateGraphics();
            grafik5.Clear(Color.White);
            int MerkezX = 500; //
            int MerkezY = 285;
            int yaricap1 = (int)Cember1YARICAP_5.Value;
            grafik5.DrawEllipse(Pens.Red, MerkezX - yaricap1 + (int)Cember1MerkezXekseni_5.Value, MerkezY - yaricap1 + (int)Cember1MerkezYekseni_5.Value, 2 * yaricap1, 2 * yaricap1);//elips çizdir ve aynı yarıçapla çember elde et
            int yaricap2 = (int)Cember2YARICAP_5.Value;
            grafik5.DrawEllipse(Pens.Black, MerkezX - yaricap2 + (int)Cember2MerkezXekseni_5.Value, MerkezY - yaricap2 + (int)Cember2MerkezYekseni_5.Value, 2 * yaricap2, 2 * yaricap2);
            if(geometrikIslemler.CemberCemberCarpismaDenetimi(TextBoxSonuc_5,Cember1MerkezXekseni_5,Cember1MerkezYekseni_5,Cember1YARICAP_5,Cember2MerkezXekseni_5,Cember2MerkezYekseni_5,Cember2YARICAP_5) == true)
            {
                TextBoxSonuc_5.Text = "kesisim var";       
            }
            else //fonksiyona göre kesişim testi yapılıyor
            {
                TextBoxSonuc_5.Text = "kesisim yok";
            }








        }

      
       

       

        private void HesaplaVeCiz_6_Click(object sender, EventArgs e)
        {

            
            Graphics grafik6 = this.CreateGraphics();
            grafik6.Clear(Color.White);
            int centerX=500+(int)KureMerkezXEkseni_6.Value;
            int centerY=285+(int)KureMerkezYEkseni_6.Value;
            int yaricap = (int)KureYaricap_6.Value;
            Color color = Color.Red;
            for (int i = centerX - yaricap; i <= centerX + yaricap; i++) {
                for (int j = centerY - yaricap ; j <= centerY + yaricap;j++)
                {  //çember çiziliyor derinlikli
                    double distance = Math.Sqrt(Math.Pow(i - centerX, 2) + Math.Pow(j - centerY, 2));
                    if(distance <= yaricap)
                    {
                        int pixelDepth = (int)(255 - ((distance / yaricap) * 255));
                        Color pixelColor = Color.FromArgb(pixelDepth, color);
                        SolidBrush brush = new SolidBrush(pixelColor);
                        grafik6.FillRectangle(brush, i, j, 1, 1);

                    }






                }


            }
          
            Pen Kalem = new Pen(Color.Blue, 2);
            grafik6.DrawLine(Kalem, 490 + (int)NoktaXekseni_6.Value, 275 + (int)NoktaYekseni_6.Value, 510 + (int)NoktaXekseni_6.Value, 295 + (int)NoktaYekseni_6.Value);  //çarpı merkez nokta elde ediliyor
            grafik6.DrawLine(Kalem, 490 + (int)NoktaXekseni_6.Value, 295 + (int)NoktaYekseni_6.Value, 510 + (int)NoktaXekseni_6.Value, 275 + (int)NoktaYekseni_6.Value);



            if (geometrikIslemler.noktaKureCarpismaDenetimi(TextBoxSonuc_6,NoktaXekseni_6, NoktaYekseni_6, NoktaZekseni_6, KureMerkezXEkseni_6, KureMerkezYEkseni_6, KureMerkezZEkseni_6,KureYaricap_6) ==true)
            {
                TextBoxSonuc_6.Text = "kesişme var";//fonksiyona göre kesişim testi yapılıyor
            }
            else
            {
                TextBoxSonuc_6.Text = "kesişme yok";
            }




        }

      

        
      

       

        private void HesaplaVeÇizButton_7_Click(object sender, EventArgs e)
        {
            

            Graphics grafik7 = this.CreateGraphics();
            grafik7.Clear(Color.White);

            Pen Kalem = new Pen(Color.Blue, 2);
            grafik7.DrawLine(Kalem, 490 + (int)NoktaX_7.Value, 275 + (int)NoktaY_7.Value, 510 + (int)NoktaX_7.Value, 295 + (int)NoktaY_7.Value);
            grafik7.DrawLine(Kalem, 490 + (int)NoktaX_7.Value, 295 + (int)NoktaY_7.Value, 510 + (int)NoktaX_7.Value, 275 + (int)NoktaY_7.Value);

            Pen p = new Pen(Color.Black, 2);
            float merkezX = (float)(DikdortgenPrizmaMerkezX_7.Value + 500);
            float merkezY = (float)(DikdortgenPrizmaMerkezY_7.Value + 285);
            float boyutX = (float)DidortgenPrizmaEn_x_7.Value;
            float boyutY = (float)DidortgenPrizmaBoy_Y_7.Value;
            float boyutZ = (float)DidortgenPrizmaDerinlik_Z_7.Value;

            PointF[] ust = new PointF[4]; //dikdörtgen prizma için ust poligon
            ust[0]=new PointF(merkezX-boyutX/2, merkezY-boyutY/2);
            ust[1]=new PointF(merkezX+boyutX/2, merkezY-boyutY/2);
            ust[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            ust[3] = new PointF(merkezX-boyutX/2-boyutZ,merkezY-boyutY/2-boyutZ);
            grafik7.DrawPolygon(p, ust);

            PointF[] alt = new PointF[4];    //dikdörtgen prizma için alt poligon
            alt[0] = new PointF(merkezX - boyutX / 2, merkezY + boyutY / 2);
            alt[1] = new PointF(merkezX+boyutX/2,merkezY+boyutY/2);
            alt[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            alt[3] = new PointF(merkezX - boyutX / 2 -boyutZ,merkezY+boyutY/2-boyutZ);
            grafik7.DrawPolygon(p, alt);
            PointF[] kenar = new PointF[4];
            kenar[0] = ust[0];
            kenar[1] = alt[0];
            kenar[2] = alt[3];
            kenar[3] = ust[3];
            grafik7.DrawPolygon(p, kenar); //poligonlar çizdiriliyor
            kenar[0] = ust[1];
            kenar[1] = alt[1];
            kenar[2] = alt[2];
            kenar[3] = ust[2];
            grafik7.DrawPolygon(p, kenar);
            if(geometrikIslemler.noktaDikdortgenPrizmaCarpismaDenetimi(textBoxSonuc_7, NoktaX_7, NoktaY_7, NoktaZ_7,DikdortgenPrizmaMerkezX_7, DikdortgenPrizmaMerkezY_7, DikdortgenPrizmaMerkezZ_7, DidortgenPrizmaEn_x_7, DidortgenPrizmaBoy_Y_7, DidortgenPrizmaDerinlik_Z_7) == true)
            {
                textBoxSonuc_7.Text = "KESİŞİM VAR";
            }
            else//fonksiyona göre kesişim testi yapılıyor
            {
                textBoxSonuc_7.Text = "KESİŞİM yok";
            }

        }

        private void HesaplaVeCızButton_8_Click(object sender, EventArgs e)
        {
          


            Graphics grafik8 = this.CreateGraphics();
            grafik8.Clear(Color.White);
            Pen Kalem = new Pen(Color.Blue, 2);
            grafik8.DrawLine(Kalem, 490 + (int)NoktaXEkseni_8.Value, 275 + (int)NoktaYEkseni_8.Value, 510 + (int)NoktaXEkseni_8.Value, 295 + (int)NoktaYEkseni_8.Value); //çarpi ile nokta çizdiriliyor
            grafik8.DrawLine(Kalem, 490 + (int)NoktaXEkseni_8.Value, 295 + (int)NoktaYEkseni_8.Value, 510 + (int)NoktaXEkseni_8.Value, 275 + (int)NoktaYEkseni_8.Value);

            Pen p = new Pen(Color.Black, 2);
            int x= 500 + (int)SilindirXEkseni_8.Value;
            int y = 285 + (int)SilindirYEkseni_8.Value;
            int radius = (int)SilindirYariCap_8.Value;
            int height = (int)SilindirBoy_8.Value;

            //silindirimizin tabanı için olan fonksiyon 
            grafik8.DrawEllipse(p, x - radius, y - radius / 2, 2 * radius, radius);
            //silindirimizin üstü
            grafik8.DrawEllipse(p, x - radius, y + height - radius / 2, 2 * radius, radius);
            //silindirin yan yüzleri
            grafik8.DrawLine(p, x - radius, y, x - radius, y + height);
            grafik8.DrawLine(p, x + radius, y, x + radius, y + height); 
            grafik8.DrawLine(p,x-radius,y,x+radius,y);
            grafik8.DrawLine(p, x - radius, y + height, x + radius, y + height);


            geometrikIslemler.noktaSilindirCarpismaDenetimi(TextBoxSonuc_8,NoktaXEkseni_8, NoktaYEkseni_8, NoktaZEkseni_8,SilindirXEkseni_8, SilindirYEkseni_8, SilindirZEkseni_8,SilindirBoy_8,SilindirYariCap_8); //fonksiyon çağırıldı

            //fonksiyona çağırılıyor


        }

      
      

       

       

        private void Hesapla_ve_ciz_9_button_Click(object sender, EventArgs e)
        {
         


            Graphics grafik9 = this.CreateGraphics();
            grafik9.Clear(Color.White);

            Pen p1 = new Pen(Color.Black, 2);

            int x = 500 + (int)silindir1XMerkez_9.Value;
            int y = 285 + (int)silindir1YMerkez_9.Value;
            int radius = (int)silindir1Yaricap_9.Value;
            int height = (int)silindir1Boy_9.Value;

            // Silindirin tabanını çiz
            grafik9.DrawEllipse(p1, x - radius, y - radius / 2, 2 * radius, radius);

            // Silindirin üstünü çiz
            grafik9.DrawEllipse(p1, x - radius, y + height - radius / 2, 2 * radius, radius);

            // Silindirin yanını çiz
            grafik9.DrawLine(p1, x - radius, y, x - radius, y + height);
            grafik9.DrawLine(p1, x + radius, y, x + radius, y + height);
            grafik9.DrawLine(p1, x - radius, y, x + radius, y);
            grafik9.DrawLine(p1, x - radius, y + height, x + radius, y + height);



            Pen p2 = new Pen(Color.Red, 2);

            int x2 = 500 + (int)silindir2XMerkez_9.Value;
            int y2 = 285 + (int)silindir2YMerkez_9.Value;
            int radius2 = (int)silindir2Yaricap_9.Value;
            int height2 = (int)silindir2Boy_9.Value;

            // Silindirin tabanını çiz
            grafik9.DrawEllipse(p2, x2 - radius2, y2 - radius2 / 2, 2 * radius2, radius2);

            // Silindirin üstünü çiz
            grafik9.DrawEllipse(p2, x2 - radius2, y2 + height2 - radius2 / 2, 2 * radius2, radius2);

            // Silindirin yanını çiz
            grafik9.DrawLine(p2, x2 - radius2, y2, x2 - radius2, y2 + height2);
            grafik9.DrawLine(p2, x2 + radius2, y2, x2 + radius2, y2 + height2);
            grafik9.DrawLine(p2, x2 - radius2, y2, x2 + radius2, y2);
            grafik9.DrawLine(p2, x2 - radius2, y2 + height2, x2 + radius2, y2 + height2);

            geometrikIslemler.silindirSilindirCarpismaDenetimi(textBoxSonuc_9, silindir1XMerkez_9, silindir1YMerkez_9, silindir1ZMerkez_9, silindir1Boy_9, silindir1Boy_9, silindir2XMerkez_9, silindir2YMerkez_9, silindir2ZMerkez_9, silindir2Boy_9, silindir2Boy_9);


            //fonksiyon çağırılıyor








        }

       
        private void hesapla_ve_cız_button_10_Click(object sender, EventArgs e)
        {
           
           

            Graphics grafik10 = this.CreateGraphics();
            grafik10.Clear(Color.White);
            int merkezX = 500 + (int)Kure1Xekseni_10.Value;
            int merkezY = 285 + (int)Kure1Yekseni_10.Value;
            int yaricap = (int)Kure1Yaricap_10.Value;
            Color color = Color.Red;
            for (int i = merkezX - yaricap; i <= merkezX + yaricap; i++)
            {
                for (int j = merkezY - yaricap; j <= merkezY + yaricap; j++)
                {
                    double mesafe = Math.Sqrt(Math.Pow(i - merkezX, 2) + Math.Pow(j - merkezY, 2));
                    if (mesafe <= yaricap) //kure çiziliyor
                    {
                        int pixelDepth = (int)(255 - ((mesafe / yaricap) * 255));
                        Color pixelColor = Color.FromArgb(pixelDepth, color);
                        SolidBrush brush = new SolidBrush(pixelColor);
                        grafik10.FillRectangle(brush, i, j, 1, 1);

                    }






                }


            }


            int merkezX2 = 500 + (int)Kure2Xekseni_10.Value; //kure çiziliyor
            int merkezY2 = 285 + (int)Kure2Yekseni_10.Value;
            int yaricap2 = (int)Kure2Yaricap_10.Value;
            Color color2 = Color.Blue;
            for (int i = merkezX2 - yaricap2; i <= merkezX2 + yaricap2; i++)
            {
                for (int j = merkezY2 - yaricap2; j <= merkezY2 + yaricap2; j++)
                {
                    double mesafe2 = Math.Sqrt(Math.Pow(i - merkezX2, 2) + Math.Pow(j - merkezY2, 2));
                    if (mesafe2 <= yaricap2)
                    {
                        int pixelDepth2 = (int)(255 - ((mesafe2 / yaricap2) * 255));
                        Color pixelColor2 = Color.FromArgb(pixelDepth2, color2);
                        SolidBrush brush2 = new SolidBrush(pixelColor2);
                        grafik10.FillRectangle(brush2, i, j, 1, 1);

                    }






                }


            }


            geometrikIslemler.kureKureCarpsimaDenetimi(textBoxSonuc_10,Kure1Xekseni_10,Kure1Yekseni_10, Kureniz1Zekseni_10, Kure1Yaricap_10, Kure2Xekseni_10, Kure2Yekseni_10, Kure2Zekseni_10, Kure2Yaricap_10);


            //fonksiyon çağırıldı


















        }

        private void Hesapla_ve_Ciz_11_Click(object sender, EventArgs e)
        {
           
            
        

            Graphics grafik11 = this.CreateGraphics();
            grafik11.Clear(Color.White);
            int centerX = 500 + (int)KureMerkezX_11.Value;
            int centerY = 285 + (int)KureMerkezY_11.Value;
            int yaricap = (int)KureYaricap_11.Value;
            Color color = Color.Red;
            for (int i = centerX - yaricap; i <= centerX + yaricap; i++)
            {
                for (int j = centerY - yaricap; j <= centerY + yaricap; j++)
                {
                    double distance = Math.Sqrt(Math.Pow(i - centerX, 2) + Math.Pow(j - centerY, 2));
                    if (distance <= yaricap)
                    { //küre çizliyor
                        int pixelDepth = (int)(255 - ((distance / yaricap) * 255));
                        Color pixelColor = Color.FromArgb(pixelDepth, color);
                        SolidBrush brush = new SolidBrush(pixelColor);
                        grafik11.FillRectangle(brush, i, j, 1, 1);

                    }
                    //küre çiziliyor





                }


            }


            Pen p1 = new Pen(Color.Black, 2);

            int x = 500 + (int)SilindirMekrezX_11.Value;
            int y = 285 + (int)SilindirMekrezY_11.Value;
            int radius = (int)SilindirYaricap_11.Value;
            int height = (int)SilindirBoy_11.Value;

            // Silindirin tabanını çiz
            grafik11.DrawEllipse(p1, x - radius, y - radius / 2, 2 * radius, radius);

            // Silindirin üstünü çiz
            grafik11.DrawEllipse(p1, x - radius, y + height - radius / 2, 2 * radius, radius);

            // Silindirin yanını çiz
            grafik11.DrawLine(p1, x - radius, y, x - radius, y + height);
            grafik11.DrawLine(p1, x + radius, y, x + radius, y + height);
            grafik11.DrawLine(p1, x - radius, y, x + radius, y);
            grafik11.DrawLine(p1, x - radius, y + height, x + radius, y + height);




            geometrikIslemler.kureSilindirCarpismaDenetimi(textBoxSonuc_11,KureMerkezX_11, KureMerkezY_11, KureMerkezZ_11,KureYaricap_11,SilindirMekrezX_11, SilindirMekrezY_11, SilindirMekrezZ_11,SilindirBoy_11,SilindirYaricap_11);



            //fonksiyon çağırılıyor


        }

        private void Hesapla_ve_Ciz_button_12_Click(object sender, EventArgs e)
        {

        Graphics grafik12 = this.CreateGraphics();
        grafik12.Clear(Color.White);

            float x = (float)YuzeyMerkezX_12.Value;
            float y = (float)YuzeyMerkezY_12.Value;
            float z = (float)YuzeyMerkezZ_12.Value;
            float a = (float)YuzeyYaricap_12.Value;
            float radius = a / 2f;


            //koordinat dönüşümü

            float screenX = x + 500;
            float screenY = 285 + y;

            grafik12.DrawEllipse(Pens.Black, screenX - a, screenY - radius, 2 * a, 2 * radius);



            int centerX = 500 + (int)KureMerkezX_12.Value;
            int centerY = 285 + (int)KureMerkezX_12.Value;
            int yaricap = (int)KureYaricap_12.Value;
            Color color = Color.Red;
            for (int i = centerX - yaricap; i <= centerX + yaricap; i++)
            {
                for (int j = centerY - yaricap; j <= centerY + yaricap; j++)
                {
                    double distance = Math.Sqrt(Math.Pow(i - centerX, 2) + Math.Pow(j - centerY, 2));
                    if (distance <= yaricap)
                    {
                        int pixelDepth = (int)(255 - ((distance / yaricap) * 255));
                        Color pixelColor = Color.FromArgb(pixelDepth, color);
                        SolidBrush brush = new SolidBrush(pixelColor);
                        grafik12.FillRectangle(brush, i, j, 1, 1);

                    }






                }


            }




            geometrikIslemler.yuzeyKureCarpismaDenetimi(textBoxSobuc_12, YuzeyMerkezX_12, YuzeyMerkezY_12, YuzeyMerkezZ_12, YuzeyYaricap_12, KureMerkezX_12, KureMerkezY_12, KureMerkezZ_12, KureYaricap_12);



            //fonksiyona çağırılıyor
















        }

        private void HesaplaVeCiz_13_Click(object sender, EventArgs e)
        {

            

            Graphics grafik13 = this.CreateGraphics();
            grafik13.Clear(Color.White);


            float x = (float)YuzeyMerkezX_13.Value;
            float y = (float)YuzeyMerkezY_13.Value;
            float z = (float)YuzeyMerkezZ_13.Value;
            float a = (float)Yyaricap_13.Value;
            float b = a / 2f; // Elipsin yarıçapı
            float screenX = x + 500;
            float screenY = 285 + y;
            grafik13.DrawEllipse(Pens.Black, screenX - a, screenY - b, 2 * a, 2 * b);


            Pen p = new Pen(Color.Black, 2);
            float merkezX = (float)(DikdortgenPrizmaMerkezX_13.Value + 500);
            float merkezY = (float)(DikdortgenPrizmaMerkezY_13.Value + 285);
            float boyutX = (float)DikdortgenPrizmaEn_13.Value;
            float boyutY = (float)DikdortgenPrizmaBoy_13.Value;
            float boyutZ = (float)DikdortgenPrizmaDerinlik_13.Value;

            PointF[] ust = new PointF[4];//üst poligon
            ust[0] = new PointF(merkezX - boyutX / 2, merkezY - boyutY / 2);
            ust[1] = new PointF(merkezX + boyutX / 2, merkezY - boyutY / 2);
            ust[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            ust[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            grafik13.DrawPolygon(p, ust);

            PointF[] alt = new PointF[4];//alt poligon
            alt[0] = new PointF(merkezX - boyutX / 2, merkezY + boyutY / 2);
            alt[1] = new PointF(merkezX + boyutX / 2, merkezY + boyutY / 2);
            alt[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            alt[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            grafik13.DrawPolygon(p, alt);
            PointF[] kenar = new PointF[4];
            kenar[0] = ust[0];
            kenar[1] = alt[0];
            kenar[2] = alt[3];
            kenar[3] = ust[3];
            grafik13.DrawPolygon(p, kenar);
            kenar[0] = ust[1];
            kenar[1] = alt[1];
            kenar[2] = alt[2];
            kenar[3] = ust[2];
            grafik13.DrawPolygon(p, kenar);

            if (geometrikIslemler.yuzeyDikdortgenPrizmaCarpismaDenetimi(textBoxSonuc_13,YuzeyMerkezX_13, YuzeyMerkezY_13, YuzeyMerkezZ_13, Yyaricap_13 ,DikdortgenPrizmaMerkezX_13, DikdortgenPrizmaMerkezY_13, DikdortgenPrizmaMerkezZ_13, DikdortgenPrizmaEn_13, DikdortgenPrizmaBoy_13, DikdortgenPrizmaDerinlik_13) == true)
            {
                textBoxSonuc_13.Text = "KESİSME VAR";
            } //fonksiyon ile kesişim testi yapılıyor 
            else
            {
                textBoxSonuc_13.Text = "KESİSME YOK";
            }















        }

        private void Hesapla_VE_Ciz_14_Click(object sender, EventArgs e)
        {

          






         ;


            Graphics grafik14 = this.CreateGraphics();
            grafik14.Clear(Color.White);

            float x = (float)YuzeyMerkezX_14.Value;
            float y = (float)YuzeyMerkezY_14.Value;
            float z = (float)YuzeyMerkezZ_14.Value;
            float a = (float)YuzeyYaricap_14.Value;
            float b = a / 2f; // Elipsin yarıçapı



            // Koordinat dönüşümü
            float screenX = x + 500;
            float screenY = 285 + y;

            // Elipsi çiz
            grafik14.DrawEllipse(Pens.Black, screenX - a, screenY - b, 2 * a, 2 * b);



            Pen p1 = new Pen(Color.Black, 2);
            int x2 = 500 + (int)SilindirMerkezX_14.Value;
            int y2 = 285 + (int)SilindirMerkezY_14.Value;
            int radius2 = (int)SilindirYaricap_14.Value;  //silindir değişkenleir
            int height2 = (int)SilindirBoy_14.Value;

            // Silindirin tabanını çiz
            grafik14.DrawEllipse(p1, x2 - radius2, y2 - radius2 / 2, 2 * radius2, radius2); 

            // Silindirin üstünü çiz
            grafik14.DrawEllipse(p1, x2 - radius2, y2 + height2 - radius2 / 2, 2 * radius2, radius2);

            // Silindirin yanını çiz
            grafik14.DrawLine(p1, x2 - radius2, y2, x2 - radius2, y2 + height2);
            grafik14.DrawLine(p1, x2 + radius2, y2, x2 + radius2, y2 + height2);
            grafik14.DrawLine(p1, x2 - radius2, y2, x2 + radius2, y2);
            grafik14.DrawLine(p1, x2 - radius2, y2 + height2, x2 + radius2, y2 + height2);



            if (geometrikIslemler.yuzeySilindirCarpismaDenetimi(textBoxSonuc_14, YuzeyMerkezX_14, YuzeyMerkezY_14, YuzeyMerkezZ_14, YuzeyYaricap_14, SilindirMerkezX_14, SilindirMerkezY_14, SilindirMerkezZ_14, SilindirBoy_14, SilindirYaricap_14))
            {
                textBoxSonuc_14.Text = "kesişim var";
            }
            else
            { //fonksiyonlar ile kesişim testi yapılıyor
                textBoxSonuc_14.Text = "kesişim yok";
            }








        }

        private void Hesapla_ve_ciz_15_button_Click(object sender, EventArgs e)
        {

           

            Graphics grafik15 = this.CreateGraphics();
            grafik15.Clear(Color.White);
            int centerX = 500 + (int)KureMerkezNoktaX_15.Value;
            int centerY = 285 + (int)KureMerkezNoktaY_15.Value;
            int yaricap = (int)KureYaricap_15.Value;
            Color color = Color.Red;
            for (int i = centerX - yaricap; i <= centerX + yaricap; i++)
            {
                for (int j = centerY - yaricap; j <= centerY + yaricap; j++)
                {
                    double distance = Math.Sqrt(Math.Pow(i - centerX, 2) + Math.Pow(j - centerY, 2));
                    if (distance <= yaricap)
                    { //küre çiziliyor
                        int pixelDepth = (int)(255 - ((distance / yaricap) * 255));
                        Color pixelColor = Color.FromArgb(pixelDepth, color);
                        SolidBrush brush = new SolidBrush(pixelColor);
                        grafik15.FillRectangle(brush, i, j, 1, 1);

                    }






                }


            }

            Pen p = new Pen(Color.Black, 2);
            float merkezX = (float)(DikdortgenPrizmaMerkezX_15.Value + 500);
            float merkezY = (float)(DikdortgenPrizmaMerkezY_15.Value + 285);
            float boyutX = (float)DikdortgenPrizmaEn_15.Value;
            float boyutY = (float)DikdortgenPrizmaBOY_15.Value;
            float boyutZ = (float)DikdortgenPrizmaDERİNLİK_15.Value;

            PointF[] ust = new PointF[4];
            ust[0] = new PointF(merkezX - boyutX / 2, merkezY - boyutY / 2);
            ust[1] = new PointF(merkezX + boyutX / 2, merkezY - boyutY / 2);
            ust[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            ust[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            grafik15.DrawPolygon(p, ust);

            PointF[] alt = new PointF[4];
            alt[0] = new PointF(merkezX - boyutX / 2, merkezY + boyutY / 2);
            alt[1] = new PointF(merkezX + boyutX / 2, merkezY + boyutY / 2);
            alt[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            alt[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            grafik15.DrawPolygon(p, alt);
            PointF[] kenar = new PointF[4];
            kenar[0] = ust[0];
            kenar[1] = alt[0];
            kenar[2] = alt[3];
            kenar[3] = ust[3]; //dikdortgen prizma çiziliyor
            grafik15.DrawPolygon(p, kenar);
            kenar[0] = ust[1];
            kenar[1] = alt[1];
            kenar[2] = alt[2];
            kenar[3] = ust[2];
            grafik15.DrawPolygon(p, kenar);



            if (geometrikIslemler.kureDikdortgenPrizmaCarpismaDenetimi(textBoxSonuc_15, KureMerkezNoktaX_15, KureMerkezNoktaY_15, KureMerkezNoktaZ_15, KureYaricap_15, DikdortgenPrizmaMerkezX_15, DikdortgenPrizmaMerkezY_15, DikdortgenPrizmaMerkezZ_15, DikdortgenPrizmaEn_15, DikdortgenPrizmaBOY_15, DikdortgenPrizmaDERİNLİK_15) == true)
            {
                textBoxSonuc_15.Text = "kesişme var";
            } //fonksiyon ile kesişim testi yapılyıor
            else
            {
                textBoxSonuc_15.Text = "kesişme yok";
            }

















        }

        private void HesaplaVeCizdir_16_Click(object sender, EventArgs e)
        {

          
            



            Graphics grafik16 = this.CreateGraphics();
            grafik16.Clear(Color.White);

            Pen p = new Pen(Color.Black, 2);
            float merkezX = (float)(DidkortgenPrizma1X_16.Value + 500);
            float merkezY = (float)(DidkortgenPrizma1Y_16.Value + 285);
            float boyutX = (float)DikdortgrnPrizma1EN_16.Value;
            float boyutY = (float)DikdortgrnPrizma1BOY_16.Value;
            float boyutZ = (float)DikdortgrnPrizma1DERİNLİK_16.Value;

            PointF[] ust = new PointF[4];
            ust[0] = new PointF(merkezX - boyutX / 2, merkezY - boyutY / 2);
            ust[1] = new PointF(merkezX + boyutX / 2, merkezY - boyutY / 2);
            ust[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            ust[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            grafik16.DrawPolygon(p, ust);

            PointF[] alt = new PointF[4];
            alt[0] = new PointF(merkezX - boyutX / 2, merkezY + boyutY / 2);
            alt[1] = new PointF(merkezX + boyutX / 2, merkezY + boyutY / 2);
            alt[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            alt[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            grafik16.DrawPolygon(p, alt);
            PointF[] kenar = new PointF[4];
            kenar[0] = ust[0];
            kenar[1] = alt[0];
            kenar[2] = alt[3];
            kenar[3] = ust[3];
            grafik16.DrawPolygon(p, kenar);
            kenar[0] = ust[1];
            kenar[1] = alt[1];
            kenar[2] = alt[2];
            kenar[3] = ust[2];
            grafik16.DrawPolygon(p, kenar);
            //////
            ///
            Pen p1 = new Pen(Color.Red, 2);
            float merkezX1 = (float)(DidkortgenPrizma2X_16.Value + 500);
            float merkezY1 = (float)(DidkortgenPrizma2Y_16.Value + 285);
            float boyutX1 = (float)DikdortgrnPrizma2EN_16.Value;
            float boyutY1 = (float)DikdortgrnPrizma2BOY_16.Value;
            float boyutZ1 = (float)DikdortgrnPrizma2DERİNLİK_16.Value;

            PointF[] ust1 = new PointF[4];
            ust1[0] = new PointF(merkezX1 - boyutX1 / 2, merkezY1 - boyutY1 / 2);
            ust1[1] = new PointF(merkezX1 + boyutX1 / 2, merkezY1 - boyutY1 / 2);
            ust1[2] = new PointF(merkezX1 + boyutX1 / 2 - boyutZ1, merkezY1 - boyutY1 / 2 - boyutZ1);
            ust1[3] = new PointF(merkezX1 - boyutX1 / 2 - boyutZ1, merkezY1 - boyutY1 / 2 - boyutZ1);
            grafik16.DrawPolygon(p1, ust1);

            PointF[] alt1 = new PointF[4];
            alt1[0] = new PointF(merkezX1 - boyutX1 / 2, merkezY1 + boyutY1 / 2);
            alt1[1] = new PointF(merkezX1 + boyutX1 / 2, merkezY1 + boyutY1 / 2);
            alt1[2] = new PointF(merkezX1 + boyutX1 / 2 - boyutZ1, merkezY1 + boyutY1 / 2 - boyutZ1);
            alt1[3] = new PointF(merkezX1 - boyutX1 / 2 - boyutZ1, merkezY1 + boyutY1 / 2 - boyutZ1);
            grafik16.DrawPolygon(p1, alt1);
            PointF[] kenar1 = new PointF[4];
            kenar1[0] = ust1[0];
            kenar1[1] = alt1[0];
            kenar1[2] = alt1[3];
            kenar1[3] = ust1[3];
            grafik16.DrawPolygon(p1, kenar1);
            kenar1[0] = ust1[1];
            kenar1[1] = alt1[1];
            kenar1[2] = alt1[2];
            kenar1[3] = ust1[2];
            grafik16.DrawPolygon(p1, kenar1);
            geometrikIslemler.DikdortgenPrizmaCarpismaDenetimi(textBoxSonuc_16, DidkortgenPrizma1X_16, DidkortgenPrizma1Y_16, DidkortgenPrizma1Z_16, DikdortgrnPrizma1EN_16, DikdortgrnPrizma1BOY_16, DikdortgrnPrizma1DERİNLİK_16, DidkortgenPrizma2X_16, DidkortgenPrizma2Y_16, DidkortgenPrizma2Z_16, DikdortgrnPrizma2EN_16, DikdortgrnPrizma2BOY_16, DikdortgrnPrizma2DERİNLİK_16);









        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            Graphics grafik1 = this.CreateGraphics();
            grafik1.Clear(Color.White);

            int originX = 500 + (int)YamukMerkezNoktaX_1.Value;
            int originY = 285 + (int)YamukMerkezNoktaY_1.Value;
            int width = (int)YamukEN_1.Value; // yamuk genişliği
            int height = (int)YamukBOY_1.Value; // yamuk yüksekliği
            float rotationAngle = (int)YamukEGIM_1.Value; // yamuk dönüş açısı
                                                          // Yamuk merkezinin konumu
            float centerX = originX + width / 2;
            float centerY = originY + height / 2;
            // Yamuk kenar noktalarının koordinatlarını hesapla
            float leftX = centerX - (float)Math.Cos(rotationAngle * Math.PI / 180) * width / 2;
            float leftY = centerY - (float)Math.Sin(rotationAngle * Math.PI / 180) * width / 2;
            float rightX = centerX + (float)Math.Cos(rotationAngle * Math.PI / 180) * width / 2;
            float rightY = centerY + (float)Math.Sin(rotationAngle * Math.PI / 180) * width / 2;
            float topX = centerX - (float)Math.Sin(rotationAngle * Math.PI / 180) * height / 2;
            float topY = centerY + (float)Math.Cos(rotationAngle * Math.PI / 180) * height / 2;
            float bottomX = centerX + (float)Math.Sin(rotationAngle * Math.PI / 180) * height / 2;
            float bottomY = centerY - (float)Math.Cos(rotationAngle * Math.PI / 180) * height / 2;
            // Yamuk kenarlarını çiz
            Pen pen = new Pen(Color.Black, 2);
            grafik1.DrawLine(pen, leftX, leftY, topX, topY);
            grafik1.DrawLine(pen, topX, topY, rightX, rightY);
            grafik1.DrawLine(pen, rightX, rightY, bottomX, bottomY);
            grafik1.DrawLine(pen, bottomX, bottomY, leftX, leftY);



            Pen Kalem = new Pen(Color.Blue, 2);
            grafik1.DrawLine(Kalem, 490 + (int)Nokta1X_1.Value, 275 + (int)Nokta1Y_1.Value, 510 + (int)Nokta1X_1.Value, 295 + (int)Nokta1Y_1.Value);
            grafik1.DrawLine(Kalem, 490 + (int)Nokta1X_1.Value, 295 + (int)Nokta1Y_1.Value, 510 + (int)Nokta1X_1.Value, 275 + (int)Nokta1Y_1.Value);

            if (geometrikIslemler.NoktaYamukKesismeTesti(textBoxSonuc_1, YamukMerkezNoktaX_1, YamukMerkezNoktaY_1, YamukEN_1, YamukBOY_1, YamukEGIM_1, Nokta1X_1, Nokta1Y_1) == true)
            {
                textBoxSonuc_1.Text = "kesişim var";
            }
            else
            {
                textBoxSonuc_1.Text = "kesişim yok";
            }










        }
        

       
        private void HesaplaVeCizdir2_1_Click(object sender, EventArgs e)
        {

           
            Graphics grafik2_1 = this.CreateGraphics();
            grafik2_1.Clear(Color.White);

            Pen Kalem = new Pen(Color.Blue, 2);
            float dikdortgenMerkezNoktaX = 500 + (float)KareIcınMerkezNoktaX_1.Value;
            float dikdortgenMerkezNoktaY = 285 + (float)KareIcınMerkezNoktaY_1.Value;
            float dikdortgenYarisiX = (float)KareIcınEn_1.Value / 2;
            float dikdortgenYarisiY = (float)KareIcınBoy_1.Value / 2;
            float noktaX = dikdortgenMerkezNoktaX - dikdortgenYarisiX;
            float noktaY = dikdortgenMerkezNoktaY - dikdortgenYarisiY;

            grafik2_1.DrawRectangle(Kalem, noktaX, noktaY, (float)KareIcınEn_1.Value, (float)KareIcınBoy_1.Value);
            int x = 500 + (int)Nokta2X_1.Value;
            int y = 285 + (int)Nokta2Y_1.Value; ;

            // Noktanın boyutu
            int size = 5;

            // Çizim işlemi
            Pen kalem = new Pen(Color.Black);
            grafik2_1.DrawEllipse(kalem, x - size / 2, y - size / 2, size, size);


            geometrikIslemler.NoktaDikdortgenTesti(textBoxSonuc11_2, Nokta2X_1, Nokta2Y_1, KareIcınMerkezNoktaX_1, KareIcınMerkezNoktaY_1, KareIcınEn_1, KareIcınBoy_1);


            //fonksiyon çağırılıyor


        }

      

        private void Cizdir_list_Click(object sender, EventArgs e)
        {
            //YAMUK_1

            Graphics grafik2_1 = this.CreateGraphics();
            grafik2_1.Clear(Color.White);
            int originX = 100;
            int originY = 100;
            int width = 100; // yamuk genişliği
            int height = 80; // yamuk yüksekliği
            float rotationAngle = 30; // yamuk dönüş açısı

            float centerX = originX + width / 2;
            float centerY = originY + height / 2;
            // Yamuk kenar noktalarının koordinatlarını hesapla
            float leftX = centerX - (float)Math.Cos(rotationAngle * Math.PI / 180) * width / 2;
            float leftY = centerY - (float)Math.Sin(rotationAngle * Math.PI / 180) * width / 2;
            float rightX = centerX + (float)Math.Cos(rotationAngle * Math.PI / 180) * width / 2;
            float rightY = centerY + (float)Math.Sin(rotationAngle * Math.PI / 180) * width / 2;
            float topX = centerX - (float)Math.Sin(rotationAngle * Math.PI / 180) * height / 2;
            float topY = centerY + (float)Math.Cos(rotationAngle * Math.PI / 180) * height / 2;
            float bottomX = centerX + (float)Math.Sin(rotationAngle * Math.PI / 180) * height / 2;
            float bottomY = centerY - (float)Math.Cos(rotationAngle * Math.PI / 180) * height / 2;

            GraphicsPath path = new GraphicsPath();
            path.AddLine(leftX, leftY, topX, topY);
            path.AddLine(topX, topY, rightX, rightY);
            path.AddLine(rightX, rightY, bottomX, bottomY);
            path.AddLine(bottomX, bottomY, leftX, leftY);
            List<GraphicsPath> paths = new List<GraphicsPath>();
            paths.Add(path);//path ekle
            //NOKTA_2
            int x = 100;
            int y = 200;

            // Noktanın boyutu
            int size = 9;


            Pen kalem = new Pen(Color.Black);
            GraphicsPath path2 = new GraphicsPath();
            path2.AddEllipse(x - size / 2, y - size / 2, size, size);
            paths.Add(path2);//path ekle

            //dikdörtgen_3

            float dikdortgenMerkezNoktaX = 100;
            float dikdortgenMerkezNoktaY = 300;
            float dikdortgenYarisiX = 130 / 2;
            float dikdortgenYarisiY = 80 / 2;
            float noktaX = dikdortgenMerkezNoktaX - dikdortgenYarisiX;
            float noktaY = dikdortgenMerkezNoktaY - dikdortgenYarisiY;
            GraphicsPath path3 = new GraphicsPath();
            path3.AddRectangle(new RectangleF(noktaX, noktaY, 130, 80));//rectange ekle
            paths.Add(path3);//path ekle

            //Cember_4
            int MerkezX = 250;
            int MerkezY = 60;
            int yaricap1 = 60;
            GraphicsPath path4 = new GraphicsPath();
            path4.AddEllipse(MerkezX - yaricap1, MerkezY - yaricap1, 2 * yaricap1, 2 * yaricap1);//ellipse ekle
            paths.Add(path4); //path ekle
            //Nokta2_5
            GraphicsPath path5 = new GraphicsPath();
            path5.AddLine(490, 275, 510, 295);
            path5.AddLine(490, 295, 510, 275);
            paths.Add(path5);
            //dikdortgen Prizma_7
            float merkezX = (float)(700);
            float merkezY = (float)(285);
            float boyutX = (float)90;
            float boyutY = (float)70;
            float boyutZ = (float)100;


            PointF[] ust = new PointF[4];
            ust[0] = new PointF(merkezX - boyutX / 2, merkezY - boyutY / 2);
            ust[1] = new PointF(merkezX + boyutX / 2, merkezY - boyutY / 2);
            ust[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);
            ust[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY - boyutY / 2 - boyutZ);


            PointF[] alt = new PointF[4];
            alt[0] = new PointF(merkezX - boyutX / 2, merkezY + boyutY / 2);
            alt[1] = new PointF(merkezX + boyutX / 2, merkezY + boyutY / 2);
            alt[2] = new PointF(merkezX + boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);
            alt[3] = new PointF(merkezX - boyutX / 2 - boyutZ, merkezY + boyutY / 2 - boyutZ);

            PointF[] kenar = new PointF[4];
            kenar[0] = ust[0];
            kenar[1] = alt[0];
            kenar[2] = alt[3];
            kenar[3] = ust[3];

            GraphicsPath path6 = new GraphicsPath();
            path6.AddPolygon(ust);//poligon ekle
            paths.Add(path6);//path ekle
            GraphicsPath path7 = new GraphicsPath();
            path7.AddPolygon(alt);//poligon ekle
            paths.Add(path7);//path ekle

            GraphicsPath path8 = new GraphicsPath();
            path8.AddPolygon(kenar); //poligon ekle
            paths.Add(path8);//path ekle

            kenar = new PointF[4];
            kenar[0] = ust[1];
            kenar[1] = alt[1];
            kenar[2] = alt[2];
            kenar[3] = ust[2];

            GraphicsPath path9 = new GraphicsPath();
            path9.AddPolygon(kenar);
            paths.Add(path9);
            //silindir_8
            x = 300;
            y = 300;
            int radius = 50;
            height = 130;
            GraphicsPath path10 = new GraphicsPath();
            path10.AddEllipse(x - size / 2, y - size / 2, size, size);
            path.CloseFigure(); //patika kapandı 
            paths.Add(path10);

            GraphicsPath path11 = new GraphicsPath();
            path11.AddEllipse(x - radius, y - radius / 2, 2 * radius, radius);
            path11.CloseFigure(); // patika kapandı
            paths.Add(path11);
            GraphicsPath path13 = new GraphicsPath();
            path13.AddLine(x - radius, y, x - radius, y + height);
            path13.AddLine(x + radius, y, x + radius, y + height);
            path13.AddLine(x - radius, y, x + radius, y);
            path13.AddLine(x - radius, y + height, x + radius, y + height);
            path13.CloseFigure(); // patika kapandı
            paths.Add(path13);
            //yuzey_8
            x = 600;
            y = 400;
            float z = 60;
            int a = 30;
            radius = a / 2;


            //koordinat dönüşümü

            float screenX = x;
            float screenY = y;
            GraphicsPath path14 = new GraphicsPath();
            path14.AddEllipse(screenX - a, screenY - radius, 2 * a, 2 * radius);
            paths.Add(path14);

            foreach (GraphicsPath p in paths)
            {
                Pen YamukP = new Pen(Color.Black, 2);
                grafik2_1.DrawPath(YamukP, p);
                Pen Nokta1P = new Pen(Color.Black, 2);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p); //foreach ile pathler çizdiriliyor
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);
                grafik2_1.DrawPath(Nokta1P, p);

            }

            //kurem renk derinligi içerdiği için List içerisinde saklanmaya uygun değil bu yüzden direkt çizdireceğim
            centerX = 400;
            centerY = 60;
            int yaricap = 50;
            Color color = Color.Red;
            for (int i = (int)centerX - yaricap; i <= centerX + yaricap; i++)
            {
                for (int j = (int)centerY - yaricap; j <= centerY + yaricap; j++)
                {
                    double distance = Math.Sqrt(Math.Pow(i - centerX, 2) + Math.Pow(j - centerY, 2));
                    if (distance <= yaricap)
                    {
                        int pixelDepth = (int)(255 - ((distance / yaricap) * 255));
                        Color pixelColor = Color.FromArgb(pixelDepth, color);
                        SolidBrush brush = new SolidBrush(pixelColor); //küre çiziliyor
                        grafik2_1.FillRectangle(brush, i, j, 1, 1);

                    }






                }


            }


        }
    }











        }
    
