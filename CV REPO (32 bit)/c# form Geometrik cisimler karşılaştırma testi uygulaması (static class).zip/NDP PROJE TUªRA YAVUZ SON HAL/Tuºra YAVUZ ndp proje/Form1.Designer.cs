﻿namespace Tuğra_YAVUZ_ndp_proje
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.NoktaDortgenCarpisma = new System.Windows.Forms.TabPage();
            this.textBoxSonuc11_2 = new System.Windows.Forms.TextBox();
            this.HesaplaVeCizdir2_1 = new System.Windows.Forms.Button();
            this.label144 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.textBoxSonuc_1 = new System.Windows.Forms.TextBox();
            this.KareIcınMerkezNoktaX_1 = new System.Windows.Forms.NumericUpDown();
            this.YamukMerkezNoktaX_1 = new System.Windows.Forms.NumericUpDown();
            this.YamukEGIM_1 = new System.Windows.Forms.NumericUpDown();
            this.Nokta2X_1 = new System.Windows.Forms.NumericUpDown();
            this.Nokta1X_1 = new System.Windows.Forms.NumericUpDown();
            this.Nokta2Y_1 = new System.Windows.Forms.NumericUpDown();
            this.Nokta1Y_1 = new System.Windows.Forms.NumericUpDown();
            this.KareIcınEn_1 = new System.Windows.Forms.NumericUpDown();
            this.YamukEN_1 = new System.Windows.Forms.NumericUpDown();
            this.KareIcınBoy_1 = new System.Windows.Forms.NumericUpDown();
            this.YamukBOY_1 = new System.Windows.Forms.NumericUpDown();
            this.KareIcınMerkezNoktaY_1 = new System.Windows.Forms.NumericUpDown();
            this.YamukMerkezNoktaY_1 = new System.Windows.Forms.NumericUpDown();
            this.HesaplaVeCizdirButton_1 = new System.Windows.Forms.Button();
            this.NoktaCemberCarpısma = new System.Windows.Forms.TabPage();
            this.SonucTextBox_2 = new System.Windows.Forms.TextBox();
            this.SonucLabel_2 = new System.Windows.Forms.Label();
            this.HesaplaVeÇiz_2 = new System.Windows.Forms.Button();
            this.CemberYaricap_2 = new System.Windows.Forms.NumericUpDown();
            this.CemberMerkezYEkseni_2 = new System.Windows.Forms.NumericUpDown();
            this.CemberMerkezXEkseni_2 = new System.Windows.Forms.NumericUpDown();
            this.NoktaYekseni_2 = new System.Windows.Forms.NumericUpDown();
            this.NoktaXekseni_2 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DikdortgenDikdortgenCarpisma = new System.Windows.Forms.TabPage();
            this.SonucTextBox_3 = new System.Windows.Forms.TextBox();
            this.SonucLabel_3 = new System.Windows.Forms.Label();
            this.Hesapla_Ve_CİZ_3_Button = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Dikdortgen2Genislik_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen2Uzunluk_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen2Yekseni_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen2Xekseni_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen1Uzunluk_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen1Genislik_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen1Yekseni_3 = new System.Windows.Forms.NumericUpDown();
            this.Dikdortgen1Xekseni_3 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenCemberCarpisma = new System.Windows.Forms.TabPage();
            this.Hesapla_Ve_Ciz_4 = new System.Windows.Forms.Button();
            this.SonucTextBox_4 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.CemberinizinYaricapi_4 = new System.Windows.Forms.NumericUpDown();
            this.CemberinizinMerkeziYekseni_4 = new System.Windows.Forms.NumericUpDown();
            this.CemberinizinMerkeziXekseni_4 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgeninBoyu_4 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgeninEni_4 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenIcınMerkezNoktaY_4 = new System.Windows.Forms.NumericUpDown();
            this.dikdortgenIcınMerkezNoktaX_4 = new System.Windows.Forms.NumericUpDown();
            this.CemberCemberCarpisma = new System.Windows.Forms.TabPage();
            this.TextBoxSonuc_5 = new System.Windows.Forms.TextBox();
            this.Cember2MerkezXekseni_5 = new System.Windows.Forms.NumericUpDown();
            this.Cember2YARICAP_5 = new System.Windows.Forms.NumericUpDown();
            this.Cember2MerkezYekseni_5 = new System.Windows.Forms.NumericUpDown();
            this.Cember1YARICAP_5 = new System.Windows.Forms.NumericUpDown();
            this.Cember1MerkezYekseni_5 = new System.Windows.Forms.NumericUpDown();
            this.Cember1MerkezXekseni_5 = new System.Windows.Forms.NumericUpDown();
            this.Hesapla_Ve_Cizdir_5 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.NoktaKureCarpisma = new System.Windows.Forms.TabPage();
            this.HesaplaVeCiz_6 = new System.Windows.Forms.Button();
            this.TextBoxSonuc_6 = new System.Windows.Forms.TextBox();
            this.KureYaricap_6 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezZEkseni_6 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezYEkseni_6 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezXEkseni_6 = new System.Windows.Forms.NumericUpDown();
            this.NoktaZekseni_6 = new System.Windows.Forms.NumericUpDown();
            this.NoktaYekseni_6 = new System.Windows.Forms.NumericUpDown();
            this.NoktaXekseni_6 = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.NoktaDikdortgenCarpisma = new System.Windows.Forms.TabPage();
            this.textBoxSonuc_7 = new System.Windows.Forms.TextBox();
            this.HesaplaVeÇizButton_7 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.DidortgenPrizmaEn_x_7 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezX_7 = new System.Windows.Forms.NumericUpDown();
            this.NoktaX_7 = new System.Windows.Forms.NumericUpDown();
            this.DidortgenPrizmaDerinlik_Z_7 = new System.Windows.Forms.NumericUpDown();
            this.DidortgenPrizmaBoy_Y_7 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezZ_7 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezY_7 = new System.Windows.Forms.NumericUpDown();
            this.NoktaZ_7 = new System.Windows.Forms.NumericUpDown();
            this.NoktaY_7 = new System.Windows.Forms.NumericUpDown();
            this.NoktaSilindirCarpisma = new System.Windows.Forms.TabPage();
            this.label56 = new System.Windows.Forms.Label();
            this.SilindirBoy_8 = new System.Windows.Forms.NumericUpDown();
            this.TextBoxSonuc_8 = new System.Windows.Forms.TextBox();
            this.HesaplaVeCızButton_8 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.SilindirYariCap_8 = new System.Windows.Forms.NumericUpDown();
            this.SilindirZEkseni_8 = new System.Windows.Forms.NumericUpDown();
            this.SilindirYEkseni_8 = new System.Windows.Forms.NumericUpDown();
            this.SilindirXEkseni_8 = new System.Windows.Forms.NumericUpDown();
            this.NoktaZEkseni_8 = new System.Windows.Forms.NumericUpDown();
            this.NoktaYEkseni_8 = new System.Windows.Forms.NumericUpDown();
            this.NoktaXEkseni_8 = new System.Windows.Forms.NumericUpDown();
            this.SilindirSilindirCarpisma = new System.Windows.Forms.TabPage();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxSonuc_9 = new System.Windows.Forms.TextBox();
            this.Hesapla_ve_ciz_9_button = new System.Windows.Forms.Button();
            this.silindir2Yaricap_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir2Boy_9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.silindir2ZMerkez_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir2YMerkez_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir2XMerkez_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir1Yaricap_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir1Boy_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir1ZMerkez_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir1YMerkez_9 = new System.Windows.Forms.NumericUpDown();
            this.silindir1XMerkez_9 = new System.Windows.Forms.NumericUpDown();
            this.KureKureCarpisma = new System.Windows.Forms.TabPage();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.Kure1Zekseni_10 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.Kure2Yaricap_10 = new System.Windows.Forms.NumericUpDown();
            this.Kure2Zekseni_10 = new System.Windows.Forms.NumericUpDown();
            this.Kure2Yekseni_10 = new System.Windows.Forms.NumericUpDown();
            this.Kure2Xekseni_10 = new System.Windows.Forms.NumericUpDown();
            this.Kure1Yaricap_10 = new System.Windows.Forms.NumericUpDown();
            this.Kureniz1Zekseni_10 = new System.Windows.Forms.NumericUpDown();
            this.Kure1Yekseni_10 = new System.Windows.Forms.NumericUpDown();
            this.Kure1Xekseni_10 = new System.Windows.Forms.NumericUpDown();
            this.textBoxSonuc_10 = new System.Windows.Forms.TextBox();
            this.hesapla_ve_cız_button_10 = new System.Windows.Forms.Button();
            this.KureSilindirCarpisma = new System.Windows.Forms.TabPage();
            this.label87 = new System.Windows.Forms.Label();
            this.textBoxSonuc_11 = new System.Windows.Forms.TextBox();
            this.Hesapla_ve_Ciz_11 = new System.Windows.Forms.Button();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.SilindirYaricap_11 = new System.Windows.Forms.NumericUpDown();
            this.SilindirBoy_11 = new System.Windows.Forms.NumericUpDown();
            this.SilindirMekrezZ_11 = new System.Windows.Forms.NumericUpDown();
            this.KureYaricap_11 = new System.Windows.Forms.NumericUpDown();
            this.SilindirMekrezY_11 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezZ_11 = new System.Windows.Forms.NumericUpDown();
            this.SilindirMekrezX_11 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezY_11 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezX_11 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyKureCarpisma = new System.Windows.Forms.TabPage();
            this.Hesapla_ve_Ciz_button_12 = new System.Windows.Forms.Button();
            this.textBoxSobuc_12 = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.YuzeyMerkezZ_12 = new System.Windows.Forms.NumericUpDown();
            this.KureYaricap_12 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyYaricap_12 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezZ_12 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezX_12 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezY_12 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezY_12 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezX_12 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyDikdortgenCarpisma = new System.Windows.Forms.TabPage();
            this.textBoxSonuc_13 = new System.Windows.Forms.TextBox();
            this.HesaplaVeCiz_13 = new System.Windows.Forms.Button();
            this.label106 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.DikdortgenPrizmaBoy_13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaEn_13 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaDerinlik_13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezZ_13 = new System.Windows.Forms.NumericUpDown();
            this.Yyaricap_13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezY_13 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezZ_13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezX_13 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezY_13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezX_13 = new System.Windows.Forms.NumericUpDown();
            this.YuzeySilindirCarpisma = new System.Windows.Forms.TabPage();
            this.YuzeyYaricap_14 = new System.Windows.Forms.NumericUpDown();
            this.textBoxSonuc_14 = new System.Windows.Forms.TextBox();
            this.Hesapla_VE_Ciz_14 = new System.Windows.Forms.Button();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.SilindirYaricap_14 = new System.Windows.Forms.NumericUpDown();
            this.SilindirBoy_14 = new System.Windows.Forms.NumericUpDown();
            this.SilindirMerkezX_14 = new System.Windows.Forms.NumericUpDown();
            this.SilindirMerkezZ_14 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezZ_14 = new System.Windows.Forms.NumericUpDown();
            this.SilindirMerkezY_14 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezY_14 = new System.Windows.Forms.NumericUpDown();
            this.YuzeyMerkezX_14 = new System.Windows.Forms.NumericUpDown();
            this.KureDikdortgenCarpisma = new System.Windows.Forms.TabPage();
            this.label127 = new System.Windows.Forms.Label();
            this.textBoxSonuc_15 = new System.Windows.Forms.TextBox();
            this.Hesapla_ve_ciz_15_button = new System.Windows.Forms.Button();
            this.label126 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.DikdortgenPrizmaMerkezX_15 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaDERİNLİK_15 = new System.Windows.Forms.NumericUpDown();
            this.KureYaricap_15 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaBOY_15 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezNoktaZ_15 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaEn_15 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezNoktaY_15 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezZ_15 = new System.Windows.Forms.NumericUpDown();
            this.KureMerkezNoktaX_15 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaMerkezY_15 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma = new System.Windows.Forms.TabPage();
            this.Sonuc = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.D11 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.DikdortgrnPrizma2DERİNLİK_16 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgrnPrizma1DERİNLİK_16 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgrnPrizma2BOY_16 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgrnPrizma1BOY_16 = new System.Windows.Forms.NumericUpDown();
            this.DidkortgenPrizma2Z_16 = new System.Windows.Forms.NumericUpDown();
            this.DidkortgenPrizma1Z_16 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgrnPrizma2EN_16 = new System.Windows.Forms.NumericUpDown();
            this.DikdortgrnPrizma1EN_16 = new System.Windows.Forms.NumericUpDown();
            this.DidkortgenPrizma2Y_16 = new System.Windows.Forms.NumericUpDown();
            this.DidkortgenPrizma1Y_16 = new System.Windows.Forms.NumericUpDown();
            this.DidkortgenPrizma2X_16 = new System.Windows.Forms.NumericUpDown();
            this.DidkortgenPrizma1X_16 = new System.Windows.Forms.NumericUpDown();
            this.textBoxSonuc_16 = new System.Windows.Forms.TextBox();
            this.HesaplaVeCizdir_16 = new System.Windows.Forms.Button();
            this.ListCizdir = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.Cizdir_list = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.NoktaDortgenCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınMerkezNoktaX_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukMerkezNoktaX_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukEGIM_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta2X_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta1X_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta2Y_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta1Y_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınEn_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukEN_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınBoy_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukBOY_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınMerkezNoktaY_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukMerkezNoktaY_1)).BeginInit();
            this.NoktaCemberCarpısma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CemberYaricap_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberMerkezYEkseni_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberMerkezXEkseni_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaYekseni_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaXekseni_2)).BeginInit();
            this.DikdortgenDikdortgenCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Genislik_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Uzunluk_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Yekseni_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Xekseni_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Uzunluk_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Genislik_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Yekseni_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Xekseni_3)).BeginInit();
            this.DikdortgenCemberCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CemberinizinYaricapi_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberinizinMerkeziYekseni_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberinizinMerkeziXekseni_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgeninBoyu_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgeninEni_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenIcınMerkezNoktaY_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dikdortgenIcınMerkezNoktaX_4)).BeginInit();
            this.CemberCemberCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cember2MerkezXekseni_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember2YARICAP_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember2MerkezYekseni_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember1YARICAP_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember1MerkezYekseni_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember1MerkezXekseni_5)).BeginInit();
            this.NoktaKureCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezZEkseni_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezYEkseni_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezXEkseni_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaZekseni_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaYekseni_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaXekseni_6)).BeginInit();
            this.NoktaDikdortgenCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DidortgenPrizmaEn_x_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezX_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaX_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidortgenPrizmaDerinlik_Z_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidortgenPrizmaBoy_Y_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezZ_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezY_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaZ_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaY_7)).BeginInit();
            this.NoktaSilindirCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirBoy_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYariCap_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirZEkseni_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYEkseni_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirXEkseni_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaZEkseni_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaYEkseni_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaXEkseni_8)).BeginInit();
            this.SilindirSilindirCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2Yaricap_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2Boy_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2ZMerkez_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2YMerkez_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2XMerkez_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1Yaricap_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1Boy_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1ZMerkez_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1YMerkez_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1XMerkez_9)).BeginInit();
            this.KureKureCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Yaricap_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Zekseni_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Yekseni_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Xekseni_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure1Yaricap_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kureniz1Zekseni_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure1Yekseni_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure1Xekseni_10)).BeginInit();
            this.KureSilindirCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYaricap_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirBoy_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMekrezZ_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMekrezY_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezZ_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMekrezX_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezY_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezX_11)).BeginInit();
            this.YuzeyKureCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezZ_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyYaricap_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezZ_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezX_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezY_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezY_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezX_12)).BeginInit();
            this.YuzeyDikdortgenCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaBoy_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaEn_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaDerinlik_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezZ_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yyaricap_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezY_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezZ_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezX_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezY_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezX_13)).BeginInit();
            this.YuzeySilindirCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyYaricap_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYaricap_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirBoy_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMerkezX_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMerkezZ_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezZ_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMerkezY_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezY_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezX_14)).BeginInit();
            this.KureDikdortgenCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezX_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaDERİNLİK_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaBOY_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezNoktaZ_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaEn_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezNoktaY_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezZ_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezNoktaX_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezY_15)).BeginInit();
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma2DERİNLİK_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma1DERİNLİK_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma2BOY_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma1BOY_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma2Z_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma1Z_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma2EN_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma1EN_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma2Y_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma1Y_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma2X_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma1X_16)).BeginInit();
            this.ListCizdir.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.NoktaDortgenCarpisma);
            this.tabControl1.Controls.Add(this.NoktaCemberCarpısma);
            this.tabControl1.Controls.Add(this.DikdortgenDikdortgenCarpisma);
            this.tabControl1.Controls.Add(this.DikdortgenCemberCarpisma);
            this.tabControl1.Controls.Add(this.CemberCemberCarpisma);
            this.tabControl1.Controls.Add(this.NoktaKureCarpisma);
            this.tabControl1.Controls.Add(this.NoktaDikdortgenCarpisma);
            this.tabControl1.Controls.Add(this.NoktaSilindirCarpisma);
            this.tabControl1.Controls.Add(this.SilindirSilindirCarpisma);
            this.tabControl1.Controls.Add(this.KureKureCarpisma);
            this.tabControl1.Controls.Add(this.KureSilindirCarpisma);
            this.tabControl1.Controls.Add(this.YuzeyKureCarpisma);
            this.tabControl1.Controls.Add(this.YuzeyDikdortgenCarpisma);
            this.tabControl1.Controls.Add(this.YuzeySilindirCarpisma);
            this.tabControl1.Controls.Add(this.KureDikdortgenCarpisma);
            this.tabControl1.Controls.Add(this.DikdortgenPrizmaDikdortgenPrizmaCarpisma);
            this.tabControl1.Controls.Add(this.ListCizdir);
            this.tabControl1.Location = new System.Drawing.Point(997, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(431, 570);
            this.tabControl1.TabIndex = 0;
            // 
            // NoktaDortgenCarpisma
            // 
            this.NoktaDortgenCarpisma.Controls.Add(this.textBoxSonuc11_2);
            this.NoktaDortgenCarpisma.Controls.Add(this.HesaplaVeCizdir2_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.label144);
            this.NoktaDortgenCarpisma.Controls.Add(this.label131);
            this.NoktaDortgenCarpisma.Controls.Add(this.label154);
            this.NoktaDortgenCarpisma.Controls.Add(this.label150);
            this.NoktaDortgenCarpisma.Controls.Add(this.label153);
            this.NoktaDortgenCarpisma.Controls.Add(this.label152);
            this.NoktaDortgenCarpisma.Controls.Add(this.label145);
            this.NoktaDortgenCarpisma.Controls.Add(this.label143);
            this.NoktaDortgenCarpisma.Controls.Add(this.label149);
            this.NoktaDortgenCarpisma.Controls.Add(this.label148);
            this.NoktaDortgenCarpisma.Controls.Add(this.label141);
            this.NoktaDortgenCarpisma.Controls.Add(this.label147);
            this.NoktaDortgenCarpisma.Controls.Add(this.label146);
            this.NoktaDortgenCarpisma.Controls.Add(this.label140);
            this.NoktaDortgenCarpisma.Controls.Add(this.textBoxSonuc_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.KareIcınMerkezNoktaX_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.YamukMerkezNoktaX_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.YamukEGIM_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.Nokta2X_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.Nokta1X_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.Nokta2Y_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.Nokta1Y_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.KareIcınEn_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.YamukEN_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.KareIcınBoy_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.YamukBOY_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.KareIcınMerkezNoktaY_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.YamukMerkezNoktaY_1);
            this.NoktaDortgenCarpisma.Controls.Add(this.HesaplaVeCizdirButton_1);
            this.NoktaDortgenCarpisma.Location = new System.Drawing.Point(4, 24);
            this.NoktaDortgenCarpisma.Name = "NoktaDortgenCarpisma";
            this.NoktaDortgenCarpisma.Padding = new System.Windows.Forms.Padding(3);
            this.NoktaDortgenCarpisma.Size = new System.Drawing.Size(423, 542);
            this.NoktaDortgenCarpisma.TabIndex = 0;
            this.NoktaDortgenCarpisma.Text = "NoktaDortgenCarpisma";
            this.NoktaDortgenCarpisma.UseVisualStyleBackColor = true;
           
            // 
            // textBoxSonuc11_2
            // 
            this.textBoxSonuc11_2.Location = new System.Drawing.Point(237, 310);
            this.textBoxSonuc11_2.Name = "textBoxSonuc11_2";
            this.textBoxSonuc11_2.Size = new System.Drawing.Size(122, 23);
            this.textBoxSonuc11_2.TabIndex = 8;
            // 
            // HesaplaVeCizdir2_1
            // 
            this.HesaplaVeCizdir2_1.Location = new System.Drawing.Point(209, 483);
            this.HesaplaVeCizdir2_1.Name = "HesaplaVeCizdir2_1";
            this.HesaplaVeCizdir2_1.Size = new System.Drawing.Size(148, 23);
            this.HesaplaVeCizdir2_1.TabIndex = 7;
            this.HesaplaVeCizdir2_1.Text = "Hesapla ve çizdir";
            this.HesaplaVeCizdir2_1.UseVisualStyleBackColor = true;
            this.HesaplaVeCizdir2_1.Click += new System.EventHandler(this.HesaplaVeCizdir2_1_Click);
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(239, 246);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(43, 15);
            this.label144.TabIndex = 6;
            this.label144.Text = "Sonuc:";
            
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(293, 71);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(227, 15);
            this.label131.TabIndex = 6;
            this.label131.Text = "Noktanızın x eksenindeki merkezini giriniz";
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(20, 222);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(162, 15);
            this.label154.TabIndex = 6;
            this.label154.Text = "Yamugunuzun eğimini giriniz";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(20, 178);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(163, 15);
            this.label150.TabIndex = 6;
            this.label150.Text = "yamugunuzun boyunu giriniz";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(20, 89);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(257, 15);
            this.label153.TabIndex = 6;
            this.label153.Text = "Yamugunuz için merkez nokta Y eksenini giriniz";
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(20, 45);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(257, 15);
            this.label152.TabIndex = 6;
            this.label152.Text = "Yamugunuz için merkez nokta X eksenini giriniz";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(20, 135);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(176, 15);
            this.label145.TabIndex = 6;
            this.label145.Text = "Yamugunuzun genişliğini giriniz";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(293, 115);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(227, 15);
            this.label143.TabIndex = 6;
            this.label143.Text = "Noktanızın y eksenindeki merkezini giriniz";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(6, 465);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(138, 15);
            this.label149.TabIndex = 6;
            this.label149.Text = "Kare/dikdortgen için boy";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(8, 414);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(133, 15);
            this.label148.TabIndex = 6;
            this.label148.Text = "Kare/dikdortgen için EN";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(239, 410);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(160, 15);
            this.label141.TabIndex = 6;
            this.label141.Text = "Noktanız için merkez nokta Y";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(8, 370);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(199, 15);
            this.label147.TabIndex = 6;
            this.label147.Text = "Kare/dikdortgen için merkez nokta Y";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(0, 318);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(198, 15);
            this.label146.TabIndex = 6;
            this.label146.Text = "Kare/dikdortgen için merkez nokta x";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(237, 366);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(160, 15);
            this.label140.TabIndex = 6;
            this.label140.Text = "Noktanız için merkez nokta X";
            // 
            // textBoxSonuc_1
            // 
            this.textBoxSonuc_1.Location = new System.Drawing.Point(239, 264);
            this.textBoxSonuc_1.Name = "textBoxSonuc_1";
            this.textBoxSonuc_1.Size = new System.Drawing.Size(120, 23);
            this.textBoxSonuc_1.TabIndex = 5;
            // 
            // KareIcınMerkezNoktaX_1
            // 
            this.KareIcınMerkezNoktaX_1.Location = new System.Drawing.Point(6, 336);
            this.KareIcınMerkezNoktaX_1.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.KareIcınMerkezNoktaX_1.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.KareIcınMerkezNoktaX_1.Name = "KareIcınMerkezNoktaX_1";
            this.KareIcınMerkezNoktaX_1.Size = new System.Drawing.Size(120, 23);
            this.KareIcınMerkezNoktaX_1.TabIndex = 4;
            // 
            // YamukMerkezNoktaX_1
            // 
            this.YamukMerkezNoktaX_1.Location = new System.Drawing.Point(20, 63);
            this.YamukMerkezNoktaX_1.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.YamukMerkezNoktaX_1.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.YamukMerkezNoktaX_1.Name = "YamukMerkezNoktaX_1";
            this.YamukMerkezNoktaX_1.Size = new System.Drawing.Size(120, 23);
            this.YamukMerkezNoktaX_1.TabIndex = 4;
            // 
            // YamukEGIM_1
            // 
            this.YamukEGIM_1.Location = new System.Drawing.Point(20, 238);
            this.YamukEGIM_1.Name = "YamukEGIM_1";
            this.YamukEGIM_1.Size = new System.Drawing.Size(120, 23);
            this.YamukEGIM_1.TabIndex = 3;
            // 
            // Nokta2X_1
            // 
            this.Nokta2X_1.Location = new System.Drawing.Point(237, 384);
            this.Nokta2X_1.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Nokta2X_1.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Nokta2X_1.Name = "Nokta2X_1";
            this.Nokta2X_1.Size = new System.Drawing.Size(120, 23);
            this.Nokta2X_1.TabIndex = 3;
            // 
            // Nokta1X_1
            // 
            this.Nokta1X_1.Location = new System.Drawing.Point(296, 89);
            this.Nokta1X_1.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Nokta1X_1.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Nokta1X_1.Name = "Nokta1X_1";
            this.Nokta1X_1.Size = new System.Drawing.Size(120, 23);
            this.Nokta1X_1.TabIndex = 3;
            // 
            // Nokta2Y_1
            // 
            this.Nokta2Y_1.Location = new System.Drawing.Point(237, 428);
            this.Nokta2Y_1.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Nokta2Y_1.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Nokta2Y_1.Name = "Nokta2Y_1";
            this.Nokta2Y_1.Size = new System.Drawing.Size(120, 23);
            this.Nokta2Y_1.TabIndex = 3;
            this.Nokta2Y_1.Value = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            // 
            // Nokta1Y_1
            // 
            this.Nokta1Y_1.Location = new System.Drawing.Point(296, 133);
            this.Nokta1Y_1.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Nokta1Y_1.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Nokta1Y_1.Name = "Nokta1Y_1";
            this.Nokta1Y_1.Size = new System.Drawing.Size(120, 23);
            this.Nokta1Y_1.TabIndex = 3;
            // 
            // KareIcınEn_1
            // 
            this.KareIcınEn_1.Location = new System.Drawing.Point(6, 439);
            this.KareIcınEn_1.Name = "KareIcınEn_1";
            this.KareIcınEn_1.Size = new System.Drawing.Size(120, 23);
            this.KareIcınEn_1.TabIndex = 3;
            // 
            // YamukEN_1
            // 
            this.YamukEN_1.Location = new System.Drawing.Point(20, 152);
            this.YamukEN_1.Name = "YamukEN_1";
            this.YamukEN_1.Size = new System.Drawing.Size(120, 23);
            this.YamukEN_1.TabIndex = 3;
            // 
            // KareIcınBoy_1
            // 
            this.KareIcınBoy_1.Location = new System.Drawing.Point(8, 485);
            this.KareIcınBoy_1.Name = "KareIcınBoy_1";
            this.KareIcınBoy_1.Size = new System.Drawing.Size(120, 23);
            this.KareIcınBoy_1.TabIndex = 3;
            // 
            // YamukBOY_1
            // 
            this.YamukBOY_1.Location = new System.Drawing.Point(20, 198);
            this.YamukBOY_1.Name = "YamukBOY_1";
            this.YamukBOY_1.Size = new System.Drawing.Size(120, 23);
            this.YamukBOY_1.TabIndex = 3;
            // 
            // KareIcınMerkezNoktaY_1
            // 
            this.KareIcınMerkezNoktaY_1.Location = new System.Drawing.Point(6, 388);
            this.KareIcınMerkezNoktaY_1.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.KareIcınMerkezNoktaY_1.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.KareIcınMerkezNoktaY_1.Name = "KareIcınMerkezNoktaY_1";
            this.KareIcınMerkezNoktaY_1.Size = new System.Drawing.Size(120, 23);
            this.KareIcınMerkezNoktaY_1.TabIndex = 3;
            // 
            // YamukMerkezNoktaY_1
            // 
            this.YamukMerkezNoktaY_1.Location = new System.Drawing.Point(20, 107);
            this.YamukMerkezNoktaY_1.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.YamukMerkezNoktaY_1.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.YamukMerkezNoktaY_1.Name = "YamukMerkezNoktaY_1";
            this.YamukMerkezNoktaY_1.Size = new System.Drawing.Size(120, 23);
            this.YamukMerkezNoktaY_1.TabIndex = 3;
            // 
            // HesaplaVeCizdirButton_1
            // 
            this.HesaplaVeCizdirButton_1.Location = new System.Drawing.Point(237, 178);
            this.HesaplaVeCizdirButton_1.Name = "HesaplaVeCizdirButton_1";
            this.HesaplaVeCizdirButton_1.Size = new System.Drawing.Size(144, 23);
            this.HesaplaVeCizdirButton_1.TabIndex = 0;
            this.HesaplaVeCizdirButton_1.Text = "Hesapla Ve Cizdir Button";
            this.HesaplaVeCizdirButton_1.UseVisualStyleBackColor = true;
            this.HesaplaVeCizdirButton_1.Click += new System.EventHandler(this.button1_Click);
            // 
            // NoktaCemberCarpısma
            // 
            this.NoktaCemberCarpısma.Controls.Add(this.SonucTextBox_2);
            this.NoktaCemberCarpısma.Controls.Add(this.SonucLabel_2);
            this.NoktaCemberCarpısma.Controls.Add(this.HesaplaVeÇiz_2);
            this.NoktaCemberCarpısma.Controls.Add(this.CemberYaricap_2);
            this.NoktaCemberCarpısma.Controls.Add(this.CemberMerkezYEkseni_2);
            this.NoktaCemberCarpısma.Controls.Add(this.CemberMerkezXEkseni_2);
            this.NoktaCemberCarpısma.Controls.Add(this.NoktaYekseni_2);
            this.NoktaCemberCarpısma.Controls.Add(this.NoktaXekseni_2);
            this.NoktaCemberCarpısma.Controls.Add(this.label5);
            this.NoktaCemberCarpısma.Controls.Add(this.label4);
            this.NoktaCemberCarpısma.Controls.Add(this.label3);
            this.NoktaCemberCarpısma.Controls.Add(this.label2);
            this.NoktaCemberCarpısma.Controls.Add(this.label1);
            this.NoktaCemberCarpısma.Location = new System.Drawing.Point(4, 24);
            this.NoktaCemberCarpısma.Name = "NoktaCemberCarpısma";
            this.NoktaCemberCarpısma.Padding = new System.Windows.Forms.Padding(3);
            this.NoktaCemberCarpısma.Size = new System.Drawing.Size(423, 542);
            this.NoktaCemberCarpısma.TabIndex = 1;
            this.NoktaCemberCarpısma.Text = "NoktaCemberCarpisma";
            this.NoktaCemberCarpısma.UseVisualStyleBackColor = true;
            // 
            // SonucTextBox_2
            // 
            this.SonucTextBox_2.Location = new System.Drawing.Point(21, 247);
            this.SonucTextBox_2.Name = "SonucTextBox_2";
            this.SonucTextBox_2.Size = new System.Drawing.Size(120, 23);
            this.SonucTextBox_2.TabIndex = 11;
            // 
            // SonucLabel_2
            // 
            this.SonucLabel_2.AutoSize = true;
            this.SonucLabel_2.Location = new System.Drawing.Point(21, 229);
            this.SonucLabel_2.Name = "SonucLabel_2";
            this.SonucLabel_2.Size = new System.Drawing.Size(43, 15);
            this.SonucLabel_2.TabIndex = 10;
            this.SonucLabel_2.Text = "Sonuc:";
            // 
            // HesaplaVeÇiz_2
            // 
            this.HesaplaVeÇiz_2.Location = new System.Drawing.Point(273, 31);
            this.HesaplaVeÇiz_2.Name = "HesaplaVeÇiz_2";
            this.HesaplaVeÇiz_2.Size = new System.Drawing.Size(122, 23);
            this.HesaplaVeÇiz_2.TabIndex = 9;
            this.HesaplaVeÇiz_2.Text = "HesaplaVeÇiz_2";
            this.HesaplaVeÇiz_2.UseVisualStyleBackColor = true;
            this.HesaplaVeÇiz_2.Click += new System.EventHandler(this.HesaplaVeÇiz_2_Click);
            // 
            // CemberYaricap_2
            // 
            this.CemberYaricap_2.Location = new System.Drawing.Point(21, 203);
            this.CemberYaricap_2.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.CemberYaricap_2.Name = "CemberYaricap_2";
            this.CemberYaricap_2.Size = new System.Drawing.Size(120, 23);
            this.CemberYaricap_2.TabIndex = 8;
            // 
            // CemberMerkezYEkseni_2
            // 
            this.CemberMerkezYEkseni_2.Location = new System.Drawing.Point(21, 163);
            this.CemberMerkezYEkseni_2.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.CemberMerkezYEkseni_2.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.CemberMerkezYEkseni_2.Name = "CemberMerkezYEkseni_2";
            this.CemberMerkezYEkseni_2.Size = new System.Drawing.Size(120, 23);
            this.CemberMerkezYEkseni_2.TabIndex = 8;
            // 
            // CemberMerkezXEkseni_2
            // 
            this.CemberMerkezXEkseni_2.Location = new System.Drawing.Point(21, 119);
            this.CemberMerkezXEkseni_2.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.CemberMerkezXEkseni_2.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.CemberMerkezXEkseni_2.Name = "CemberMerkezXEkseni_2";
            this.CemberMerkezXEkseni_2.Size = new System.Drawing.Size(120, 23);
            this.CemberMerkezXEkseni_2.TabIndex = 8;
            // 
            // NoktaYekseni_2
            // 
            this.NoktaYekseni_2.Location = new System.Drawing.Point(21, 75);
            this.NoktaYekseni_2.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.NoktaYekseni_2.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.NoktaYekseni_2.Name = "NoktaYekseni_2";
            this.NoktaYekseni_2.Size = new System.Drawing.Size(120, 23);
            this.NoktaYekseni_2.TabIndex = 8;
            // 
            // NoktaXekseni_2
            // 
            this.NoktaXekseni_2.Location = new System.Drawing.Point(21, 31);
            this.NoktaXekseni_2.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.NoktaXekseni_2.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.NoktaXekseni_2.Name = "NoktaXekseni_2";
            this.NoktaXekseni_2.Size = new System.Drawing.Size(120, 23);
            this.NoktaXekseni_2.TabIndex = 8;
           
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(166, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Cemberinizin yaricapini giriniz";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(337, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Cemberinizin merkezinin y ekseni üzerindeki konumunu giriniz";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Cemberinizin merkezinin X ekseni üzerindeki konumunu giriniz";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(236, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Noktanızın Y eksenindeki konumunu giriniz";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Noktanızın X eksenindeki konumunu giriniz";
            // 
            // DikdortgenDikdortgenCarpisma
            // 
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.SonucTextBox_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.SonucLabel_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Hesapla_Ve_CİZ_3_Button);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label14);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label13);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label12);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label11);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label10);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label9);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label15);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.label8);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen2Genislik_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen2Uzunluk_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen2Yekseni_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen2Xekseni_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen1Uzunluk_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen1Genislik_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen1Yekseni_3);
            this.DikdortgenDikdortgenCarpisma.Controls.Add(this.Dikdortgen1Xekseni_3);
            this.DikdortgenDikdortgenCarpisma.Location = new System.Drawing.Point(4, 24);
            this.DikdortgenDikdortgenCarpisma.Name = "DikdortgenDikdortgenCarpisma";
            this.DikdortgenDikdortgenCarpisma.Padding = new System.Windows.Forms.Padding(3);
            this.DikdortgenDikdortgenCarpisma.Size = new System.Drawing.Size(423, 542);
            this.DikdortgenDikdortgenCarpisma.TabIndex = 2;
            this.DikdortgenDikdortgenCarpisma.Text = "DikdortgenDikdortgenCarpisma";
            this.DikdortgenDikdortgenCarpisma.UseVisualStyleBackColor = true;
            // 
            // SonucTextBox_3
            // 
            this.SonucTextBox_3.Location = new System.Drawing.Point(21, 389);
            this.SonucTextBox_3.Name = "SonucTextBox_3";
            this.SonucTextBox_3.Size = new System.Drawing.Size(120, 23);
            this.SonucTextBox_3.TabIndex = 4;
            // 
            // SonucLabel_3
            // 
            this.SonucLabel_3.AutoSize = true;
            this.SonucLabel_3.Location = new System.Drawing.Point(21, 371);
            this.SonucLabel_3.Name = "SonucLabel_3";
            this.SonucLabel_3.Size = new System.Drawing.Size(43, 15);
            this.SonucLabel_3.TabIndex = 3;
            this.SonucLabel_3.Text = "Sonuc:";
            // 
            // Hesapla_Ve_CİZ_3_Button
            // 
            this.Hesapla_Ve_CİZ_3_Button.Location = new System.Drawing.Point(21, 433);
            this.Hesapla_Ve_CİZ_3_Button.Name = "Hesapla_Ve_CİZ_3_Button";
            this.Hesapla_Ve_CİZ_3_Button.Size = new System.Drawing.Size(120, 23);
            this.Hesapla_Ve_CİZ_3_Button.TabIndex = 2;
            this.Hesapla_Ve_CİZ_3_Button.Text = "Hesapla_Ve_CİZ_3";
            this.Hesapla_Ve_CİZ_3_Button.UseVisualStyleBackColor = true;
            this.Hesapla_Ve_CİZ_3_Button.Click += new System.EventHandler(this.Hesapla_Ve_CİZ_3_Button_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 327);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(352, 15);
            this.label14.TabIndex = 1;
            this.label14.Text = "1. dikdörtgeninizin uzuluğunu yani y eksenindeki uzantısını giriniz";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(21, 283);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(347, 15);
            this.label13.TabIndex = 1;
            this.label13.Text = "1. Dikdörtgeninizin genişiğini yani x eksenindeki uzantısını giriniz";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(21, 234);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(270, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "2. Dikdortgeninizin Y eksenindeki merkezini giriniz";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 192);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(269, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "2. Dikdortgeninizin x eksenindeki merkezini giriniz";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 148);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(352, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "1. dikdörtgeninizin uzuluğunu yani y eksenindeki uzantısını giriniz";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(347, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "1. Dikdörtgeninizin genişiğini yani x eksenindeki uzantısını giriniz";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(21, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(269, 15);
            this.label15.TabIndex = 1;
            this.label15.Text = "1. Dikdortgeninizin x eksenindeki merkezini giriniz";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(269, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "1. Dikdortgeninizin y eksenindeki merkezini giriniz";
            // 
            // Dikdortgen2Genislik_3
            // 
            this.Dikdortgen2Genislik_3.Location = new System.Drawing.Point(21, 301);
            this.Dikdortgen2Genislik_3.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.Dikdortgen2Genislik_3.Name = "Dikdortgen2Genislik_3";
            this.Dikdortgen2Genislik_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen2Genislik_3.TabIndex = 0;
            // 
            // Dikdortgen2Uzunluk_3
            // 
            this.Dikdortgen2Uzunluk_3.Location = new System.Drawing.Point(21, 345);
            this.Dikdortgen2Uzunluk_3.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.Dikdortgen2Uzunluk_3.Name = "Dikdortgen2Uzunluk_3";
            this.Dikdortgen2Uzunluk_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen2Uzunluk_3.TabIndex = 0;
            // 
            // Dikdortgen2Yekseni_3
            // 
            this.Dikdortgen2Yekseni_3.Location = new System.Drawing.Point(21, 252);
            this.Dikdortgen2Yekseni_3.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Dikdortgen2Yekseni_3.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Dikdortgen2Yekseni_3.Name = "Dikdortgen2Yekseni_3";
            this.Dikdortgen2Yekseni_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen2Yekseni_3.TabIndex = 0;
            // 
            // Dikdortgen2Xekseni_3
            // 
            this.Dikdortgen2Xekseni_3.Location = new System.Drawing.Point(21, 211);
            this.Dikdortgen2Xekseni_3.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Dikdortgen2Xekseni_3.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Dikdortgen2Xekseni_3.Name = "Dikdortgen2Xekseni_3";
            this.Dikdortgen2Xekseni_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen2Xekseni_3.TabIndex = 0;
            // 
            // Dikdortgen1Uzunluk_3
            // 
            this.Dikdortgen1Uzunluk_3.Location = new System.Drawing.Point(21, 166);
            this.Dikdortgen1Uzunluk_3.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.Dikdortgen1Uzunluk_3.Name = "Dikdortgen1Uzunluk_3";
            this.Dikdortgen1Uzunluk_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen1Uzunluk_3.TabIndex = 0;
            // 
            // Dikdortgen1Genislik_3
            // 
            this.Dikdortgen1Genislik_3.Location = new System.Drawing.Point(21, 122);
            this.Dikdortgen1Genislik_3.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.Dikdortgen1Genislik_3.Name = "Dikdortgen1Genislik_3";
            this.Dikdortgen1Genislik_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen1Genislik_3.TabIndex = 0;
            // 
            // Dikdortgen1Yekseni_3
            // 
            this.Dikdortgen1Yekseni_3.Location = new System.Drawing.Point(21, 75);
            this.Dikdortgen1Yekseni_3.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Dikdortgen1Yekseni_3.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Dikdortgen1Yekseni_3.Name = "Dikdortgen1Yekseni_3";
            this.Dikdortgen1Yekseni_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen1Yekseni_3.TabIndex = 0;
            // 
            // Dikdortgen1Xekseni_3
            // 
            this.Dikdortgen1Xekseni_3.Location = new System.Drawing.Point(21, 33);
            this.Dikdortgen1Xekseni_3.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Dikdortgen1Xekseni_3.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Dikdortgen1Xekseni_3.Name = "Dikdortgen1Xekseni_3";
            this.Dikdortgen1Xekseni_3.Size = new System.Drawing.Size(120, 23);
            this.Dikdortgen1Xekseni_3.TabIndex = 0;
            // 
            // DikdortgenCemberCarpisma
            // 
            this.DikdortgenCemberCarpisma.Controls.Add(this.Hesapla_Ve_Ciz_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.SonucTextBox_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label22);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label20);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label18);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label21);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label19);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label17);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label16);
            this.DikdortgenCemberCarpisma.Controls.Add(this.label7);
            this.DikdortgenCemberCarpisma.Controls.Add(this.CemberinizinYaricapi_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.CemberinizinMerkeziYekseni_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.CemberinizinMerkeziXekseni_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.DikdortgeninBoyu_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.DikdortgeninEni_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.DikdortgenIcınMerkezNoktaY_4);
            this.DikdortgenCemberCarpisma.Controls.Add(this.dikdortgenIcınMerkezNoktaX_4);
            this.DikdortgenCemberCarpisma.Location = new System.Drawing.Point(4, 24);
            this.DikdortgenCemberCarpisma.Name = "DikdortgenCemberCarpisma";
            this.DikdortgenCemberCarpisma.Padding = new System.Windows.Forms.Padding(3);
            this.DikdortgenCemberCarpisma.Size = new System.Drawing.Size(423, 542);
            this.DikdortgenCemberCarpisma.TabIndex = 3;
            this.DikdortgenCemberCarpisma.Text = "DikdortgenCemberCarpisma";
            this.DikdortgenCemberCarpisma.UseVisualStyleBackColor = true;
            // 
            // Hesapla_Ve_Ciz_4
            // 
            this.Hesapla_Ve_Ciz_4.Location = new System.Drawing.Point(0, 398);
            this.Hesapla_Ve_Ciz_4.Name = "Hesapla_Ve_Ciz_4";
            this.Hesapla_Ve_Ciz_4.Size = new System.Drawing.Size(123, 23);
            this.Hesapla_Ve_Ciz_4.TabIndex = 3;
            this.Hesapla_Ve_Ciz_4.Text = "Hesapla_Ve_Ciz_4";
            this.Hesapla_Ve_Ciz_4.UseVisualStyleBackColor = true;
            this.Hesapla_Ve_Ciz_4.Click += new System.EventHandler(this.Hesapla_Ve_Ciz_4_Click);
            // 
            // SonucTextBox_4
            // 
            this.SonucTextBox_4.Location = new System.Drawing.Point(3, 369);
            this.SonucTextBox_4.Name = "SonucTextBox_4";
            this.SonucTextBox_4.Size = new System.Drawing.Size(120, 23);
            this.SonucTextBox_4.TabIndex = 2;
           
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 307);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(164, 15);
            this.label22.TabIndex = 1;
            this.label22.Text = "çemberinizin yarıçapını giriniz";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(-4, 212);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(251, 15);
            this.label20.TabIndex = 1;
            this.label20.Text = "çemberiniz için merkez nokta x eksenini giriniz";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(0, 117);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(172, 15);
            this.label18.TabIndex = 1;
            this.label18.Text = "Dikdörtgeninizin enini giriniz(x)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 351);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 15);
            this.label21.TabIndex = 1;
            this.label21.Text = "sonuç:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(-4, 254);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(251, 15);
            this.label19.TabIndex = 1;
            this.label19.Text = "çemberiniz için merkez nokta y eksenini giriniz";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 161);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(186, 15);
            this.label17.TabIndex = 1;
            this.label17.Text = "dikdörtgeninizin boyunu giriniz(y)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(253, 15);
            this.label16.TabIndex = 1;
            this.label16.Text = "Dikdörtgen için merkez nokta X eksenini giriniz";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(252, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "dikdortgen için merkez nokta Y eksenini giriniz";
            // 
            // CemberinizinYaricapi_4
            // 
            this.CemberinizinYaricapi_4.Location = new System.Drawing.Point(0, 325);
            this.CemberinizinYaricapi_4.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.CemberinizinYaricapi_4.Name = "CemberinizinYaricapi_4";
            this.CemberinizinYaricapi_4.Size = new System.Drawing.Size(120, 23);
            this.CemberinizinYaricapi_4.TabIndex = 0;
            // 
            // CemberinizinMerkeziYekseni_4
            // 
            this.CemberinizinMerkeziYekseni_4.Location = new System.Drawing.Point(0, 272);
            this.CemberinizinMerkeziYekseni_4.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.CemberinizinMerkeziYekseni_4.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.CemberinizinMerkeziYekseni_4.Name = "CemberinizinMerkeziYekseni_4";
            this.CemberinizinMerkeziYekseni_4.Size = new System.Drawing.Size(120, 23);
            this.CemberinizinMerkeziYekseni_4.TabIndex = 0;
            // 
            // CemberinizinMerkeziXekseni_4
            // 
            this.CemberinizinMerkeziXekseni_4.Location = new System.Drawing.Point(0, 230);
            this.CemberinizinMerkeziXekseni_4.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.CemberinizinMerkeziXekseni_4.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.CemberinizinMerkeziXekseni_4.Name = "CemberinizinMerkeziXekseni_4";
            this.CemberinizinMerkeziXekseni_4.Size = new System.Drawing.Size(120, 23);
            this.CemberinizinMerkeziXekseni_4.TabIndex = 0;
            // 
            // DikdortgeninBoyu_4
            // 
            this.DikdortgeninBoyu_4.Location = new System.Drawing.Point(0, 179);
            this.DikdortgeninBoyu_4.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.DikdortgeninBoyu_4.Name = "DikdortgeninBoyu_4";
            this.DikdortgeninBoyu_4.Size = new System.Drawing.Size(120, 23);
            this.DikdortgeninBoyu_4.TabIndex = 0;
            // 
            // DikdortgeninEni_4
            // 
            this.DikdortgeninEni_4.Location = new System.Drawing.Point(3, 135);
            this.DikdortgeninEni_4.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.DikdortgeninEni_4.Name = "DikdortgeninEni_4";
            this.DikdortgeninEni_4.Size = new System.Drawing.Size(120, 23);
            this.DikdortgeninEni_4.TabIndex = 0;
            // 
            // DikdortgenIcınMerkezNoktaY_4
            // 
            this.DikdortgenIcınMerkezNoktaY_4.Location = new System.Drawing.Point(3, 92);
            this.DikdortgenIcınMerkezNoktaY_4.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.DikdortgenIcınMerkezNoktaY_4.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.DikdortgenIcınMerkezNoktaY_4.Name = "DikdortgenIcınMerkezNoktaY_4";
            this.DikdortgenIcınMerkezNoktaY_4.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenIcınMerkezNoktaY_4.TabIndex = 0;
            // 
            // dikdortgenIcınMerkezNoktaX_4
            // 
            this.dikdortgenIcınMerkezNoktaX_4.Location = new System.Drawing.Point(3, 50);
            this.dikdortgenIcınMerkezNoktaX_4.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.dikdortgenIcınMerkezNoktaX_4.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.dikdortgenIcınMerkezNoktaX_4.Name = "dikdortgenIcınMerkezNoktaX_4";
            this.dikdortgenIcınMerkezNoktaX_4.Size = new System.Drawing.Size(120, 23);
            this.dikdortgenIcınMerkezNoktaX_4.TabIndex = 0;
            // 
            // CemberCemberCarpisma
            // 
            this.CemberCemberCarpisma.Controls.Add(this.TextBoxSonuc_5);
            this.CemberCemberCarpisma.Controls.Add(this.Cember2MerkezXekseni_5);
            this.CemberCemberCarpisma.Controls.Add(this.Cember2YARICAP_5);
            this.CemberCemberCarpisma.Controls.Add(this.Cember2MerkezYekseni_5);
            this.CemberCemberCarpisma.Controls.Add(this.Cember1YARICAP_5);
            this.CemberCemberCarpisma.Controls.Add(this.Cember1MerkezYekseni_5);
            this.CemberCemberCarpisma.Controls.Add(this.Cember1MerkezXekseni_5);
            this.CemberCemberCarpisma.Controls.Add(this.Hesapla_Ve_Cizdir_5);
            this.CemberCemberCarpisma.Controls.Add(this.label29);
            this.CemberCemberCarpisma.Controls.Add(this.label28);
            this.CemberCemberCarpisma.Controls.Add(this.label27);
            this.CemberCemberCarpisma.Controls.Add(this.label26);
            this.CemberCemberCarpisma.Controls.Add(this.label25);
            this.CemberCemberCarpisma.Controls.Add(this.label24);
            this.CemberCemberCarpisma.Controls.Add(this.label23);
            this.CemberCemberCarpisma.Location = new System.Drawing.Point(4, 24);
            this.CemberCemberCarpisma.Name = "CemberCemberCarpisma";
            this.CemberCemberCarpisma.Padding = new System.Windows.Forms.Padding(3);
            this.CemberCemberCarpisma.Size = new System.Drawing.Size(423, 542);
            this.CemberCemberCarpisma.TabIndex = 4;
            this.CemberCemberCarpisma.Text = "CemberCemberCarpisma";
            this.CemberCemberCarpisma.UseVisualStyleBackColor = true;
            // 
            // TextBoxSonuc_5
            // 
            this.TextBoxSonuc_5.Location = new System.Drawing.Point(0, 289);
            this.TextBoxSonuc_5.Name = "TextBoxSonuc_5";
            this.TextBoxSonuc_5.Size = new System.Drawing.Size(123, 23);
            this.TextBoxSonuc_5.TabIndex = 3;
            // 
            // Cember2MerkezXekseni_5
            // 
            this.Cember2MerkezXekseni_5.Location = new System.Drawing.Point(3, 162);
            this.Cember2MerkezXekseni_5.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Cember2MerkezXekseni_5.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Cember2MerkezXekseni_5.Name = "Cember2MerkezXekseni_5";
            this.Cember2MerkezXekseni_5.Size = new System.Drawing.Size(120, 23);
            this.Cember2MerkezXekseni_5.TabIndex = 2;
           
            // 
            // Cember2YARICAP_5
            // 
            this.Cember2YARICAP_5.Location = new System.Drawing.Point(3, 245);
            this.Cember2YARICAP_5.Name = "Cember2YARICAP_5";
            this.Cember2YARICAP_5.Size = new System.Drawing.Size(120, 23);
            this.Cember2YARICAP_5.TabIndex = 2;
       
            // 
            // Cember2MerkezYekseni_5
            // 
            this.Cember2MerkezYekseni_5.Location = new System.Drawing.Point(6, 201);
            this.Cember2MerkezYekseni_5.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Cember2MerkezYekseni_5.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Cember2MerkezYekseni_5.Name = "Cember2MerkezYekseni_5";
            this.Cember2MerkezYekseni_5.Size = new System.Drawing.Size(120, 23);
            this.Cember2MerkezYekseni_5.TabIndex = 2;
         
            // 
            // Cember1YARICAP_5
            // 
            this.Cember1YARICAP_5.Location = new System.Drawing.Point(6, 118);
            this.Cember1YARICAP_5.Name = "Cember1YARICAP_5";
            this.Cember1YARICAP_5.Size = new System.Drawing.Size(120, 23);
            this.Cember1YARICAP_5.TabIndex = 2;
            // 
            // Cember1MerkezYekseni_5
            // 
            this.Cember1MerkezYekseni_5.Location = new System.Drawing.Point(6, 74);
            this.Cember1MerkezYekseni_5.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Cember1MerkezYekseni_5.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Cember1MerkezYekseni_5.Name = "Cember1MerkezYekseni_5";
            this.Cember1MerkezYekseni_5.Size = new System.Drawing.Size(120, 23);
            this.Cember1MerkezYekseni_5.TabIndex = 2;
            // 
            // Cember1MerkezXekseni_5
            // 
            this.Cember1MerkezXekseni_5.Location = new System.Drawing.Point(6, 35);
            this.Cember1MerkezXekseni_5.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Cember1MerkezXekseni_5.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Cember1MerkezXekseni_5.Name = "Cember1MerkezXekseni_5";
            this.Cember1MerkezXekseni_5.Size = new System.Drawing.Size(120, 23);
            this.Cember1MerkezXekseni_5.TabIndex = 2;
            // 
            // Hesapla_Ve_Cizdir_5
            // 
            this.Hesapla_Ve_Cizdir_5.Location = new System.Drawing.Point(0, 318);
            this.Hesapla_Ve_Cizdir_5.Name = "Hesapla_Ve_Cizdir_5";
            this.Hesapla_Ve_Cizdir_5.Size = new System.Drawing.Size(123, 23);
            this.Hesapla_Ve_Cizdir_5.TabIndex = 1;
            this.Hesapla_Ve_Cizdir_5.Text = "Hesapla_Ve_Cizdir_5";
            this.Hesapla_Ve_Cizdir_5.UseVisualStyleBackColor = true;
            this.Hesapla_Ve_Cizdir_5.Click += new System.EventHandler(this.Hesapla_Ve_Cizdir_5_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(0, 271);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(44, 15);
            this.label29.TabIndex = 0;
            this.label29.Text = "label23";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(0, 227);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(210, 15);
            this.label28.TabIndex = 0;
            this.label28.Text = "lütfen 2. çemberinizin yarıçapını giriniz";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(0, 184);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(394, 15);
            this.label27.TabIndex = 0;
            this.label27.Text = "lütfen 2. çemberinizin merkezeninin y ekseni üzerindeki konumunu giriniz";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(3, 144);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(345, 15);
            this.label26.TabIndex = 0;
            this.label26.Text = "lütfen 2. çemberinizin merkezinin x eksenindeki merkezini giriniz";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 100);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(210, 15);
            this.label25.TabIndex = 0;
            this.label25.Text = "lütfen 1. çemberinizin yarıçapını giriniz";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 61);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(312, 15);
            this.label24.TabIndex = 0;
            this.label24.Text = "lütfen 1. çemberinizin y ekseni üzerindeki merkezini giriniz";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 17);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(287, 15);
            this.label23.TabIndex = 0;
            this.label23.Text = "Lütfen 1. çemberinizin x eksenindeki merkezini giriniz";
            // 
            // NoktaKureCarpisma
            // 
            this.NoktaKureCarpisma.Controls.Add(this.HesaplaVeCiz_6);
            this.NoktaKureCarpisma.Controls.Add(this.TextBoxSonuc_6);
            this.NoktaKureCarpisma.Controls.Add(this.KureYaricap_6);
            this.NoktaKureCarpisma.Controls.Add(this.KureMerkezZEkseni_6);
            this.NoktaKureCarpisma.Controls.Add(this.KureMerkezYEkseni_6);
            this.NoktaKureCarpisma.Controls.Add(this.KureMerkezXEkseni_6);
            this.NoktaKureCarpisma.Controls.Add(this.NoktaZekseni_6);
            this.NoktaKureCarpisma.Controls.Add(this.NoktaYekseni_6);
            this.NoktaKureCarpisma.Controls.Add(this.NoktaXekseni_6);
            this.NoktaKureCarpisma.Controls.Add(this.label37);
            this.NoktaKureCarpisma.Controls.Add(this.label36);
            this.NoktaKureCarpisma.Controls.Add(this.label35);
            this.NoktaKureCarpisma.Controls.Add(this.label34);
            this.NoktaKureCarpisma.Controls.Add(this.label33);
            this.NoktaKureCarpisma.Controls.Add(this.label32);
            this.NoktaKureCarpisma.Controls.Add(this.label31);
            this.NoktaKureCarpisma.Controls.Add(this.label30);
            this.NoktaKureCarpisma.Location = new System.Drawing.Point(4, 24);
            this.NoktaKureCarpisma.Name = "NoktaKureCarpisma";
            this.NoktaKureCarpisma.Padding = new System.Windows.Forms.Padding(3);
            this.NoktaKureCarpisma.Size = new System.Drawing.Size(423, 542);
            this.NoktaKureCarpisma.TabIndex = 5;
            this.NoktaKureCarpisma.Text = "NoktaKureCarpisma";
            this.NoktaKureCarpisma.UseVisualStyleBackColor = true;
            // 
            // HesaplaVeCiz_6
            // 
            this.HesaplaVeCiz_6.Location = new System.Drawing.Point(0, 378);
            this.HesaplaVeCiz_6.Name = "HesaplaVeCiz_6";
            this.HesaplaVeCiz_6.Size = new System.Drawing.Size(123, 29);
            this.HesaplaVeCiz_6.TabIndex = 3;
            this.HesaplaVeCiz_6.Text = "HesaplaVeCiz_6";
            this.HesaplaVeCiz_6.UseVisualStyleBackColor = true;
            this.HesaplaVeCiz_6.Click += new System.EventHandler(this.HesaplaVeCiz_6_Click);
            // 
            // TextBoxSonuc_6
            // 
            this.TextBoxSonuc_6.Location = new System.Drawing.Point(3, 340);
            this.TextBoxSonuc_6.Name = "TextBoxSonuc_6";
            this.TextBoxSonuc_6.Size = new System.Drawing.Size(123, 23);
            this.TextBoxSonuc_6.TabIndex = 2;
            // 
            // KureYaricap_6
            // 
            this.KureYaricap_6.Location = new System.Drawing.Point(3, 296);
            this.KureYaricap_6.Name = "KureYaricap_6";
            this.KureYaricap_6.Size = new System.Drawing.Size(120, 23);
            this.KureYaricap_6.TabIndex = 1;
          
            // 
            // KureMerkezZEkseni_6
            // 
            this.KureMerkezZEkseni_6.Location = new System.Drawing.Point(3, 252);
            this.KureMerkezZEkseni_6.Name = "KureMerkezZEkseni_6";
            this.KureMerkezZEkseni_6.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezZEkseni_6.TabIndex = 1;
        
            // 
            // KureMerkezYEkseni_6
            // 
            this.KureMerkezYEkseni_6.Location = new System.Drawing.Point(3, 208);
            this.KureMerkezYEkseni_6.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.KureMerkezYEkseni_6.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.KureMerkezYEkseni_6.Name = "KureMerkezYEkseni_6";
            this.KureMerkezYEkseni_6.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezYEkseni_6.TabIndex = 1;
           
            // 
            // KureMerkezXEkseni_6
            // 
            this.KureMerkezXEkseni_6.Location = new System.Drawing.Point(6, 164);
            this.KureMerkezXEkseni_6.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.KureMerkezXEkseni_6.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.KureMerkezXEkseni_6.Name = "KureMerkezXEkseni_6";
            this.KureMerkezXEkseni_6.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezXEkseni_6.TabIndex = 1;
            
            // 
            // NoktaZekseni_6
            // 
            this.NoktaZekseni_6.Location = new System.Drawing.Point(6, 120);
            this.NoktaZekseni_6.Name = "NoktaZekseni_6";
            this.NoktaZekseni_6.Size = new System.Drawing.Size(120, 23);
            this.NoktaZekseni_6.TabIndex = 1;
            // 
            // NoktaYekseni_6
            // 
            this.NoktaYekseni_6.Location = new System.Drawing.Point(6, 79);
            this.NoktaYekseni_6.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.NoktaYekseni_6.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.NoktaYekseni_6.Name = "NoktaYekseni_6";
            this.NoktaYekseni_6.Size = new System.Drawing.Size(120, 23);
            this.NoktaYekseni_6.TabIndex = 1;
            // 
            // NoktaXekseni_6
            // 
            this.NoktaXekseni_6.Location = new System.Drawing.Point(6, 35);
            this.NoktaXekseni_6.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.NoktaXekseni_6.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.NoktaXekseni_6.Name = "NoktaXekseni_6";
            this.NoktaXekseni_6.Size = new System.Drawing.Size(120, 23);
            this.NoktaXekseni_6.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(3, 322);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(42, 15);
            this.label37.TabIndex = 0;
            this.label37.Text = "sunuç;";
      
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(3, 278);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(145, 15);
            this.label36.TabIndex = 0;
            this.label36.Text = "Kurenizin yarıçapını giriniz";
          
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(3, 234);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(280, 15);
            this.label35.TabIndex = 0;
            this.label35.Text = "Kurenizin Z Eksenine göre merkez konumunu giriniz";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(3, 190);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(280, 15);
            this.label34.TabIndex = 0;
            this.label34.Text = "Kurenizin Y Eksenine göre merkez konumunu giriniz";
           
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 146);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(280, 15);
            this.label33.TabIndex = 0;
            this.label33.Text = "Kurenizin X eksenine gore merkez konumunu giriniz";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 101);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(236, 15);
            this.label32.TabIndex = 0;
            this.label32.Text = "Noktanızın Z eksenindeki konumunu giriniz";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 61);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(236, 15);
            this.label31.TabIndex = 0;
            this.label31.Text = "Noktanızın Y eksenindeki konumunu giriniz";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 16);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(236, 15);
            this.label30.TabIndex = 0;
            this.label30.Text = "Noktanızın X eksenindeki konumunu giriniz";
            // 
            // NoktaDikdortgenCarpisma
            // 
            this.NoktaDikdortgenCarpisma.Controls.Add(this.textBoxSonuc_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.HesaplaVeÇizButton_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label47);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label46);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label45);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label43);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label42);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label44);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label40);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label41);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label39);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.label38);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.DidortgenPrizmaEn_x_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezX_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.NoktaX_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.DidortgenPrizmaDerinlik_Z_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.DidortgenPrizmaBoy_Y_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezZ_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezY_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.NoktaZ_7);
            this.NoktaDikdortgenCarpisma.Controls.Add(this.NoktaY_7);
            this.NoktaDikdortgenCarpisma.Location = new System.Drawing.Point(4, 24);
            this.NoktaDikdortgenCarpisma.Name = "NoktaDikdortgenCarpisma";
            this.NoktaDikdortgenCarpisma.Size = new System.Drawing.Size(423, 542);
            this.NoktaDikdortgenCarpisma.TabIndex = 6;
            this.NoktaDikdortgenCarpisma.Text = "NoktaDikdortgenCarpisma";
            this.NoktaDikdortgenCarpisma.UseVisualStyleBackColor = true;
            // 
            // textBoxSonuc_7
            // 
            this.textBoxSonuc_7.Location = new System.Drawing.Point(12, 442);
            this.textBoxSonuc_7.Name = "textBoxSonuc_7";
            this.textBoxSonuc_7.Size = new System.Drawing.Size(100, 23);
            this.textBoxSonuc_7.TabIndex = 3;
            // 
            // HesaplaVeÇizButton_7
            // 
            this.HesaplaVeÇizButton_7.Location = new System.Drawing.Point(12, 479);
            this.HesaplaVeÇizButton_7.Name = "HesaplaVeÇizButton_7";
            this.HesaplaVeÇizButton_7.Size = new System.Drawing.Size(132, 23);
            this.HesaplaVeÇizButton_7.TabIndex = 2;
            this.HesaplaVeÇizButton_7.Text = "HesaplaVeÇizButton_7";
            this.HesaplaVeÇizButton_7.UseVisualStyleBackColor = true;
            this.HesaplaVeÇizButton_7.Click += new System.EventHandler(this.HesaplaVeÇizButton_7_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(12, 424);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(43, 15);
            this.label47.TabIndex = 1;
            this.label47.Text = "Sonuc:";
            
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(12, 370);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(272, 15);
            this.label46.TabIndex = 1;
            this.label46.Text = "Lutfen dikdortgen prizmanızın derinliğini(Z) giriniz";
            
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(12, 321);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(259, 15);
            this.label45.TabIndex = 1;
            this.label45.Text = "Lutfen dikdortgen prizmanızın boyunu(y) giriniz";
          
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(12, 221);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(424, 15);
            this.label43.TabIndex = 1;
            this.label43.Text = "Lutfen dikdortgen prizmanızın merkez noktası için z eksenindeki değerini giriniz";
            
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(12, 176);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(426, 15);
            this.label42.TabIndex = 1;
            this.label42.Text = "Lutfen dikdortgen prizmanızın merkez noktası için Y eksenindeki değerini giriniz";
            
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(12, 277);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(244, 15);
            this.label44.TabIndex = 1;
            this.label44.Text = "Lutfen dikdortgen prizmanızın enini(x) giriniz";
            
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(12, 87);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(190, 15);
            this.label40.TabIndex = 1;
            this.label40.Text = "Lütfen noktanızın Z eksenini giriniz";
            
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(12, 132);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(426, 15);
            this.label41.TabIndex = 1;
            this.label41.Text = "Lutfen dikdortgen prizmanızın merkez noktası için X eksenindeki değerini giriniz";
      
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 43);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(190, 15);
            this.label39.TabIndex = 1;
            this.label39.Text = "Lütfen noktanızın Y eksenini giriniz";
           
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(12, 3);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(190, 15);
            this.label38.TabIndex = 1;
            this.label38.Text = "Lütfen noktanızın X eksenini giriniz";
           
            // 
            // DidortgenPrizmaEn_x_7
            // 
            this.DidortgenPrizmaEn_x_7.Location = new System.Drawing.Point(12, 295);
            this.DidortgenPrizmaEn_x_7.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.DidortgenPrizmaEn_x_7.Name = "DidortgenPrizmaEn_x_7";
            this.DidortgenPrizmaEn_x_7.Size = new System.Drawing.Size(120, 23);
            this.DidortgenPrizmaEn_x_7.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezX_7
            // 
            this.DikdortgenPrizmaMerkezX_7.Location = new System.Drawing.Point(12, 150);
            this.DikdortgenPrizmaMerkezX_7.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.DikdortgenPrizmaMerkezX_7.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.DikdortgenPrizmaMerkezX_7.Name = "DikdortgenPrizmaMerkezX_7";
            this.DikdortgenPrizmaMerkezX_7.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezX_7.TabIndex = 0;
            // 
            // NoktaX_7
            // 
            this.NoktaX_7.Location = new System.Drawing.Point(12, 21);
            this.NoktaX_7.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.NoktaX_7.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.NoktaX_7.Name = "NoktaX_7";
            this.NoktaX_7.Size = new System.Drawing.Size(120, 23);
            this.NoktaX_7.TabIndex = 0;
            // 
            // DidortgenPrizmaDerinlik_Z_7
            // 
            this.DidortgenPrizmaDerinlik_Z_7.Location = new System.Drawing.Point(12, 388);
            this.DidortgenPrizmaDerinlik_Z_7.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.DidortgenPrizmaDerinlik_Z_7.Name = "DidortgenPrizmaDerinlik_Z_7";
            this.DidortgenPrizmaDerinlik_Z_7.Size = new System.Drawing.Size(120, 23);
            this.DidortgenPrizmaDerinlik_Z_7.TabIndex = 0;
          
            // 
            // DidortgenPrizmaBoy_Y_7
            // 
            this.DidortgenPrizmaBoy_Y_7.Location = new System.Drawing.Point(12, 340);
            this.DidortgenPrizmaBoy_Y_7.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.DidortgenPrizmaBoy_Y_7.Name = "DidortgenPrizmaBoy_Y_7";
            this.DidortgenPrizmaBoy_Y_7.Size = new System.Drawing.Size(120, 23);
            this.DidortgenPrizmaBoy_Y_7.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezZ_7
            // 
            this.DikdortgenPrizmaMerkezZ_7.Location = new System.Drawing.Point(12, 243);
            this.DikdortgenPrizmaMerkezZ_7.Name = "DikdortgenPrizmaMerkezZ_7";
            this.DikdortgenPrizmaMerkezZ_7.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezZ_7.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezY_7
            // 
            this.DikdortgenPrizmaMerkezY_7.Location = new System.Drawing.Point(12, 195);
            this.DikdortgenPrizmaMerkezY_7.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.DikdortgenPrizmaMerkezY_7.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.DikdortgenPrizmaMerkezY_7.Name = "DikdortgenPrizmaMerkezY_7";
            this.DikdortgenPrizmaMerkezY_7.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezY_7.TabIndex = 0;
            // 
            // NoktaZ_7
            // 
            this.NoktaZ_7.Location = new System.Drawing.Point(12, 105);
            this.NoktaZ_7.Name = "NoktaZ_7";
            this.NoktaZ_7.Size = new System.Drawing.Size(120, 23);
            this.NoktaZ_7.TabIndex = 0;
            // 
            // NoktaY_7
            // 
            this.NoktaY_7.Location = new System.Drawing.Point(12, 61);
            this.NoktaY_7.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.NoktaY_7.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.NoktaY_7.Name = "NoktaY_7";
            this.NoktaY_7.Size = new System.Drawing.Size(120, 23);
            this.NoktaY_7.TabIndex = 0;
            // 
            // NoktaSilindirCarpisma
            // 
            this.NoktaSilindirCarpisma.Controls.Add(this.label56);
            this.NoktaSilindirCarpisma.Controls.Add(this.SilindirBoy_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.TextBoxSonuc_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.HesaplaVeCızButton_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.label55);
            this.NoktaSilindirCarpisma.Controls.Add(this.label54);
            this.NoktaSilindirCarpisma.Controls.Add(this.label53);
            this.NoktaSilindirCarpisma.Controls.Add(this.label52);
            this.NoktaSilindirCarpisma.Controls.Add(this.label51);
            this.NoktaSilindirCarpisma.Controls.Add(this.label50);
            this.NoktaSilindirCarpisma.Controls.Add(this.label49);
            this.NoktaSilindirCarpisma.Controls.Add(this.label48);
            this.NoktaSilindirCarpisma.Controls.Add(this.SilindirYariCap_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.SilindirZEkseni_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.SilindirYEkseni_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.SilindirXEkseni_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.NoktaZEkseni_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.NoktaYEkseni_8);
            this.NoktaSilindirCarpisma.Controls.Add(this.NoktaXEkseni_8);
            this.NoktaSilindirCarpisma.Location = new System.Drawing.Point(4, 24);
            this.NoktaSilindirCarpisma.Name = "NoktaSilindirCarpisma";
            this.NoktaSilindirCarpisma.Size = new System.Drawing.Size(423, 542);
            this.NoktaSilindirCarpisma.TabIndex = 7;
            this.NoktaSilindirCarpisma.Text = "NoktaSilindirCarpisma";
            this.NoktaSilindirCarpisma.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(12, 301);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(186, 15);
            this.label56.TabIndex = 5;
            this.label56.Text = "Lutfen silindirinizin boyunu giriniz";
            // 
            // SilindirBoy_8
            // 
            this.SilindirBoy_8.Location = new System.Drawing.Point(12, 319);
            this.SilindirBoy_8.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.SilindirBoy_8.Name = "SilindirBoy_8";
            this.SilindirBoy_8.Size = new System.Drawing.Size(120, 23);
            this.SilindirBoy_8.TabIndex = 4;
            // 
            // TextBoxSonuc_8
            // 
            this.TextBoxSonuc_8.Location = new System.Drawing.Point(3, 446);
            this.TextBoxSonuc_8.Name = "TextBoxSonuc_8";
            this.TextBoxSonuc_8.Size = new System.Drawing.Size(252, 23);
            this.TextBoxSonuc_8.TabIndex = 3;
            // 
            // HesaplaVeCızButton_8
            // 
            this.HesaplaVeCızButton_8.Location = new System.Drawing.Point(3, 417);
            this.HesaplaVeCızButton_8.Name = "HesaplaVeCızButton_8";
            this.HesaplaVeCızButton_8.Size = new System.Drawing.Size(120, 23);
            this.HesaplaVeCızButton_8.TabIndex = 2;
            this.HesaplaVeCızButton_8.Text = "Hesapla Ve Ciz 8";
            this.HesaplaVeCızButton_8.UseVisualStyleBackColor = true;
            this.HesaplaVeCızButton_8.Click += new System.EventHandler(this.HesaplaVeCızButton_8_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(3, 345);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(196, 15);
            this.label55.TabIndex = 1;
            this.label55.Text = "Lutfen sılındırınızın yarıcapını gırınız";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(17, 399);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(40, 15);
            this.label54.TabIndex = 1;
            this.label54.Text = "Sonuc";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(12, 249);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(320, 15);
            this.label53.TabIndex = 1;
            this.label53.Text = "Lutfen silindirinizin Z eksenine gore merkez noktasını gırınız";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(12, 204);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(320, 15);
            this.label52.TabIndex = 1;
            this.label52.Text = "Lutfen silindirinizin Y eksenine gore merkez noktasını gırınız";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(12, 159);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(320, 15);
            this.label51.TabIndex = 1;
            this.label51.Text = "Lutfen silindirinizin X eksenine gore merkez noktasını gırınız";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(12, 115);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(282, 15);
            this.label50.TabIndex = 1;
            this.label50.Text = "Lutfen noktanızın Z eksenıne gore konumunu giriniz";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(12, 62);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(282, 15);
            this.label49.TabIndex = 1;
            this.label49.Text = "Lutfen noktanızın Y eksenıne gore konumunu giriniz";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(12, 18);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(282, 15);
            this.label48.TabIndex = 1;
            this.label48.Text = "Lutfen noktanızın X eksenıne gore konumunu giriniz";
            // 
            // SilindirYariCap_8
            // 
            this.SilindirYariCap_8.Location = new System.Drawing.Point(12, 373);
            this.SilindirYariCap_8.Name = "SilindirYariCap_8";
            this.SilindirYariCap_8.Size = new System.Drawing.Size(120, 23);
            this.SilindirYariCap_8.TabIndex = 0;
            // 
            // SilindirZEkseni_8
            // 
            this.SilindirZEkseni_8.Location = new System.Drawing.Point(12, 267);
            this.SilindirZEkseni_8.Name = "SilindirZEkseni_8";
            this.SilindirZEkseni_8.Size = new System.Drawing.Size(120, 23);
            this.SilindirZEkseni_8.TabIndex = 0;
            // 
            // SilindirYEkseni_8
            // 
            this.SilindirYEkseni_8.Location = new System.Drawing.Point(12, 222);
            this.SilindirYEkseni_8.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.SilindirYEkseni_8.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.SilindirYEkseni_8.Name = "SilindirYEkseni_8";
            this.SilindirYEkseni_8.Size = new System.Drawing.Size(120, 23);
            this.SilindirYEkseni_8.TabIndex = 0;
            this.SilindirYEkseni_8.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            // 
            // SilindirXEkseni_8
            // 
            this.SilindirXEkseni_8.Location = new System.Drawing.Point(12, 175);
            this.SilindirXEkseni_8.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.SilindirXEkseni_8.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.SilindirXEkseni_8.Name = "SilindirXEkseni_8";
            this.SilindirXEkseni_8.Size = new System.Drawing.Size(120, 23);
            this.SilindirXEkseni_8.TabIndex = 0;
            // 
            // NoktaZEkseni_8
            // 
            this.NoktaZEkseni_8.Location = new System.Drawing.Point(12, 133);
            this.NoktaZEkseni_8.Name = "NoktaZEkseni_8";
            this.NoktaZEkseni_8.Size = new System.Drawing.Size(120, 23);
            this.NoktaZEkseni_8.TabIndex = 0;
            // 
            // NoktaYEkseni_8
            // 
            this.NoktaYEkseni_8.Location = new System.Drawing.Point(12, 80);
            this.NoktaYEkseni_8.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.NoktaYEkseni_8.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.NoktaYEkseni_8.Name = "NoktaYEkseni_8";
            this.NoktaYEkseni_8.Size = new System.Drawing.Size(120, 23);
            this.NoktaYEkseni_8.TabIndex = 0;
            // 
            // NoktaXEkseni_8
            // 
            this.NoktaXEkseni_8.Location = new System.Drawing.Point(12, 36);
            this.NoktaXEkseni_8.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.NoktaXEkseni_8.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.NoktaXEkseni_8.Name = "NoktaXEkseni_8";
            this.NoktaXEkseni_8.Size = new System.Drawing.Size(120, 23);
            this.NoktaXEkseni_8.TabIndex = 0;
            // 
            // SilindirSilindirCarpisma
            // 
            this.SilindirSilindirCarpisma.Controls.Add(this.label68);
            this.SilindirSilindirCarpisma.Controls.Add(this.label67);
            this.SilindirSilindirCarpisma.Controls.Add(this.label66);
            this.SilindirSilindirCarpisma.Controls.Add(this.label65);
            this.SilindirSilindirCarpisma.Controls.Add(this.label64);
            this.SilindirSilindirCarpisma.Controls.Add(this.label63);
            this.SilindirSilindirCarpisma.Controls.Add(this.label62);
            this.SilindirSilindirCarpisma.Controls.Add(this.label61);
            this.SilindirSilindirCarpisma.Controls.Add(this.label60);
            this.SilindirSilindirCarpisma.Controls.Add(this.label59);
            this.SilindirSilindirCarpisma.Controls.Add(this.label58);
            this.SilindirSilindirCarpisma.Controls.Add(this.label57);
            this.SilindirSilindirCarpisma.Controls.Add(this.textBoxSonuc_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.Hesapla_ve_ciz_9_button);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir2Yaricap_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir2Boy_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.numericUpDown10);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir2ZMerkez_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir2YMerkez_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir2XMerkez_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir1Yaricap_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir1Boy_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir1ZMerkez_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir1YMerkez_9);
            this.SilindirSilindirCarpisma.Controls.Add(this.silindir1XMerkez_9);
            this.SilindirSilindirCarpisma.Location = new System.Drawing.Point(4, 24);
            this.SilindirSilindirCarpisma.Name = "SilindirSilindirCarpisma";
            this.SilindirSilindirCarpisma.Size = new System.Drawing.Size(423, 542);
            this.SilindirSilindirCarpisma.TabIndex = 8;
            this.SilindirSilindirCarpisma.Text = "SilindirSilindirCarpisma";
            this.SilindirSilindirCarpisma.UseVisualStyleBackColor = true;
           
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(181, 493);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(43, 15);
            this.label68.TabIndex = 3;
            this.label68.Text = "Sonuc:";
            
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(12, 461);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(190, 15);
            this.label67.TabIndex = 3;
            this.label67.Text = "İkinci silindirinizin yaricapini giriniz";
         
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(12, 461);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(44, 15);
            this.label66.TabIndex = 3;
            this.label66.Text = "label57";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(12, 417);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(180, 15);
            this.label65.TabIndex = 3;
            this.label65.Text = "İkinci silindirinizin boyunu giriniz";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(12, 367);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(267, 15);
            this.label64.TabIndex = 3;
            this.label64.Text = "ikinci silindiriz için Z eksenindeki merkezini giriniz";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(12, 315);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(267, 15);
            this.label63.TabIndex = 3;
            this.label63.Text = "ikinci silindiriz için Y eksenindeki merkezini giriniz";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(12, 271);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(267, 15);
            this.label62.TabIndex = 3;
            this.label62.Text = "ikinci silindiriz için X eksenindeki merkezini giriniz";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(12, 219);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(195, 15);
            this.label61.TabIndex = 3;
            this.label61.Text = "Birinci silindirinizin yaricapini giriniz";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(12, 168);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(178, 15);
            this.label60.TabIndex = 3;
            this.label60.Text = "Birinci silindiriniiz boyunu giriniz";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(12, 116);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(272, 15);
            this.label59.TabIndex = 3;
            this.label59.Text = "Birinci silindiriz için Z eksenindeki merkezini giriniz";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(12, 66);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(272, 15);
            this.label58.TabIndex = 3;
            this.label58.Text = "Birinci silindiriz için Y eksenindeki merkezini giriniz";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(12, 14);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(272, 15);
            this.label57.TabIndex = 3;
            this.label57.Text = "Birinci silindiriz için X eksenindeki merkezini giriniz";
            // 
            // textBoxSonuc_9
            // 
            this.textBoxSonuc_9.Location = new System.Drawing.Point(35, 511);
            this.textBoxSonuc_9.Name = "textBoxSonuc_9";
            this.textBoxSonuc_9.Size = new System.Drawing.Size(337, 23);
            this.textBoxSonuc_9.TabIndex = 2;
            // 
            // Hesapla_ve_ciz_9_button
            // 
            this.Hesapla_ve_ciz_9_button.Location = new System.Drawing.Point(245, 435);
            this.Hesapla_ve_ciz_9_button.Name = "Hesapla_ve_ciz_9_button";
            this.Hesapla_ve_ciz_9_button.Size = new System.Drawing.Size(161, 23);
            this.Hesapla_ve_ciz_9_button.TabIndex = 1;
            this.Hesapla_ve_ciz_9_button.Text = "Hesapla_ve_ciz_9_button";
            this.Hesapla_ve_ciz_9_button.UseVisualStyleBackColor = true;
            this.Hesapla_ve_ciz_9_button.Click += new System.EventHandler(this.Hesapla_ve_ciz_9_button_Click);
            // 
            // silindir2Yaricap_9
            // 
            this.silindir2Yaricap_9.Location = new System.Drawing.Point(12, 479);
            this.silindir2Yaricap_9.Name = "silindir2Yaricap_9";
            this.silindir2Yaricap_9.Size = new System.Drawing.Size(120, 23);
            this.silindir2Yaricap_9.TabIndex = 0;
            
            // 
            // silindir2Boy_9
            // 
            this.silindir2Boy_9.Location = new System.Drawing.Point(12, 435);
            this.silindir2Boy_9.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.silindir2Boy_9.Name = "silindir2Boy_9";
            this.silindir2Boy_9.Size = new System.Drawing.Size(120, 23);
            this.silindir2Boy_9.TabIndex = 0;
            
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.Location = new System.Drawing.Point(12, 435);
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown10.TabIndex = 0;
            
            // 
            // silindir2ZMerkez_9
            // 
            this.silindir2ZMerkez_9.Location = new System.Drawing.Point(12, 385);
            this.silindir2ZMerkez_9.Name = "silindir2ZMerkez_9";
            this.silindir2ZMerkez_9.Size = new System.Drawing.Size(120, 23);
            this.silindir2ZMerkez_9.TabIndex = 0;
          
            // 
            // silindir2YMerkez_9
            // 
            this.silindir2YMerkez_9.Location = new System.Drawing.Point(12, 341);
            this.silindir2YMerkez_9.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.silindir2YMerkez_9.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.silindir2YMerkez_9.Name = "silindir2YMerkez_9";
            this.silindir2YMerkez_9.Size = new System.Drawing.Size(120, 23);
            this.silindir2YMerkez_9.TabIndex = 0;
         
            // 
            // silindir2XMerkez_9
            // 
            this.silindir2XMerkez_9.Location = new System.Drawing.Point(12, 289);
            this.silindir2XMerkez_9.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.silindir2XMerkez_9.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.silindir2XMerkez_9.Name = "silindir2XMerkez_9";
            this.silindir2XMerkez_9.Size = new System.Drawing.Size(120, 23);
            this.silindir2XMerkez_9.TabIndex = 0;
            
            // 
            // silindir1Yaricap_9
            // 
            this.silindir1Yaricap_9.Location = new System.Drawing.Point(12, 237);
            this.silindir1Yaricap_9.Name = "silindir1Yaricap_9";
            this.silindir1Yaricap_9.Size = new System.Drawing.Size(120, 23);
            this.silindir1Yaricap_9.TabIndex = 0;
         
            // 
            // silindir1Boy_9
            // 
            this.silindir1Boy_9.Location = new System.Drawing.Point(12, 186);
            this.silindir1Boy_9.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.silindir1Boy_9.Name = "silindir1Boy_9";
            this.silindir1Boy_9.Size = new System.Drawing.Size(120, 23);
            this.silindir1Boy_9.TabIndex = 0;
           
            // 
            // silindir1ZMerkez_9
            // 
            this.silindir1ZMerkez_9.Location = new System.Drawing.Point(12, 134);
            this.silindir1ZMerkez_9.Name = "silindir1ZMerkez_9";
            this.silindir1ZMerkez_9.Size = new System.Drawing.Size(120, 23);
            this.silindir1ZMerkez_9.TabIndex = 0;
           
            // 
            // silindir1YMerkez_9
            // 
            this.silindir1YMerkez_9.Location = new System.Drawing.Point(12, 84);
            this.silindir1YMerkez_9.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.silindir1YMerkez_9.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.silindir1YMerkez_9.Name = "silindir1YMerkez_9";
            this.silindir1YMerkez_9.Size = new System.Drawing.Size(120, 23);
            this.silindir1YMerkez_9.TabIndex = 0;
            
            // 
            // silindir1XMerkez_9
            // 
            this.silindir1XMerkez_9.Location = new System.Drawing.Point(12, 32);
            this.silindir1XMerkez_9.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.silindir1XMerkez_9.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.silindir1XMerkez_9.Name = "silindir1XMerkez_9";
            this.silindir1XMerkez_9.Size = new System.Drawing.Size(120, 23);
            this.silindir1XMerkez_9.TabIndex = 0;
           
            // 
            // KureKureCarpisma
            // 
            this.KureKureCarpisma.Controls.Add(this.label78);
            this.KureKureCarpisma.Controls.Add(this.label77);
            this.KureKureCarpisma.Controls.Add(this.label76);
            this.KureKureCarpisma.Controls.Add(this.label75);
            this.KureKureCarpisma.Controls.Add(this.label72);
            this.KureKureCarpisma.Controls.Add(this.label74);
            this.KureKureCarpisma.Controls.Add(this.label71);
            this.KureKureCarpisma.Controls.Add(this.label73);
            this.KureKureCarpisma.Controls.Add(this.Kure1Zekseni_10);
            this.KureKureCarpisma.Controls.Add(this.label69);
            this.KureKureCarpisma.Controls.Add(this.Kure2Yaricap_10);
            this.KureKureCarpisma.Controls.Add(this.Kure2Zekseni_10);
            this.KureKureCarpisma.Controls.Add(this.Kure2Yekseni_10);
            this.KureKureCarpisma.Controls.Add(this.Kure2Xekseni_10);
            this.KureKureCarpisma.Controls.Add(this.Kure1Yaricap_10);
            this.KureKureCarpisma.Controls.Add(this.Kureniz1Zekseni_10);
            this.KureKureCarpisma.Controls.Add(this.Kure1Yekseni_10);
            this.KureKureCarpisma.Controls.Add(this.Kure1Xekseni_10);
            this.KureKureCarpisma.Controls.Add(this.textBoxSonuc_10);
            this.KureKureCarpisma.Controls.Add(this.hesapla_ve_cız_button_10);
            this.KureKureCarpisma.Location = new System.Drawing.Point(4, 24);
            this.KureKureCarpisma.Name = "KureKureCarpisma";
            this.KureKureCarpisma.Size = new System.Drawing.Size(423, 542);
            this.KureKureCarpisma.TabIndex = 9;
            this.KureKureCarpisma.Text = "KureKureCarpisma";
            this.KureKureCarpisma.UseVisualStyleBackColor = true;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(19, 421);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(42, 15);
            this.label78.TabIndex = 4;
            this.label78.Text = "sonuc:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(19, 421);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(0, 15);
            this.label77.TabIndex = 3;
            
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(19, 377);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(156, 15);
            this.label76.TabIndex = 3;
            this.label76.Text = "2. kürenizin yarıçapını giriniz";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(19, 326);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(309, 15);
            this.label75.TabIndex = 3;
            this.label75.Text = "2. Kurenizin Z ekseni üzerindeki merkez konumunu giriniz";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(19, 176);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(157, 15);
            this.label72.TabIndex = 3;
            this.label72.Text = "1. Kurenizin yarıcapını giriniz";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(19, 283);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(309, 15);
            this.label74.TabIndex = 3;
            this.label74.Text = "2. Kurenizin Y ekseni üzerindeki merkez konumunu giriniz";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(27, 125);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(309, 15);
            this.label71.TabIndex = 3;
            this.label71.Text = "1. Kurenizin Z ekseni üzerindeki merkez konumunu giriniz";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(19, 226);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(309, 15);
            this.label73.TabIndex = 3;
            this.label73.Text = "2. Kurenizin X ekseni üzerindeki merkez konumunu giriniz";
            // 
            // Kure1Zekseni_10
            // 
            this.Kure1Zekseni_10.AutoSize = true;
            this.Kure1Zekseni_10.Location = new System.Drawing.Point(27, 82);
            this.Kure1Zekseni_10.Name = "Kure1Zekseni_10";
            this.Kure1Zekseni_10.Size = new System.Drawing.Size(309, 15);
            this.Kure1Zekseni_10.TabIndex = 3;
            this.Kure1Zekseni_10.Text = "1. Kurenizin Y ekseni üzerindeki merkez konumunu giriniz";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(19, 31);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(309, 15);
            this.label69.TabIndex = 3;
            this.label69.Text = "1. Kurenizin X ekseni üzerindeki merkez konumunu giriniz";
            // 
            // Kure2Yaricap_10
            // 
            this.Kure2Yaricap_10.Location = new System.Drawing.Point(19, 395);
            this.Kure2Yaricap_10.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.Kure2Yaricap_10.Name = "Kure2Yaricap_10";
            this.Kure2Yaricap_10.Size = new System.Drawing.Size(120, 23);
            this.Kure2Yaricap_10.TabIndex = 2;
            // 
            // Kure2Zekseni_10
            // 
            this.Kure2Zekseni_10.Location = new System.Drawing.Point(19, 344);
            this.Kure2Zekseni_10.Name = "Kure2Zekseni_10";
            this.Kure2Zekseni_10.Size = new System.Drawing.Size(120, 23);
            this.Kure2Zekseni_10.TabIndex = 2;
            // 
            // Kure2Yekseni_10
            // 
            this.Kure2Yekseni_10.Location = new System.Drawing.Point(19, 300);
            this.Kure2Yekseni_10.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Kure2Yekseni_10.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Kure2Yekseni_10.Name = "Kure2Yekseni_10";
            this.Kure2Yekseni_10.Size = new System.Drawing.Size(120, 23);
            this.Kure2Yekseni_10.TabIndex = 2;
            // 
            // Kure2Xekseni_10
            // 
            this.Kure2Xekseni_10.Location = new System.Drawing.Point(19, 249);
            this.Kure2Xekseni_10.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Kure2Xekseni_10.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Kure2Xekseni_10.Name = "Kure2Xekseni_10";
            this.Kure2Xekseni_10.Size = new System.Drawing.Size(120, 23);
            this.Kure2Xekseni_10.TabIndex = 2;
            // 
            // Kure1Yaricap_10
            // 
            this.Kure1Yaricap_10.Location = new System.Drawing.Point(19, 194);
            this.Kure1Yaricap_10.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.Kure1Yaricap_10.Name = "Kure1Yaricap_10";
            this.Kure1Yaricap_10.Size = new System.Drawing.Size(120, 23);
            this.Kure1Yaricap_10.TabIndex = 2;
            // 
            // Kureniz1Zekseni_10
            // 
            this.Kureniz1Zekseni_10.Location = new System.Drawing.Point(19, 143);
            this.Kureniz1Zekseni_10.Name = "Kureniz1Zekseni_10";
            this.Kureniz1Zekseni_10.Size = new System.Drawing.Size(120, 23);
            this.Kureniz1Zekseni_10.TabIndex = 2;
            // 
            // Kure1Yekseni_10
            // 
            this.Kure1Yekseni_10.Location = new System.Drawing.Point(19, 100);
            this.Kure1Yekseni_10.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.Kure1Yekseni_10.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.Kure1Yekseni_10.Name = "Kure1Yekseni_10";
            this.Kure1Yekseni_10.Size = new System.Drawing.Size(120, 23);
            this.Kure1Yekseni_10.TabIndex = 2;
            // 
            // Kure1Xekseni_10
            // 
            this.Kure1Xekseni_10.Location = new System.Drawing.Point(19, 49);
            this.Kure1Xekseni_10.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.Kure1Xekseni_10.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.Kure1Xekseni_10.Name = "Kure1Xekseni_10";
            this.Kure1Xekseni_10.Size = new System.Drawing.Size(120, 23);
            this.Kure1Xekseni_10.TabIndex = 2;
            // 
            // textBoxSonuc_10
            // 
            this.textBoxSonuc_10.Location = new System.Drawing.Point(19, 439);
            this.textBoxSonuc_10.Name = "textBoxSonuc_10";
            this.textBoxSonuc_10.Size = new System.Drawing.Size(131, 23);
            this.textBoxSonuc_10.TabIndex = 1;
            // 
            // hesapla_ve_cız_button_10
            // 
            this.hesapla_ve_cız_button_10.Location = new System.Drawing.Point(224, 438);
            this.hesapla_ve_cız_button_10.Name = "hesapla_ve_cız_button_10";
            this.hesapla_ve_cız_button_10.Size = new System.Drawing.Size(161, 23);
            this.hesapla_ve_cız_button_10.TabIndex = 0;
            this.hesapla_ve_cız_button_10.Text = "hesapla_ve_cız_button_10";
            this.hesapla_ve_cız_button_10.UseVisualStyleBackColor = true;
            this.hesapla_ve_cız_button_10.Click += new System.EventHandler(this.hesapla_ve_cız_button_10_Click);
            // 
            // KureSilindirCarpisma
            // 
            this.KureSilindirCarpisma.Controls.Add(this.label87);
            this.KureSilindirCarpisma.Controls.Add(this.textBoxSonuc_11);
            this.KureSilindirCarpisma.Controls.Add(this.Hesapla_ve_Ciz_11);
            this.KureSilindirCarpisma.Controls.Add(this.label86);
            this.KureSilindirCarpisma.Controls.Add(this.label85);
            this.KureSilindirCarpisma.Controls.Add(this.label84);
            this.KureSilindirCarpisma.Controls.Add(this.label81);
            this.KureSilindirCarpisma.Controls.Add(this.label83);
            this.KureSilindirCarpisma.Controls.Add(this.label80);
            this.KureSilindirCarpisma.Controls.Add(this.label82);
            this.KureSilindirCarpisma.Controls.Add(this.label79);
            this.KureSilindirCarpisma.Controls.Add(this.label70);
            this.KureSilindirCarpisma.Controls.Add(this.SilindirYaricap_11);
            this.KureSilindirCarpisma.Controls.Add(this.SilindirBoy_11);
            this.KureSilindirCarpisma.Controls.Add(this.SilindirMekrezZ_11);
            this.KureSilindirCarpisma.Controls.Add(this.KureYaricap_11);
            this.KureSilindirCarpisma.Controls.Add(this.SilindirMekrezY_11);
            this.KureSilindirCarpisma.Controls.Add(this.KureMerkezZ_11);
            this.KureSilindirCarpisma.Controls.Add(this.SilindirMekrezX_11);
            this.KureSilindirCarpisma.Controls.Add(this.KureMerkezY_11);
            this.KureSilindirCarpisma.Controls.Add(this.KureMerkezX_11);
            this.KureSilindirCarpisma.Location = new System.Drawing.Point(4, 24);
            this.KureSilindirCarpisma.Name = "KureSilindirCarpisma";
            this.KureSilindirCarpisma.Size = new System.Drawing.Size(423, 542);
            this.KureSilindirCarpisma.TabIndex = 10;
            this.KureSilindirCarpisma.Text = "KureSilindirCarpisma";
            this.KureSilindirCarpisma.UseVisualStyleBackColor = true;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(3, 454);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(42, 15);
            this.label87.TabIndex = 4;
            this.label87.Text = "sonuc:";
            // 
            // textBoxSonuc_11
            // 
            this.textBoxSonuc_11.Location = new System.Drawing.Point(3, 472);
            this.textBoxSonuc_11.Name = "textBoxSonuc_11";
            this.textBoxSonuc_11.Size = new System.Drawing.Size(156, 23);
            this.textBoxSonuc_11.TabIndex = 3;
            // 
            // Hesapla_ve_Ciz_11
            // 
            this.Hesapla_ve_Ciz_11.Location = new System.Drawing.Point(231, 471);
            this.Hesapla_ve_Ciz_11.Name = "Hesapla_ve_Ciz_11";
            this.Hesapla_ve_Ciz_11.Size = new System.Drawing.Size(156, 23);
            this.Hesapla_ve_Ciz_11.TabIndex = 2;
            this.Hesapla_ve_Ciz_11.Text = "Hesapla_ve_Ciz_11";
            this.Hesapla_ve_Ciz_11.UseVisualStyleBackColor = true;
            this.Hesapla_ve_Ciz_11.Click += new System.EventHandler(this.Hesapla_ve_Ciz_11_Click);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(0, 406);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(193, 15);
            this.label86.TabIndex = 1;
            this.label86.Text = "lutfen silindirinizin yaricapini giriniz";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(3, 365);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(186, 15);
            this.label85.TabIndex = 1;
            this.label85.Text = "lütfen silinidirinizin boyunu giriniz";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(3, 320);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(279, 15);
            this.label84.TabIndex = 1;
            this.label84.Text = "lutfen silindirinizin Z eksenine gore merkezini giriniz";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(3, 166);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(181, 15);
            this.label81.TabIndex = 1;
            this.label81.Text = "Lutfen kurenizin yarıçapını giriniz";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(3, 264);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(279, 15);
            this.label83.TabIndex = 1;
            this.label83.Text = "lutfen silindirinizin Y eksenine gore merkezini giriniz";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(3, 121);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(295, 15);
            this.label80.TabIndex = 1;
            this.label80.Text = "Lutfen kürenizin merkezinin Z eksenine konumu giriniz";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(3, 210);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(279, 15);
            this.label82.TabIndex = 1;
            this.label82.Text = "lutfen silindirinizin X eksenine gore merkezini giriniz";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(3, 65);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(295, 15);
            this.label79.TabIndex = 1;
            this.label79.Text = "Lutfen kürenizin merkezinin Y eksenine konumu giriniz";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(3, 11);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(294, 15);
            this.label70.TabIndex = 1;
            this.label70.Text = "Lutfen kürenizin merkezinin x eksenine konumu giriniz";
            // 
            // SilindirYaricap_11
            // 
            this.SilindirYaricap_11.Location = new System.Drawing.Point(3, 422);
            this.SilindirYaricap_11.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.SilindirYaricap_11.Name = "SilindirYaricap_11";
            this.SilindirYaricap_11.Size = new System.Drawing.Size(120, 23);
            this.SilindirYaricap_11.TabIndex = 0;
            // 
            // SilindirBoy_11
            // 
            this.SilindirBoy_11.Location = new System.Drawing.Point(3, 380);
            this.SilindirBoy_11.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.SilindirBoy_11.Name = "SilindirBoy_11";
            this.SilindirBoy_11.Size = new System.Drawing.Size(120, 23);
            this.SilindirBoy_11.TabIndex = 0;
            // 
            // SilindirMekrezZ_11
            // 
            this.SilindirMekrezZ_11.Location = new System.Drawing.Point(3, 335);
            this.SilindirMekrezZ_11.Name = "SilindirMekrezZ_11";
            this.SilindirMekrezZ_11.Size = new System.Drawing.Size(120, 23);
            this.SilindirMekrezZ_11.TabIndex = 0;
            // 
            // KureYaricap_11
            // 
            this.KureYaricap_11.Location = new System.Drawing.Point(3, 184);
            this.KureYaricap_11.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.KureYaricap_11.Name = "KureYaricap_11";
            this.KureYaricap_11.Size = new System.Drawing.Size(120, 23);
            this.KureYaricap_11.TabIndex = 0;
            // 
            // SilindirMekrezY_11
            // 
            this.SilindirMekrezY_11.Location = new System.Drawing.Point(3, 285);
            this.SilindirMekrezY_11.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.SilindirMekrezY_11.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.SilindirMekrezY_11.Name = "SilindirMekrezY_11";
            this.SilindirMekrezY_11.Size = new System.Drawing.Size(120, 23);
            this.SilindirMekrezY_11.TabIndex = 0;
            // 
            // KureMerkezZ_11
            // 
            this.KureMerkezZ_11.Location = new System.Drawing.Point(3, 139);
            this.KureMerkezZ_11.Name = "KureMerkezZ_11";
            this.KureMerkezZ_11.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezZ_11.TabIndex = 0;
            // 
            // SilindirMekrezX_11
            // 
            this.SilindirMekrezX_11.Location = new System.Drawing.Point(3, 235);
            this.SilindirMekrezX_11.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.SilindirMekrezX_11.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.SilindirMekrezX_11.Name = "SilindirMekrezX_11";
            this.SilindirMekrezX_11.Size = new System.Drawing.Size(120, 23);
            this.SilindirMekrezX_11.TabIndex = 0;
            // 
            // KureMerkezY_11
            // 
            this.KureMerkezY_11.Location = new System.Drawing.Point(3, 89);
            this.KureMerkezY_11.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.KureMerkezY_11.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.KureMerkezY_11.Name = "KureMerkezY_11";
            this.KureMerkezY_11.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezY_11.TabIndex = 0;
            // 
            // KureMerkezX_11
            // 
            this.KureMerkezX_11.Location = new System.Drawing.Point(3, 39);
            this.KureMerkezX_11.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.KureMerkezX_11.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.KureMerkezX_11.Name = "KureMerkezX_11";
            this.KureMerkezX_11.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezX_11.TabIndex = 0;
            // 
            // YuzeyKureCarpisma
            // 
            this.YuzeyKureCarpisma.Controls.Add(this.Hesapla_ve_Ciz_button_12);
            this.YuzeyKureCarpisma.Controls.Add(this.textBoxSobuc_12);
            this.YuzeyKureCarpisma.Controls.Add(this.label98);
            this.YuzeyKureCarpisma.Controls.Add(this.label97);
            this.YuzeyKureCarpisma.Controls.Add(this.label91);
            this.YuzeyKureCarpisma.Controls.Add(this.label95);
            this.YuzeyKureCarpisma.Controls.Add(this.label90);
            this.YuzeyKureCarpisma.Controls.Add(this.label94);
            this.YuzeyKureCarpisma.Controls.Add(this.label93);
            this.YuzeyKureCarpisma.Controls.Add(this.label89);
            this.YuzeyKureCarpisma.Controls.Add(this.label88);
            this.YuzeyKureCarpisma.Controls.Add(this.YuzeyMerkezZ_12);
            this.YuzeyKureCarpisma.Controls.Add(this.KureYaricap_12);
            this.YuzeyKureCarpisma.Controls.Add(this.YuzeyYaricap_12);
            this.YuzeyKureCarpisma.Controls.Add(this.KureMerkezZ_12);
            this.YuzeyKureCarpisma.Controls.Add(this.KureMerkezX_12);
            this.YuzeyKureCarpisma.Controls.Add(this.KureMerkezY_12);
            this.YuzeyKureCarpisma.Controls.Add(this.YuzeyMerkezY_12);
            this.YuzeyKureCarpisma.Controls.Add(this.YuzeyMerkezX_12);
            this.YuzeyKureCarpisma.Location = new System.Drawing.Point(4, 24);
            this.YuzeyKureCarpisma.Name = "YuzeyKureCarpisma";
            this.YuzeyKureCarpisma.Size = new System.Drawing.Size(423, 542);
            this.YuzeyKureCarpisma.TabIndex = 11;
            this.YuzeyKureCarpisma.Text = "YuzeyKureCarpisma";
            this.YuzeyKureCarpisma.UseVisualStyleBackColor = true;
            // 
            // Hesapla_ve_Ciz_button_12
            // 
            this.Hesapla_ve_Ciz_button_12.Location = new System.Drawing.Point(129, 234);
            this.Hesapla_ve_Ciz_button_12.Name = "Hesapla_ve_Ciz_button_12";
            this.Hesapla_ve_Ciz_button_12.Size = new System.Drawing.Size(155, 23);
            this.Hesapla_ve_Ciz_button_12.TabIndex = 4;
            this.Hesapla_ve_Ciz_button_12.Text = "Hesapla_ve_Ciz_button_12";
            this.Hesapla_ve_Ciz_button_12.UseVisualStyleBackColor = true;
            this.Hesapla_ve_Ciz_button_12.Click += new System.EventHandler(this.Hesapla_ve_Ciz_button_12_Click);
            // 
            // textBoxSobuc_12
            // 
            this.textBoxSobuc_12.Location = new System.Drawing.Point(129, 278);
            this.textBoxSobuc_12.Name = "textBoxSobuc_12";
            this.textBoxSobuc_12.Size = new System.Drawing.Size(166, 23);
            this.textBoxSobuc_12.TabIndex = 3;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(184, 260);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(43, 15);
            this.label98.TabIndex = 2;
            this.label98.Text = "Sonuc:";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(240, 163);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(145, 15);
            this.label97.TabIndex = 1;
            this.label97.Text = "Kurenizin yaricapini giriniz";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(16, 163);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(192, 15);
            this.label91.TabIndex = 1;
            this.label91.Text = "Lutfen Yuzeyinizin yaricapini giriniz";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(203, 108);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(220, 15);
            this.label95.TabIndex = 1;
            this.label95.Text = "Kure icin merkez Nokta Z eksenini giriniz";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(16, 111);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(173, 15);
            this.label90.TabIndex = 1;
            this.label90.Text = "Lutfen Yuzeyin Zeksenini giriniz";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(196, 64);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(220, 15);
            this.label94.TabIndex = 1;
            this.label94.Text = "Kure icin merkez Nokta Y eksenini giriniz";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(196, 11);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(220, 15);
            this.label93.TabIndex = 1;
            this.label93.Text = "Kure icin merkez Nokta X eksenini giriniz";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(13, 64);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(176, 15);
            this.label89.TabIndex = 1;
            this.label89.Text = "Lutfen Yuzeyin Y eksenini giriniz";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(3, 11);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(176, 15);
            this.label88.TabIndex = 1;
            this.label88.Text = "Lutfen Yuzeyin X eksenini giriniz";
            // 
            // YuzeyMerkezZ_12
            // 
            this.YuzeyMerkezZ_12.Location = new System.Drawing.Point(16, 129);
            this.YuzeyMerkezZ_12.Name = "YuzeyMerkezZ_12";
            this.YuzeyMerkezZ_12.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezZ_12.TabIndex = 0;
            // 
            // KureYaricap_12
            // 
            this.KureYaricap_12.Location = new System.Drawing.Point(253, 181);
            this.KureYaricap_12.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.KureYaricap_12.Name = "KureYaricap_12";
            this.KureYaricap_12.Size = new System.Drawing.Size(120, 23);
            this.KureYaricap_12.TabIndex = 0;
            // 
            // YuzeyYaricap_12
            // 
            this.YuzeyYaricap_12.Location = new System.Drawing.Point(16, 181);
            this.YuzeyYaricap_12.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.YuzeyYaricap_12.Name = "YuzeyYaricap_12";
            this.YuzeyYaricap_12.Size = new System.Drawing.Size(120, 23);
            this.YuzeyYaricap_12.TabIndex = 0;
            // 
            // KureMerkezZ_12
            // 
            this.KureMerkezZ_12.Location = new System.Drawing.Point(253, 134);
            this.KureMerkezZ_12.Name = "KureMerkezZ_12";
            this.KureMerkezZ_12.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezZ_12.TabIndex = 0;
            // 
            // KureMerkezX_12
            // 
            this.KureMerkezX_12.Location = new System.Drawing.Point(253, 35);
            this.KureMerkezX_12.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.KureMerkezX_12.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.KureMerkezX_12.Name = "KureMerkezX_12";
            this.KureMerkezX_12.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezX_12.TabIndex = 0;
            // 
            // KureMerkezY_12
            // 
            this.KureMerkezY_12.Location = new System.Drawing.Point(253, 82);
            this.KureMerkezY_12.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.KureMerkezY_12.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.KureMerkezY_12.Name = "KureMerkezY_12";
            this.KureMerkezY_12.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezY_12.TabIndex = 0;
            // 
            // YuzeyMerkezY_12
            // 
            this.YuzeyMerkezY_12.Location = new System.Drawing.Point(16, 82);
            this.YuzeyMerkezY_12.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.YuzeyMerkezY_12.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.YuzeyMerkezY_12.Name = "YuzeyMerkezY_12";
            this.YuzeyMerkezY_12.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezY_12.TabIndex = 0;
            // 
            // YuzeyMerkezX_12
            // 
            this.YuzeyMerkezX_12.Location = new System.Drawing.Point(16, 35);
            this.YuzeyMerkezX_12.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.YuzeyMerkezX_12.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.YuzeyMerkezX_12.Name = "YuzeyMerkezX_12";
            this.YuzeyMerkezX_12.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezX_12.TabIndex = 0;
            // 
            // YuzeyDikdortgenCarpisma
            // 
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.textBoxSonuc_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.HesaplaVeCiz_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label106);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label101);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label105);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label100);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label104);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label99);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label103);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label96);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label102);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.label92);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaBoy_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.numericUpDown12);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaEn_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaDerinlik_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.numericUpDown11);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezZ_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.Yyaricap_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.numericUpDown9);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezY_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.YuzeyMerkezZ_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.numericUpDown8);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezX_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.YuzeyMerkezY_13);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.numericUpDown7);
            this.YuzeyDikdortgenCarpisma.Controls.Add(this.YuzeyMerkezX_13);
            this.YuzeyDikdortgenCarpisma.Location = new System.Drawing.Point(4, 24);
            this.YuzeyDikdortgenCarpisma.Name = "YuzeyDikdortgenCarpisma";
            this.YuzeyDikdortgenCarpisma.Size = new System.Drawing.Size(423, 542);
            this.YuzeyDikdortgenCarpisma.TabIndex = 12;
            this.YuzeyDikdortgenCarpisma.Text = "YuzeyDikdortgenPrizmaCarpisma";
            this.YuzeyDikdortgenCarpisma.UseVisualStyleBackColor = true;
            
            // 
            // textBoxSonuc_13
            // 
            this.textBoxSonuc_13.Location = new System.Drawing.Point(54, 287);
            this.textBoxSonuc_13.Name = "textBoxSonuc_13";
            this.textBoxSonuc_13.Size = new System.Drawing.Size(121, 23);
            this.textBoxSonuc_13.TabIndex = 3;
            // 
            // HesaplaVeCiz_13
            // 
            this.HesaplaVeCiz_13.Location = new System.Drawing.Point(54, 245);
            this.HesaplaVeCiz_13.Name = "HesaplaVeCiz_13";
            this.HesaplaVeCiz_13.Size = new System.Drawing.Size(121, 23);
            this.HesaplaVeCiz_13.TabIndex = 2;
            this.HesaplaVeCiz_13.Text = "HesaplaVeCiz_13";
            this.HesaplaVeCiz_13.UseVisualStyleBackColor = true;
            this.HesaplaVeCiz_13.Click += new System.EventHandler(this.HesaplaVeCiz_13_Click);
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(243, 183);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(177, 15);
            this.label106.TabIndex = 1;
            this.label106.Text = "Dikdortgen prizmanızın boyu (y)";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(222, 227);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(194, 15);
            this.label101.TabIndex = 1;
            this.label101.Text = "Dikdortgen prizmanızın derinliği (Z)";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(243, 136);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(166, 15);
            this.label105.TabIndex = 1;
            this.label105.Text = "Dikdortgen prizmanızın eni (x)";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(18, 136);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(157, 15);
            this.label100.TabIndex = 1;
            this.label100.Text = "yüzeyiniziin yarıçapını giriniz";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(245, 92);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(209, 15);
            this.label104.TabIndex = 1;
            this.label104.Text = "Dikdortgen prizmanın merkez Z ekseni";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(-3, 92);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(202, 15);
            this.label99.TabIndex = 1;
            this.label99.Text = "yuzey merkez nokta Z eksenini giriniz";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(245, 48);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(209, 15);
            this.label103.TabIndex = 1;
            this.label103.Text = "Dikdortgen prizmanın merkez Y ekseni";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(0, 48);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(205, 15);
            this.label96.TabIndex = 1;
            this.label96.Text = " yuzey merkez nokta Y eksenini giriniz";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(207, 9);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(209, 15);
            this.label102.TabIndex = 1;
            this.label102.Text = "Dikdortgen prizmanın merkez X ekseni";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(-4, 9);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(202, 15);
            this.label92.TabIndex = 1;
            this.label92.Text = "yuzey merkez nokta X eksenini giriniz";
            // 
            // DikdortgenPrizmaBoy_13
            // 
            this.DikdortgenPrizmaBoy_13.Location = new System.Drawing.Point(245, 201);
            this.DikdortgenPrizmaBoy_13.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgenPrizmaBoy_13.Name = "DikdortgenPrizmaBoy_13";
            this.DikdortgenPrizmaBoy_13.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaBoy_13.TabIndex = 0;
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.Location = new System.Drawing.Point(245, 201);
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown12.TabIndex = 0;
            // 
            // DikdortgenPrizmaEn_13
            // 
            this.DikdortgenPrizmaEn_13.Location = new System.Drawing.Point(245, 154);
            this.DikdortgenPrizmaEn_13.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgenPrizmaEn_13.Name = "DikdortgenPrizmaEn_13";
            this.DikdortgenPrizmaEn_13.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaEn_13.TabIndex = 0;
            // 
            // DikdortgenPrizmaDerinlik_13
            // 
            this.DikdortgenPrizmaDerinlik_13.Location = new System.Drawing.Point(243, 245);
            this.DikdortgenPrizmaDerinlik_13.Name = "DikdortgenPrizmaDerinlik_13";
            this.DikdortgenPrizmaDerinlik_13.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaDerinlik_13.TabIndex = 0;
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.Location = new System.Drawing.Point(245, 154);
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown11.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezZ_13
            // 
            this.DikdortgenPrizmaMerkezZ_13.Location = new System.Drawing.Point(245, 110);
            this.DikdortgenPrizmaMerkezZ_13.Name = "DikdortgenPrizmaMerkezZ_13";
            this.DikdortgenPrizmaMerkezZ_13.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezZ_13.TabIndex = 0;
            // 
            // Yyaricap_13
            // 
            this.Yyaricap_13.Location = new System.Drawing.Point(18, 154);
            this.Yyaricap_13.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.Yyaricap_13.Name = "Yyaricap_13";
            this.Yyaricap_13.Size = new System.Drawing.Size(120, 23);
            this.Yyaricap_13.TabIndex = 0;
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Location = new System.Drawing.Point(245, 110);
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown9.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezY_13
            // 
            this.DikdortgenPrizmaMerkezY_13.Location = new System.Drawing.Point(245, 66);
            this.DikdortgenPrizmaMerkezY_13.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.DikdortgenPrizmaMerkezY_13.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.DikdortgenPrizmaMerkezY_13.Name = "DikdortgenPrizmaMerkezY_13";
            this.DikdortgenPrizmaMerkezY_13.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezY_13.TabIndex = 0;
            // 
            // YuzeyMerkezZ_13
            // 
            this.YuzeyMerkezZ_13.Location = new System.Drawing.Point(18, 110);
            this.YuzeyMerkezZ_13.Name = "YuzeyMerkezZ_13";
            this.YuzeyMerkezZ_13.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezZ_13.TabIndex = 0;
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Location = new System.Drawing.Point(245, 66);
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown8.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezX_13
            // 
            this.DikdortgenPrizmaMerkezX_13.Location = new System.Drawing.Point(245, 27);
            this.DikdortgenPrizmaMerkezX_13.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.DikdortgenPrizmaMerkezX_13.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.DikdortgenPrizmaMerkezX_13.Name = "DikdortgenPrizmaMerkezX_13";
            this.DikdortgenPrizmaMerkezX_13.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezX_13.TabIndex = 0;
            // 
            // YuzeyMerkezY_13
            // 
            this.YuzeyMerkezY_13.Location = new System.Drawing.Point(18, 66);
            this.YuzeyMerkezY_13.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.YuzeyMerkezY_13.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.YuzeyMerkezY_13.Name = "YuzeyMerkezY_13";
            this.YuzeyMerkezY_13.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezY_13.TabIndex = 0;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(245, 27);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown7.TabIndex = 0;
            // 
            // YuzeyMerkezX_13
            // 
            this.YuzeyMerkezX_13.Location = new System.Drawing.Point(18, 27);
            this.YuzeyMerkezX_13.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.YuzeyMerkezX_13.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.YuzeyMerkezX_13.Name = "YuzeyMerkezX_13";
            this.YuzeyMerkezX_13.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezX_13.TabIndex = 0;
            // 
            // YuzeySilindirCarpisma
            // 
            this.YuzeySilindirCarpisma.Controls.Add(this.YuzeyYaricap_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.textBoxSonuc_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.Hesapla_VE_Ciz_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.label116);
            this.YuzeySilindirCarpisma.Controls.Add(this.label115);
            this.YuzeySilindirCarpisma.Controls.Add(this.label114);
            this.YuzeySilindirCarpisma.Controls.Add(this.label113);
            this.YuzeySilindirCarpisma.Controls.Add(this.label110);
            this.YuzeySilindirCarpisma.Controls.Add(this.label112);
            this.YuzeySilindirCarpisma.Controls.Add(this.label109);
            this.YuzeySilindirCarpisma.Controls.Add(this.label111);
            this.YuzeySilindirCarpisma.Controls.Add(this.label108);
            this.YuzeySilindirCarpisma.Controls.Add(this.label107);
            this.YuzeySilindirCarpisma.Controls.Add(this.SilindirYaricap_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.SilindirBoy_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.SilindirMerkezX_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.SilindirMerkezZ_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.YuzeyMerkezZ_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.SilindirMerkezY_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.YuzeyMerkezY_14);
            this.YuzeySilindirCarpisma.Controls.Add(this.YuzeyMerkezX_14);
            this.YuzeySilindirCarpisma.Location = new System.Drawing.Point(4, 24);
            this.YuzeySilindirCarpisma.Name = "YuzeySilindirCarpisma";
            this.YuzeySilindirCarpisma.Size = new System.Drawing.Size(423, 542);
            this.YuzeySilindirCarpisma.TabIndex = 13;
            this.YuzeySilindirCarpisma.Text = "YuzeySilindirCarpisma";
            this.YuzeySilindirCarpisma.UseVisualStyleBackColor = true;
            // 
            // YuzeyYaricap_14
            // 
            this.YuzeyYaricap_14.Location = new System.Drawing.Point(14, 187);
            this.YuzeyYaricap_14.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.YuzeyYaricap_14.Name = "YuzeyYaricap_14";
            this.YuzeyYaricap_14.Size = new System.Drawing.Size(120, 23);
            this.YuzeyYaricap_14.TabIndex = 5;
            // 
            // textBoxSonuc_14
            // 
            this.textBoxSonuc_14.Location = new System.Drawing.Point(224, 453);
            this.textBoxSonuc_14.Name = "textBoxSonuc_14";
            this.textBoxSonuc_14.Size = new System.Drawing.Size(120, 23);
            this.textBoxSonuc_14.TabIndex = 4;
            // 
            // Hesapla_VE_Ciz_14
            // 
            this.Hesapla_VE_Ciz_14.Location = new System.Drawing.Point(224, 374);
            this.Hesapla_VE_Ciz_14.Name = "Hesapla_VE_Ciz_14";
            this.Hesapla_VE_Ciz_14.Size = new System.Drawing.Size(120, 23);
            this.Hesapla_VE_Ciz_14.TabIndex = 3;
            this.Hesapla_VE_Ciz_14.Text = "Hesapla_VE_Ciz_14";
            this.Hesapla_VE_Ciz_14.UseVisualStyleBackColor = true;
            this.Hesapla_VE_Ciz_14.Click += new System.EventHandler(this.Hesapla_VE_Ciz_14_Click);
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(14, 166);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(191, 15);
            this.label116.TabIndex = 2;
            this.label116.Text = "Lutfen yuzeyinizin yarıcapini giriniz";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(254, 435);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(43, 15);
            this.label115.TabIndex = 2;
            this.label115.Text = "Sonuc:";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(3, 409);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(160, 15);
            this.label114.TabIndex = 1;
            this.label114.Text = "Silindirinizin yarıçapını giriniz";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(7, 365);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(156, 15);
            this.label113.TabIndex = 1;
            this.label113.Text = "Silinidirinizin boyunu giriniz ";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(14, 224);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(236, 15);
            this.label110.TabIndex = 1;
            this.label110.Text = "Silindirinizin merkez nokta X eksenini giriniz";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(7, 312);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(236, 15);
            this.label112.TabIndex = 1;
            this.label112.Text = "Silindirinizin merkez nokta Z eksenini giriniz";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(14, 116);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(279, 15);
            this.label109.TabIndex = 1;
            this.label109.Text = "Lutfen yüzeyiniz için merkez nokta Z eksenini giriniz";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(7, 268);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(236, 15);
            this.label111.TabIndex = 1;
            this.label111.Text = "Silindirinizin merkez nokta Y eksenini giriniz";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(14, 70);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(279, 15);
            this.label108.TabIndex = 1;
            this.label108.Text = "Lutfen yüzeyiniz için merkez nokta Y eksenini giriniz";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(14, 26);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(278, 15);
            this.label107.TabIndex = 1;
            this.label107.Text = "Lutfen yüzeyiniz için merkez nokta x eksenini giriniz";
            // 
            // SilindirYaricap_14
            // 
            this.SilindirYaricap_14.Location = new System.Drawing.Point(14, 427);
            this.SilindirYaricap_14.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.SilindirYaricap_14.Name = "SilindirYaricap_14";
            this.SilindirYaricap_14.Size = new System.Drawing.Size(120, 23);
            this.SilindirYaricap_14.TabIndex = 0;
            // 
            // SilindirBoy_14
            // 
            this.SilindirBoy_14.Location = new System.Drawing.Point(14, 383);
            this.SilindirBoy_14.Name = "SilindirBoy_14";
            this.SilindirBoy_14.Size = new System.Drawing.Size(120, 23);
            this.SilindirBoy_14.TabIndex = 0;
            // 
            // SilindirMerkezX_14
            // 
            this.SilindirMerkezX_14.Location = new System.Drawing.Point(14, 242);
            this.SilindirMerkezX_14.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.SilindirMerkezX_14.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.SilindirMerkezX_14.Name = "SilindirMerkezX_14";
            this.SilindirMerkezX_14.Size = new System.Drawing.Size(120, 23);
            this.SilindirMerkezX_14.TabIndex = 0;
            // 
            // SilindirMerkezZ_14
            // 
            this.SilindirMerkezZ_14.Location = new System.Drawing.Point(14, 330);
            this.SilindirMerkezZ_14.Name = "SilindirMerkezZ_14";
            this.SilindirMerkezZ_14.Size = new System.Drawing.Size(120, 23);
            this.SilindirMerkezZ_14.TabIndex = 0;
            // 
            // YuzeyMerkezZ_14
            // 
            this.YuzeyMerkezZ_14.Location = new System.Drawing.Point(14, 140);
            this.YuzeyMerkezZ_14.Name = "YuzeyMerkezZ_14";
            this.YuzeyMerkezZ_14.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezZ_14.TabIndex = 0;
            // 
            // SilindirMerkezY_14
            // 
            this.SilindirMerkezY_14.Location = new System.Drawing.Point(14, 286);
            this.SilindirMerkezY_14.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.SilindirMerkezY_14.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.SilindirMerkezY_14.Name = "SilindirMerkezY_14";
            this.SilindirMerkezY_14.Size = new System.Drawing.Size(120, 23);
            this.SilindirMerkezY_14.TabIndex = 0;
            // 
            // YuzeyMerkezY_14
            // 
            this.YuzeyMerkezY_14.Location = new System.Drawing.Point(14, 90);
            this.YuzeyMerkezY_14.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.YuzeyMerkezY_14.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.YuzeyMerkezY_14.Name = "YuzeyMerkezY_14";
            this.YuzeyMerkezY_14.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezY_14.TabIndex = 0;
            // 
            // YuzeyMerkezX_14
            // 
            this.YuzeyMerkezX_14.Location = new System.Drawing.Point(14, 44);
            this.YuzeyMerkezX_14.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.YuzeyMerkezX_14.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.YuzeyMerkezX_14.Name = "YuzeyMerkezX_14";
            this.YuzeyMerkezX_14.Size = new System.Drawing.Size(120, 23);
            this.YuzeyMerkezX_14.TabIndex = 0;
            // 
            // KureDikdortgenCarpisma
            // 
            this.KureDikdortgenCarpisma.Controls.Add(this.label127);
            this.KureDikdortgenCarpisma.Controls.Add(this.textBoxSonuc_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.Hesapla_ve_ciz_15_button);
            this.KureDikdortgenCarpisma.Controls.Add(this.label126);
            this.KureDikdortgenCarpisma.Controls.Add(this.label121);
            this.KureDikdortgenCarpisma.Controls.Add(this.label125);
            this.KureDikdortgenCarpisma.Controls.Add(this.label120);
            this.KureDikdortgenCarpisma.Controls.Add(this.label124);
            this.KureDikdortgenCarpisma.Controls.Add(this.label119);
            this.KureDikdortgenCarpisma.Controls.Add(this.label123);
            this.KureDikdortgenCarpisma.Controls.Add(this.label118);
            this.KureDikdortgenCarpisma.Controls.Add(this.label122);
            this.KureDikdortgenCarpisma.Controls.Add(this.label117);
            this.KureDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezX_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaDERİNLİK_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.KureYaricap_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaBOY_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.KureMerkezNoktaZ_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaEn_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.KureMerkezNoktaY_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezZ_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.KureMerkezNoktaX_15);
            this.KureDikdortgenCarpisma.Controls.Add(this.DikdortgenPrizmaMerkezY_15);
            this.KureDikdortgenCarpisma.Location = new System.Drawing.Point(4, 24);
            this.KureDikdortgenCarpisma.Name = "KureDikdortgenCarpisma";
            this.KureDikdortgenCarpisma.Size = new System.Drawing.Size(423, 542);
            this.KureDikdortgenCarpisma.TabIndex = 14;
            this.KureDikdortgenCarpisma.Text = "KureDikdortgenPrizmaCarpisma";
            this.KureDikdortgenCarpisma.UseVisualStyleBackColor = true;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(48, 430);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(40, 15);
            this.label127.TabIndex = 4;
            this.label127.Text = "Sonuc";
            // 
            // textBoxSonuc_15
            // 
            this.textBoxSonuc_15.Location = new System.Drawing.Point(40, 448);
            this.textBoxSonuc_15.Name = "textBoxSonuc_15";
            this.textBoxSonuc_15.Size = new System.Drawing.Size(100, 23);
            this.textBoxSonuc_15.TabIndex = 3;
            // 
            // Hesapla_ve_ciz_15_button
            // 
            this.Hesapla_ve_ciz_15_button.Location = new System.Drawing.Point(28, 361);
            this.Hesapla_ve_ciz_15_button.Name = "Hesapla_ve_ciz_15_button";
            this.Hesapla_ve_ciz_15_button.Size = new System.Drawing.Size(132, 23);
            this.Hesapla_ve_ciz_15_button.TabIndex = 2;
            this.Hesapla_ve_ciz_15_button.Text = "Hesapla_ve_ciz_15";
            this.Hesapla_ve_ciz_15_button.UseVisualStyleBackColor = true;
            this.Hesapla_ve_ciz_15_button.Click += new System.EventHandler(this.Hesapla_ve_ciz_15_button_Click);
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(257, 470);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(151, 15);
            this.label126.TabIndex = 1;
            this.label126.Text = "prizmanın derinliğini giriniz";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(65, 220);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(351, 15);
            this.label121.TabIndex = 1;
            this.label121.Text = "Dikdörtgen prizmanzın X eksenine göre merkez konumunu giriniz";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(257, 413);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(139, 15);
            this.label125.TabIndex = 1;
            this.label125.Text = "prizmanın boyunu giriniz";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(40, 164);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(139, 15);
            this.label120.TabIndex = 1;
            this.label120.Text = "Kurnizin yarıçapını giriniz";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(259, 365);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(124, 15);
            this.label124.TabIndex = 1;
            this.label124.Text = "Prizmanın enini giriniz";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(40, 111);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(218, 15);
            this.label119.TabIndex = 1;
            this.label119.Text = "Kure için merkez nokta Z eksenini giriniz";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(57, 317);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(351, 15);
            this.label123.TabIndex = 1;
            this.label123.Text = "Dikdörtgen prizmanzın Z eksenine göre merkez konumunu giriniz";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(40, 67);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(218, 15);
            this.label118.TabIndex = 1;
            this.label118.Text = "Kure için merkez nokta Y eksenini giriniz";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(65, 273);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(351, 15);
            this.label122.TabIndex = 1;
            this.label122.Text = "Dikdörtgen prizmanzın Y eksenine göre merkez konumunu giriniz";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(40, 19);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(218, 15);
            this.label117.TabIndex = 1;
            this.label117.Text = "Kure için merkez nokta X eksenini giriniz";
            // 
            // DikdortgenPrizmaMerkezX_15
            // 
            this.DikdortgenPrizmaMerkezX_15.Location = new System.Drawing.Point(257, 238);
            this.DikdortgenPrizmaMerkezX_15.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.DikdortgenPrizmaMerkezX_15.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.DikdortgenPrizmaMerkezX_15.Name = "DikdortgenPrizmaMerkezX_15";
            this.DikdortgenPrizmaMerkezX_15.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezX_15.TabIndex = 0;
            // 
            // DikdortgenPrizmaDERİNLİK_15
            // 
            this.DikdortgenPrizmaDERİNLİK_15.Location = new System.Drawing.Point(259, 488);
            this.DikdortgenPrizmaDERİNLİK_15.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgenPrizmaDERİNLİK_15.Name = "DikdortgenPrizmaDERİNLİK_15";
            this.DikdortgenPrizmaDERİNLİK_15.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaDERİNLİK_15.TabIndex = 0;
            // 
            // KureYaricap_15
            // 
            this.KureYaricap_15.Location = new System.Drawing.Point(40, 182);
            this.KureYaricap_15.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.KureYaricap_15.Name = "KureYaricap_15";
            this.KureYaricap_15.Size = new System.Drawing.Size(120, 23);
            this.KureYaricap_15.TabIndex = 0;
            // 
            // DikdortgenPrizmaBOY_15
            // 
            this.DikdortgenPrizmaBOY_15.Location = new System.Drawing.Point(259, 436);
            this.DikdortgenPrizmaBOY_15.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgenPrizmaBOY_15.Name = "DikdortgenPrizmaBOY_15";
            this.DikdortgenPrizmaBOY_15.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaBOY_15.TabIndex = 0;
            // 
            // KureMerkezNoktaZ_15
            // 
            this.KureMerkezNoktaZ_15.Location = new System.Drawing.Point(40, 133);
            this.KureMerkezNoktaZ_15.Name = "KureMerkezNoktaZ_15";
            this.KureMerkezNoktaZ_15.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezNoktaZ_15.TabIndex = 0;
            // 
            // DikdortgenPrizmaEn_15
            // 
            this.DikdortgenPrizmaEn_15.Location = new System.Drawing.Point(259, 387);
            this.DikdortgenPrizmaEn_15.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgenPrizmaEn_15.Name = "DikdortgenPrizmaEn_15";
            this.DikdortgenPrizmaEn_15.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaEn_15.TabIndex = 0;
            // 
            // KureMerkezNoktaY_15
            // 
            this.KureMerkezNoktaY_15.Location = new System.Drawing.Point(40, 85);
            this.KureMerkezNoktaY_15.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.KureMerkezNoktaY_15.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.KureMerkezNoktaY_15.Name = "KureMerkezNoktaY_15";
            this.KureMerkezNoktaY_15.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezNoktaY_15.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezZ_15
            // 
            this.DikdortgenPrizmaMerkezZ_15.Location = new System.Drawing.Point(259, 339);
            this.DikdortgenPrizmaMerkezZ_15.Name = "DikdortgenPrizmaMerkezZ_15";
            this.DikdortgenPrizmaMerkezZ_15.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezZ_15.TabIndex = 0;
            // 
            // KureMerkezNoktaX_15
            // 
            this.KureMerkezNoktaX_15.Location = new System.Drawing.Point(40, 37);
            this.KureMerkezNoktaX_15.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.KureMerkezNoktaX_15.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.KureMerkezNoktaX_15.Name = "KureMerkezNoktaX_15";
            this.KureMerkezNoktaX_15.Size = new System.Drawing.Size(120, 23);
            this.KureMerkezNoktaX_15.TabIndex = 0;
            // 
            // DikdortgenPrizmaMerkezY_15
            // 
            this.DikdortgenPrizmaMerkezY_15.Location = new System.Drawing.Point(259, 291);
            this.DikdortgenPrizmaMerkezY_15.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.DikdortgenPrizmaMerkezY_15.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.DikdortgenPrizmaMerkezY_15.Name = "DikdortgenPrizmaMerkezY_15";
            this.DikdortgenPrizmaMerkezY_15.Size = new System.Drawing.Size(120, 23);
            this.DikdortgenPrizmaMerkezY_15.TabIndex = 0;
            // 
            // DikdortgenPrizmaDikdortgenPrizmaCarpisma
            // 
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.Sonuc);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label139);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label138);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label136);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label135);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label133);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label137);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label132);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label134);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label130);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.D11);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label129);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.label128);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DikdortgrnPrizma2DERİNLİK_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DikdortgrnPrizma1DERİNLİK_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DikdortgrnPrizma2BOY_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DikdortgrnPrizma1BOY_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DidkortgenPrizma2Z_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DidkortgenPrizma1Z_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DikdortgrnPrizma2EN_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DikdortgrnPrizma1EN_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DidkortgenPrizma2Y_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DidkortgenPrizma1Y_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DidkortgenPrizma2X_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.DidkortgenPrizma1X_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.textBoxSonuc_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Controls.Add(this.HesaplaVeCizdir_16);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Location = new System.Drawing.Point(4, 24);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Name = "DikdortgenPrizmaDikdortgenPrizmaCarpisma";
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Size = new System.Drawing.Size(423, 542);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.TabIndex = 15;
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.Text = "DikdortgenPrizmaDikdortgenPrizmaCarpisma";
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.UseVisualStyleBackColor = true;
            // 
            // Sonuc
            // 
            this.Sonuc.AutoSize = true;
            this.Sonuc.Location = new System.Drawing.Point(177, 467);
            this.Sonuc.Name = "Sonuc";
            this.Sonuc.Size = new System.Drawing.Size(43, 15);
            this.Sonuc.TabIndex = 4;
            this.Sonuc.Text = "Sonuc:";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(248, 131);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(165, 15);
            this.label139.TabIndex = 3;
            this.label139.Text = "Dikdortgen prizma 2 merkez Z";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(248, 75);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(165, 15);
            this.label138.TabIndex = 3;
            this.label138.Text = "Dikdortgen prizma 2 merkez Y";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(248, 310);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(157, 15);
            this.label136.TabIndex = 3;
            this.label136.Text = "Dikdortgen prizma 2 Derinlik";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(283, 254);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(98, 15);
            this.label135.TabIndex = 3;
            this.label135.Text = "Dikdortgen 2 Boy";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(26, 310);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(156, 15);
            this.label133.TabIndex = 3;
            this.label133.Text = "Dikdortgen prizma 1 derinlik";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(248, 9);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(165, 15);
            this.label137.TabIndex = 3;
            this.label137.Text = "Dikdortgen prizma 2 merkez X";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(65, 254);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(137, 15);
            this.label132.TabIndex = 3;
            this.label132.Text = "Dikdortgen prizma 1 boy";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(283, 187);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(130, 15);
            this.label134.TabIndex = 3;
            this.label134.Text = "Dikdortgen prizma 2 en";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(23, 131);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(165, 15);
            this.label130.TabIndex = 3;
            this.label130.Text = "Dikdortgen prizma 1 merkez Z";
            // 
            // D11
            // 
            this.D11.AutoSize = true;
            this.D11.Location = new System.Drawing.Point(26, 187);
            this.D11.Name = "D11";
            this.D11.Size = new System.Drawing.Size(130, 15);
            this.D11.TabIndex = 3;
            this.D11.Text = "Dikdortgen prizma 1 en";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(23, 75);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(165, 15);
            this.label129.TabIndex = 3;
            this.label129.Text = "Dikdortgen prizma 1 merkez Y";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(23, 18);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(165, 15);
            this.label128.TabIndex = 3;
            this.label128.Text = "Dikdortgen prizma 1 merkez X";
            // 
            // DikdortgrnPrizma2DERİNLİK_16
            // 
            this.DikdortgrnPrizma2DERİNLİK_16.Location = new System.Drawing.Point(268, 328);
            this.DikdortgrnPrizma2DERİNLİK_16.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgrnPrizma2DERİNLİK_16.Name = "DikdortgrnPrizma2DERİNLİK_16";
            this.DikdortgrnPrizma2DERİNLİK_16.Size = new System.Drawing.Size(120, 23);
            this.DikdortgrnPrizma2DERİNLİK_16.TabIndex = 2;
            // 
            // DikdortgrnPrizma1DERİNLİK_16
            // 
            this.DikdortgrnPrizma1DERİNLİK_16.Location = new System.Drawing.Point(23, 328);
            this.DikdortgrnPrizma1DERİNLİK_16.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgrnPrizma1DERİNLİK_16.Name = "DikdortgrnPrizma1DERİNLİK_16";
            this.DikdortgrnPrizma1DERİNLİK_16.Size = new System.Drawing.Size(120, 23);
            this.DikdortgrnPrizma1DERİNLİK_16.TabIndex = 2;
            // 
            // DikdortgrnPrizma2BOY_16
            // 
            this.DikdortgrnPrizma2BOY_16.Location = new System.Drawing.Point(268, 272);
            this.DikdortgrnPrizma2BOY_16.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgrnPrizma2BOY_16.Name = "DikdortgrnPrizma2BOY_16";
            this.DikdortgrnPrizma2BOY_16.Size = new System.Drawing.Size(120, 23);
            this.DikdortgrnPrizma2BOY_16.TabIndex = 2;
            // 
            // DikdortgrnPrizma1BOY_16
            // 
            this.DikdortgrnPrizma1BOY_16.Location = new System.Drawing.Point(23, 272);
            this.DikdortgrnPrizma1BOY_16.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgrnPrizma1BOY_16.Name = "DikdortgrnPrizma1BOY_16";
            this.DikdortgrnPrizma1BOY_16.Size = new System.Drawing.Size(120, 23);
            this.DikdortgrnPrizma1BOY_16.TabIndex = 2;
            // 
            // DidkortgenPrizma2Z_16
            // 
            this.DidkortgenPrizma2Z_16.Location = new System.Drawing.Point(268, 149);
            this.DidkortgenPrizma2Z_16.Name = "DidkortgenPrizma2Z_16";
            this.DidkortgenPrizma2Z_16.Size = new System.Drawing.Size(120, 23);
            this.DidkortgenPrizma2Z_16.TabIndex = 2;
            // 
            // DidkortgenPrizma1Z_16
            // 
            this.DidkortgenPrizma1Z_16.Location = new System.Drawing.Point(23, 149);
            this.DidkortgenPrizma1Z_16.Name = "DidkortgenPrizma1Z_16";
            this.DidkortgenPrizma1Z_16.Size = new System.Drawing.Size(120, 23);
            this.DidkortgenPrizma1Z_16.TabIndex = 2;
            // 
            // DikdortgrnPrizma2EN_16
            // 
            this.DikdortgrnPrizma2EN_16.Location = new System.Drawing.Point(268, 215);
            this.DikdortgrnPrizma2EN_16.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgrnPrizma2EN_16.Name = "DikdortgrnPrizma2EN_16";
            this.DikdortgrnPrizma2EN_16.Size = new System.Drawing.Size(120, 23);
            this.DikdortgrnPrizma2EN_16.TabIndex = 2;
            // 
            // DikdortgrnPrizma1EN_16
            // 
            this.DikdortgrnPrizma1EN_16.Location = new System.Drawing.Point(23, 215);
            this.DikdortgrnPrizma1EN_16.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.DikdortgrnPrizma1EN_16.Name = "DikdortgrnPrizma1EN_16";
            this.DikdortgrnPrizma1EN_16.Size = new System.Drawing.Size(120, 23);
            this.DikdortgrnPrizma1EN_16.TabIndex = 2;
            // 
            // DidkortgenPrizma2Y_16
            // 
            this.DidkortgenPrizma2Y_16.Location = new System.Drawing.Point(268, 93);
            this.DidkortgenPrizma2Y_16.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.DidkortgenPrizma2Y_16.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.DidkortgenPrizma2Y_16.Name = "DidkortgenPrizma2Y_16";
            this.DidkortgenPrizma2Y_16.Size = new System.Drawing.Size(120, 23);
            this.DidkortgenPrizma2Y_16.TabIndex = 2;
            // 
            // DidkortgenPrizma1Y_16
            // 
            this.DidkortgenPrizma1Y_16.Location = new System.Drawing.Point(23, 93);
            this.DidkortgenPrizma1Y_16.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.DidkortgenPrizma1Y_16.Minimum = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            this.DidkortgenPrizma1Y_16.Name = "DidkortgenPrizma1Y_16";
            this.DidkortgenPrizma1Y_16.Size = new System.Drawing.Size(120, 23);
            this.DidkortgenPrizma1Y_16.TabIndex = 2;
            // 
            // DidkortgenPrizma2X_16
            // 
            this.DidkortgenPrizma2X_16.Location = new System.Drawing.Point(268, 36);
            this.DidkortgenPrizma2X_16.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.DidkortgenPrizma2X_16.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.DidkortgenPrizma2X_16.Name = "DidkortgenPrizma2X_16";
            this.DidkortgenPrizma2X_16.Size = new System.Drawing.Size(120, 23);
            this.DidkortgenPrizma2X_16.TabIndex = 2;
            // 
            // DidkortgenPrizma1X_16
            // 
            this.DidkortgenPrizma1X_16.Location = new System.Drawing.Point(23, 36);
            this.DidkortgenPrizma1X_16.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.DidkortgenPrizma1X_16.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            -2147483648});
            this.DidkortgenPrizma1X_16.Name = "DidkortgenPrizma1X_16";
            this.DidkortgenPrizma1X_16.Size = new System.Drawing.Size(120, 23);
            this.DidkortgenPrizma1X_16.TabIndex = 2;
            // 
            // textBoxSonuc_16
            // 
            this.textBoxSonuc_16.Location = new System.Drawing.Point(132, 485);
            this.textBoxSonuc_16.Name = "textBoxSonuc_16";
            this.textBoxSonuc_16.Size = new System.Drawing.Size(142, 23);
            this.textBoxSonuc_16.TabIndex = 1;
            // 
            // HesaplaVeCizdir_16
            // 
            this.HesaplaVeCizdir_16.Location = new System.Drawing.Point(132, 399);
            this.HesaplaVeCizdir_16.Name = "HesaplaVeCizdir_16";
            this.HesaplaVeCizdir_16.Size = new System.Drawing.Size(142, 23);
            this.HesaplaVeCizdir_16.TabIndex = 0;
            this.HesaplaVeCizdir_16.Text = "HesaplaVeCizdir_16";
            this.HesaplaVeCizdir_16.UseVisualStyleBackColor = true;
            this.HesaplaVeCizdir_16.Click += new System.EventHandler(this.HesaplaVeCizdir_16_Click);
            // 
            // ListCizdir
            // 
            this.ListCizdir.Controls.Add(this.label6);
            this.ListCizdir.Controls.Add(this.Cizdir_list);
            this.ListCizdir.Location = new System.Drawing.Point(4, 24);
            this.ListCizdir.Name = "ListCizdir";
            this.ListCizdir.Size = new System.Drawing.Size(423, 542);
            this.ListCizdir.TabIndex = 16;
            this.ListCizdir.Text = "ListCizdir";
            this.ListCizdir.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(108, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(180, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "List özeliği ile tüm cisimleri çizdir";
            // 
            // Cizdir_list
            // 
            this.Cizdir_list.Location = new System.Drawing.Point(158, 133);
            this.Cizdir_list.Name = "Cizdir_list";
            this.Cizdir_list.Size = new System.Drawing.Size(93, 23);
            this.Cizdir_list.TabIndex = 0;
            this.Cizdir_list.Text = "Cizdir_list";
            this.Cizdir_list.UseVisualStyleBackColor = true;
            this.Cizdir_list.Click += new System.EventHandler(this.Cizdir_list_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1429, 571);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.NoktaDortgenCarpisma.ResumeLayout(false);
            this.NoktaDortgenCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınMerkezNoktaX_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukMerkezNoktaX_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukEGIM_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta2X_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta1X_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta2Y_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nokta1Y_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınEn_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukEN_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınBoy_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukBOY_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KareIcınMerkezNoktaY_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YamukMerkezNoktaY_1)).EndInit();
            this.NoktaCemberCarpısma.ResumeLayout(false);
            this.NoktaCemberCarpısma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CemberYaricap_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberMerkezYEkseni_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberMerkezXEkseni_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaYekseni_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaXekseni_2)).EndInit();
            this.DikdortgenDikdortgenCarpisma.ResumeLayout(false);
            this.DikdortgenDikdortgenCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Genislik_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Uzunluk_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Yekseni_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen2Xekseni_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Uzunluk_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Genislik_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Yekseni_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dikdortgen1Xekseni_3)).EndInit();
            this.DikdortgenCemberCarpisma.ResumeLayout(false);
            this.DikdortgenCemberCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CemberinizinYaricapi_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberinizinMerkeziYekseni_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CemberinizinMerkeziXekseni_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgeninBoyu_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgeninEni_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenIcınMerkezNoktaY_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dikdortgenIcınMerkezNoktaX_4)).EndInit();
            this.CemberCemberCarpisma.ResumeLayout(false);
            this.CemberCemberCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cember2MerkezXekseni_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember2YARICAP_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember2MerkezYekseni_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember1YARICAP_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember1MerkezYekseni_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cember1MerkezXekseni_5)).EndInit();
            this.NoktaKureCarpisma.ResumeLayout(false);
            this.NoktaKureCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezZEkseni_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezYEkseni_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezXEkseni_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaZekseni_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaYekseni_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaXekseni_6)).EndInit();
            this.NoktaDikdortgenCarpisma.ResumeLayout(false);
            this.NoktaDikdortgenCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DidortgenPrizmaEn_x_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezX_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaX_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidortgenPrizmaDerinlik_Z_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidortgenPrizmaBoy_Y_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezZ_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezY_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaZ_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaY_7)).EndInit();
            this.NoktaSilindirCarpisma.ResumeLayout(false);
            this.NoktaSilindirCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirBoy_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYariCap_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirZEkseni_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYEkseni_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirXEkseni_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaZEkseni_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaYEkseni_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoktaXEkseni_8)).EndInit();
            this.SilindirSilindirCarpisma.ResumeLayout(false);
            this.SilindirSilindirCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2Yaricap_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2Boy_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2ZMerkez_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2YMerkez_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir2XMerkez_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1Yaricap_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1Boy_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1ZMerkez_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1YMerkez_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silindir1XMerkez_9)).EndInit();
            this.KureKureCarpisma.ResumeLayout(false);
            this.KureKureCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Yaricap_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Zekseni_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Yekseni_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure2Xekseni_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure1Yaricap_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kureniz1Zekseni_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure1Yekseni_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kure1Xekseni_10)).EndInit();
            this.KureSilindirCarpisma.ResumeLayout(false);
            this.KureSilindirCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYaricap_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirBoy_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMekrezZ_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMekrezY_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezZ_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMekrezX_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezY_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezX_11)).EndInit();
            this.YuzeyKureCarpisma.ResumeLayout(false);
            this.YuzeyKureCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezZ_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyYaricap_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezZ_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezX_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezY_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezY_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezX_12)).EndInit();
            this.YuzeyDikdortgenCarpisma.ResumeLayout(false);
            this.YuzeyDikdortgenCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaBoy_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaEn_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaDerinlik_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezZ_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yyaricap_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezY_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezZ_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezX_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezY_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezX_13)).EndInit();
            this.YuzeySilindirCarpisma.ResumeLayout(false);
            this.YuzeySilindirCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyYaricap_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirYaricap_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirBoy_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMerkezX_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMerkezZ_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezZ_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SilindirMerkezY_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezY_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YuzeyMerkezX_14)).EndInit();
            this.KureDikdortgenCarpisma.ResumeLayout(false);
            this.KureDikdortgenCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezX_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaDERİNLİK_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureYaricap_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaBOY_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezNoktaZ_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaEn_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezNoktaY_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezZ_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KureMerkezNoktaX_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgenPrizmaMerkezY_15)).EndInit();
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.ResumeLayout(false);
            this.DikdortgenPrizmaDikdortgenPrizmaCarpisma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma2DERİNLİK_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma1DERİNLİK_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma2BOY_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma1BOY_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma2Z_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma1Z_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma2EN_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DikdortgrnPrizma1EN_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma2Y_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma1Y_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma2X_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DidkortgenPrizma1X_16)).EndInit();
            this.ListCizdir.ResumeLayout(false);
            this.ListCizdir.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl1;
        private TabPage NoktaDortgenCarpisma;
        private TabPage NoktaCemberCarpısma;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TabPage DikdortgenDikdortgenCarpisma;
        private TabPage DikdortgenCemberCarpisma;
        private TabPage CemberCemberCarpisma;
        private TabPage NoktaKureCarpisma;
        private TabPage NoktaDikdortgenCarpisma;
        private TabPage NoktaSilindirCarpisma;
        private TabPage SilindirSilindirCarpisma;
        private TabPage KureKureCarpisma;
        private TabPage KureSilindirCarpisma;
        private TabPage YuzeyKureCarpisma;
        private TabPage YuzeyDikdortgenCarpisma;
        private TabPage YuzeySilindirCarpisma;
        private TabPage KureDikdortgenCarpisma;
        private TabPage DikdortgenPrizmaDikdortgenPrizmaCarpisma;
        private NumericUpDown CemberYaricap_2;
        private NumericUpDown CemberMerkezYEkseni_2;
        private NumericUpDown CemberMerkezXEkseni_2;
        private NumericUpDown NoktaYekseni_2;
        private NumericUpDown NoktaXekseni_2;
        private Label label5;
        private Button HesaplaVeÇiz_2;
        private TextBox SonucTextBox_2;
        private Label SonucLabel_2;
        private Button Hesapla_Ve_CİZ_3_Button;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label15;
        private Label label8;
        private NumericUpDown Dikdortgen2Genislik_3;
        private NumericUpDown Dikdortgen2Uzunluk_3;
        private NumericUpDown Dikdortgen2Yekseni_3;
        private NumericUpDown Dikdortgen2Xekseni_3;
        private NumericUpDown Dikdortgen1Uzunluk_3;
        private NumericUpDown Dikdortgen1Genislik_3;
        private NumericUpDown Dikdortgen1Yekseni_3;
        private NumericUpDown Dikdortgen1Xekseni_3;
        private TextBox SonucTextBox_3;
        private Label SonucLabel_3;
        private TextBox SonucTextBox_4;
        private Label label22;
        private Label label20;
        private Label label18;
        private Label label21;
        private Label label19;
        private Label label17;
        private Label label16;
        private Label label7;
        private NumericUpDown CemberinizinYaricapi_4;
        private NumericUpDown CemberinizinMerkeziYekseni_4;
        private NumericUpDown CemberinizinMerkeziXekseni_4;
        private NumericUpDown DikdortgeninBoyu_4;
        private NumericUpDown DikdortgeninEni_4;
        private NumericUpDown DikdortgenIcınMerkezNoktaY_4;
        private NumericUpDown dikdortgenIcınMerkezNoktaX_4;
        private Button Hesapla_Ve_Ciz_4;
        private NumericUpDown Cember2MerkezYekseni_5;
        private NumericUpDown Cember1MerkezYekseni_5;
        private NumericUpDown Cember1MerkezXekseni_5;
        private Button Hesapla_Ve_Cizdir_5;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private TextBox TextBoxSonuc_5;
        private NumericUpDown Cember2MerkezXekseni_5;
        private NumericUpDown Cember2YARICAP_5;
        private NumericUpDown Cember1YARICAP_5;
        private Label label35;
        private Label label34;
        private Label label33;
        private Label label32;
        private Label label31;
        private Label label30;
        private NumericUpDown KureMerkezXEkseni_6;
        private NumericUpDown NoktaZekseni_6;
        private NumericUpDown NoktaYekseni_6;
        private NumericUpDown NoktaXekseni_6;
        private Label label37;
        private Label label36;
        private Button HesaplaVeCiz_6;
        private TextBox TextBoxSonuc_6;
        private NumericUpDown KureYaricap_6;
        private NumericUpDown KureMerkezZEkseni_6;
        private NumericUpDown KureMerkezYEkseni_6;
        private Label label40;
        private Label label39;
        private Label label38;
        private NumericUpDown DidortgenPrizmaEn_x_7;
        private NumericUpDown DikdortgenPrizmaMerkezX_7;
        private NumericUpDown NoktaX_7;
        private NumericUpDown DidortgenPrizmaDerinlik_Z_7;
        private NumericUpDown DidortgenPrizmaBoy_Y_7;
        private NumericUpDown DikdortgenPrizmaMerkezZ_7;
        private NumericUpDown DikdortgenPrizmaMerkezY_7;
        private NumericUpDown NoktaZ_7;
        private NumericUpDown NoktaY_7;
        private TextBox textBoxSonuc_7;
        private Button HesaplaVeÇizButton_7;
        private Label label47;
        private Label label46;
        private Label label45;
        private Label label43;
        private Label label42;
        private Label label44;
        private Label label41;
        private TextBox TextBoxSonuc_8;
        private Button HesaplaVeCızButton_8;
        private Label label55;
        private Label label54;
        private Label label53;
        private Label label52;
        private Label label51;
        private Label label50;
        private Label label49;
        private Label label48;
        private NumericUpDown SilindirYariCap_8;
        private NumericUpDown SilindirZEkseni_8;
        private NumericUpDown SilindirYEkseni_8;
        private NumericUpDown SilindirXEkseni_8;
        private NumericUpDown NoktaZEkseni_8;
        private NumericUpDown NoktaYEkseni_8;
        private NumericUpDown NoktaXEkseni_8;
        private Label label56;
        private NumericUpDown SilindirBoy_8;
        private NumericUpDown silindir1YMerkez_9;
        private NumericUpDown silindir1XMerkez_9;
        private Label label67;
        private Label label66;
        private Label label65;
        private Label label64;
        private Label label63;
        private Label label62;
        private Label label61;
        private Label label60;
        private Label label59;
        private Label label58;
        private Label label57;
        private TextBox textBoxSonuc_9;
        private Button Hesapla_ve_ciz_9_button;
        private NumericUpDown silindir2Yaricap_9;
        private NumericUpDown silindir2Boy_9;
        private NumericUpDown numericUpDown10;
        private NumericUpDown silindir2ZMerkez_9;
        private NumericUpDown silindir2YMerkez_9;
        private NumericUpDown silindir2XMerkez_9;
        private NumericUpDown silindir1Yaricap_9;
        private NumericUpDown silindir1Boy_9;
        private NumericUpDown silindir1ZMerkez_9;
        private Label label68;
        private Label label77;
        private Label label76;
        private Label label75;
        private Label label72;
        private Label label74;
        private Label label71;
        private Label label73;
        private Label Kure1Zekseni_10;
        private Label label69;
        private NumericUpDown Kure2Yaricap_10;
        private NumericUpDown Kure2Zekseni_10;
        private NumericUpDown Kure2Yekseni_10;
        private NumericUpDown Kure2Xekseni_10;
        private NumericUpDown Kure1Yaricap_10;
        private NumericUpDown Kureniz1Zekseni_10;
        private NumericUpDown Kure1Yekseni_10;
        private NumericUpDown Kure1Xekseni_10;
        private TextBox textBoxSonuc_10;
        private Button hesapla_ve_cız_button_10;
        private TextBox textBoxSonuc_16;
        private Button HesaplaVeCizdir_16;
        private Label label78;
        private Label label87;
        private TextBox textBoxSonuc_11;
        private Button Hesapla_ve_Ciz_11;
        private Label label86;
        private Label label85;
        private Label label84;
        private Label label81;
        private Label label83;
        private Label label80;
        private Label label82;
        private Label label79;
        private Label label70;
        private NumericUpDown SilindirYaricap_11;
        private NumericUpDown SilindirBoy_11;
        private NumericUpDown SilindirMekrezZ_11;
        private NumericUpDown KureYaricap_11;
        private NumericUpDown SilindirMekrezY_11;
        private NumericUpDown KureMerkezZ_11;
        private NumericUpDown SilindirMekrezX_11;
        private NumericUpDown KureMerkezY_11;
        private NumericUpDown KureMerkezX_11;
        private Button Hesapla_ve_Ciz_button_12;
        private TextBox textBoxSobuc_12;
        private Label label98;
        private Label label97;
        private Label label91;
        private Label label95;
        private Label label90;
        private Label label94;
        private Label label93;
        private Label label89;
        private Label label88;
        private NumericUpDown YuzeyMerkezZ_12;
        private NumericUpDown KureYaricap_12;
        private NumericUpDown YuzeyYaricap_12;
        private NumericUpDown KureMerkezZ_12;
        private NumericUpDown KureMerkezX_12;
        private NumericUpDown KureMerkezY_12;
        private NumericUpDown YuzeyMerkezY_12;
        private NumericUpDown YuzeyMerkezX_12;
        private TextBox textBoxSonuc_13;
        private Button HesaplaVeCiz_13;
        private Label label106;
        private Label label101;
        private Label label105;
        private Label label100;
        private Label label104;
        private Label label99;
        private Label label103;
        private Label label96;
        private Label label102;
        private Label label92;
        private NumericUpDown DikdortgenPrizmaBoy_13;
        private NumericUpDown numericUpDown12;
        private NumericUpDown DikdortgenPrizmaEn_13;
        private NumericUpDown DikdortgenPrizmaDerinlik_13;
        private NumericUpDown numericUpDown11;
        private NumericUpDown DikdortgenPrizmaMerkezZ_13;
        private NumericUpDown Yyaricap_13;
        private NumericUpDown numericUpDown9;
        private NumericUpDown DikdortgenPrizmaMerkezY_13;
        private NumericUpDown YuzeyMerkezZ_13;
        private NumericUpDown numericUpDown8;
        private NumericUpDown DikdortgenPrizmaMerkezX_13;
        private NumericUpDown YuzeyMerkezY_13;
        private NumericUpDown numericUpDown7;
        private NumericUpDown YuzeyMerkezX_13;
        private NumericUpDown YuzeyYaricap_14;
        private TextBox textBoxSonuc_14;
        private Button Hesapla_VE_Ciz_14;
        private Label label116;
        private Label label115;
        private Label label114;
        private Label label113;
        private Label label110;
        private Label label112;
        private Label label109;
        private Label label111;
        private Label label108;
        private Label label107;
        private NumericUpDown SilindirYaricap_14;
        private NumericUpDown SilindirBoy_14;
        private NumericUpDown SilindirMerkezX_14;
        private NumericUpDown SilindirMerkezZ_14;
        private NumericUpDown YuzeyMerkezZ_14;
        private NumericUpDown SilindirMerkezY_14;
        private NumericUpDown YuzeyMerkezY_14;
        private NumericUpDown YuzeyMerkezX_14;
        private Label label127;
        private TextBox textBoxSonuc_15;
        private Button Hesapla_ve_ciz_15_button;
        private Label label126;
        private Label label121;
        private Label label125;
        private Label label120;
        private Label label124;
        private Label label119;
        private Label label123;
        private Label label118;
        private Label label122;
        private Label label117;
        private NumericUpDown DikdortgenPrizmaMerkezX_15;
        private NumericUpDown DikdortgenPrizmaDERİNLİK_15;
        private NumericUpDown KureYaricap_15;
        private NumericUpDown DikdortgenPrizmaBOY_15;
        private NumericUpDown KureMerkezNoktaZ_15;
        private NumericUpDown DikdortgenPrizmaEn_15;
        private NumericUpDown KureMerkezNoktaY_15;
        private NumericUpDown DikdortgenPrizmaMerkezZ_15;
        private NumericUpDown KureMerkezNoktaX_15;
        private NumericUpDown DikdortgenPrizmaMerkezY_15;
        private Label Sonuc;
        private Label label139;
        private Label label138;
        private Label label136;
        private Label label135;
        private Label label133;
        private Label label137;
        private Label label132;
        private Label label134;
        private Label label130;
        private Label D11;
        private Label label129;
        private Label label128;
        private NumericUpDown DikdortgrnPrizma2DERİNLİK_16;
        private NumericUpDown DikdortgrnPrizma1DERİNLİK_16;
        private NumericUpDown DikdortgrnPrizma2BOY_16;
        private NumericUpDown DikdortgrnPrizma1BOY_16;
        private NumericUpDown DidkortgenPrizma2Z_16;
        private NumericUpDown DidkortgenPrizma1Z_16;
        private NumericUpDown DikdortgrnPrizma2EN_16;
        private NumericUpDown DikdortgrnPrizma1EN_16;
        private NumericUpDown DidkortgenPrizma2Y_16;
        private NumericUpDown DidkortgenPrizma1Y_16;
        private NumericUpDown DidkortgenPrizma2X_16;
        private NumericUpDown DidkortgenPrizma1X_16;
        private Button HesaplaVeCizdirButton_1;
        private Label label144;
        private Label label131;
        private Label label154;
        private Label label150;
        private Label label153;
        private Label label152;
        private Label label145;
        private Label label143;
        private Label label149;
        private Label label148;
        private Label label141;
        private Label label147;
        private Label label146;
        private Label label140;
        private TextBox textBoxSonuc_1;
        private NumericUpDown KareIcınMerkezNoktaX_1;
        private NumericUpDown YamukMerkezNoktaX_1;
        private NumericUpDown YamukEGIM_1;
        private NumericUpDown Nokta2X_1;
        private NumericUpDown Nokta1X_1;
        private NumericUpDown Nokta2Y_1;
        private NumericUpDown Nokta1Y_1;
        private NumericUpDown KareIcınEn_1;
        private NumericUpDown YamukEN_1;
        private NumericUpDown KareIcınBoy_1;
        private NumericUpDown YamukBOY_1;
        private NumericUpDown KareIcınMerkezNoktaY_1;
        private NumericUpDown YamukMerkezNoktaY_1;
        private Button HesaplaVeCizdir2_1;
        private TabPage ListCizdir;
        private Label label6;
        private Button Cizdir_list;
        private TextBox textBoxSonuc11_2;
    }
}