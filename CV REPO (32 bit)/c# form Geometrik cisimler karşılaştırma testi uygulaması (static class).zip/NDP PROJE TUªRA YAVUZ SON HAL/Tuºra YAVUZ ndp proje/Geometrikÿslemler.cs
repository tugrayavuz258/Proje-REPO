﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuğra_YAVUZ_ndp_proje
{
    internal class Geometrikİslemler
    {



    }
}
